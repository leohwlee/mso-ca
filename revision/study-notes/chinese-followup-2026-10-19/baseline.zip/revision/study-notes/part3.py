"""Source-authored bilingual manuscript; independently revised 2026-10-19. No bank input."""
from model import p, ref, block, section

PART = dict(title=p('《打擊洗錢及恐怖分子資金籌集條例》：附表', 'Anti-Money Laundering and Counter-Terrorist Financing Ordinance: schedules'),
intro=p('先記住定義及法定最低要求，再到Part 6掌握指引下的完整操作。門檻、額外措施及例外均須連同適用對象理解。', 'Learn the definitions and statutory minimum requirements, then use Part 6 for full operational guidance. Read thresholds, additional measures and exceptions together with their applicable persons.'), sections=[
section('definitions', '附表1及附表2：重要定義', 'Schedules 1 and 2: key definitions', [
    block('金融機構、關係及對等司法管轄區', 'Institutions, relationships and equivalent jurisdictions', [
        ('金融機構涵蓋認可機構、持牌法團、獲授權保險人、持牌個人保險代理／保險代理機構／保險經紀公司、MSO、郵政署署長、儲值支付工具持牌人、持牌虛擬資產服務提供者及穩定幣持牌人等法定類別；各類別並非適用完全相同的發牌部份。', 'Financial institutions include authorized institutions, licensed corporations, authorized insurers, licensed individual insurance agents/agencies/broker companies, MSOs, the Postmaster General, SVF licensees, licensed VAS providers and stablecoin licensees. They do not all use the same licensing Part.'),
        ('業務關係是預期有持續性的業務、專業或商業關係；非經常交易是在沒有業務關係的客戶交易。不能因一次交易金額小便否定本已存在的持續關係。', 'A business relationship is a business, professional or commercial relationship expected to have duration. An occasional transaction concerns a customer without such a relationship. A small individual transaction does not erase an existing ongoing relationship.'),
        ('對等司法管轄區指香港以外的FATF成員，或採取與附表2相若要求的司法管轄區。「業務日」的法定定義排除公眾假期、烈風警告日及黑色暴雨警告日；遇到業務日期限須使用法定定義。', 'An equivalent jurisdiction is a FATF member other than Hong Kong or a jurisdiction imposing similar Schedule 2 requirements. The statutory business-day definition excludes public holidays, gale-warning days and black-rainstorm-warning days; apply it where a deadline uses business days.'),
    ], [
        ref('04', '附表1第1–3條；附表2第1條', 'Schedule 1 ss.1–3; Schedule 2 s.1', 'equivalent jurisdiction'),
    ], kind='list'),
    block('實益擁有人與政治人物', 'Beneficial owners and PEPs', [
        ('公司：自然人直接／間接擁有或控制超過25%已發行股本、行使／控制超過25%股東大會投票權，或最終控制管理。合夥：自然人直接／間接超過25%資本／利潤或投票權，或最終控制管理。兩類也包括交易為其進行的另一「人」，不能把這個分支一概限於自然人。正好25%未達百分比門檻，仍須檢查控制。', 'For corporations: individuals directly/indirectly owning or controlling more than 25% of issued capital or general-meeting votes, or exercising ultimate management control. For partnerships: individuals with directly/indirectly more than 25% of capital, profits or votes, or ultimate management control. Both also include another “person” on whose behalf the transaction is conducted; that limb is not universally limited to individuals. Exactly 25% misses the percentage test, but control must still be examined.'),
        ('信託的實益擁有人涵蓋對信託資本享有既得權益的個人、財產授予人、保障人／執行人、受託人及最終控制信託的人；其他法人／法律安排須識別處於等同或相若位置的人。', 'Trust beneficial owners cover individuals with vested interests in capital, settlors, protectors/enforcers, trustees and persons exercising ultimate control. Other legal persons/arrangements require identification of equivalent or similar positions.'),
        ('法定政治人物定義針對香港以外獲委任重要公職的人，包括國家／政府首長、高級政客、政府／司法／軍事高層、國企高級行政人員及重要政黨幹事，亦包括法定家庭成員及密切聯繫者；不包括中／初級職員。指引另處理香港本地及國際組織政治人物。', 'The statutory PEP definition concerns prominent public functions outside Hong Kong, including heads of state/government, senior politicians, government/judicial/military officials, state-enterprise executives and important party officials, plus statutory family/close associates. It excludes middle/junior officials. The Guideline separately addresses domestic and international-organisation PEPs.'),
    ], [
        ref('04', '附表2第1條', 'Schedule 2 s.1', 'more than 25%'),
    ], kind='list'),
    block('公共機構及識別文件', 'Public bodies and identification documents', [
        ('公共機構包括行政／立法／市政議會、政府部門／事業、地方或公共當局／事業、由行政長官或政府委任的委員會等組織，以及依法可用公共身分行事的組織；不只指政府部門。法人包括公共機構及有／無法團身分的團體。', 'Public bodies include executive/legislative/municipal/urban councils, government departments/undertakings, local/public authorities/undertakings, CE/Government-appointed boards and bodies empowered to act publicly by enactment. They are not just government departments. Legal persons include public bodies and incorporated/unincorporated bodies.'),
        ('附表2法定識別文件：自然人為身分證、身分證明書、簽證身分書或旅行證件；香港公司為成立證明或遷冊證明；註冊非香港公司為相關註冊證明。其他境外法團用當地相當註冊機關發出的成立／註冊或等同證明。', 'Schedule 2 statutory identification documents: individuals—identity card, certificate/document of identity or travel document; Hong Kong companies—incorporation or re-domiciliation certificate; registered non-Hong Kong companies—registration certificate; other foreign corporations—incorporation/registration or equivalent evidence from the corresponding local authority.'),
        ('在港經營合夥的法定識別文件是商業登記證；不在港經營合夥則為合夥協議或政府發出的成立／註冊文件。須分清此定義，與指引一般可採用的可靠獨立核實資料並非同一個清單。', 'For a Hong Kong-business partnership the statutory identification document is the BR certificate; for a partnership not doing business in Hong Kong it is its agreement or government formation/registration evidence. This definition differs from the Guideline’s wider reliable-independent verification sources.'),
    ], [
        ref('04', '附表2第1條', 'Schedule 2 s.1', 'public body'),
    ], kind='list'),
    block('金融機構以外的指定行業及數碼識別', 'Designated non-financial professions and digital identification', [
        ('DNFBP指指定非金融業人士，包括會計專業人士、地產代理、法律專業人士、信託或公司服務（TCSP）持牌人，以及貴金屬及寶石B類註冊人。DNFBP不是所有非金融商戶，也不等於MSO。', 'DNFBP means designated non-financial businesses and professions: accounting professionals, estate agents, legal professionals, trust or company service provider (TCSP) licensees and Category B precious-metals/stones registrants. It does not mean every non-financial business or an MSO.'),
        ('認可數碼識別系統須是由相應有關當局／監管機構認可的可靠獨立來源。對MSO，須由海關關長認可；使用數碼文件、視像或一般手機驗證，本身不等於使用法定認可系統。', 'A recognized digital identification system must be a reliable independent source recognized by the applicable authority/regulatory body. For an MSO the recognizing authority is the CCE; electronic files, video or ordinary mobile verification do not by themselves constitute a statutory recognized system.'),
    ], [
        ref('04', '附表1第1部第1條；附表2第1條', 'Schedule 1 Part 1 s.1; Schedule 2 s.1', 'DNFBP (指定非金融業人士)'),
    ], kind='list'),
    block('對等司法管轄區的評估不是只記名單', 'Assessing equivalent jurisdictions beyond a memorised list', [
        ('對非FATF成員司法管轄區，MSO可能須自行判斷是否有相類規定，並記錄評估。可考慮FATF類區域組織成員資格／相互評估、策略缺失及改善進度、關長通函，以及專門機構刊物；須定期及／或觸發事件後覆核。', 'For a non-FATF-member jurisdiction the MSO may need to determine whether comparable requirements apply and document its assessment. Factors may include FATF-style regional membership/mutual evaluations, strategic deficiencies/progress, CCE advisories and specialist publications. Review regularly and/or following trigger events.'),
    ], [
        ref('03', '第4.16.2–4.16.3段', '¶4.16.2–4.16.3', 'The MSO should document its assessment of the jurisdiction'),
    ], kind='list'),
]),
section('core-duties', '四項盡職審查與觸發條件', 'Four CDD measures and their triggers', [
    block('完整措施及時間', 'Full measures and timing', [
        ('四項CDD：識別及核實客戶；識別實益擁有人並採合理措施核實及了解法人／信託結構；取得業務關係目的及擬具有的性質資料（明顯可見者除外）；識別／核實代表客戶行事的人及其授權。識別和核實是不同工作。', 'The four CDD measures are: identify/verify the customer; identify beneficial owners and reasonably verify them, understanding legal-person/trust structures; obtain the relationship’s purpose/intended nature unless obvious; and identify/verify persons acting for the customer and their authority. Identification and verification are separate tasks.'),
        ('須在建立業務關係前、一般非經常交易等於或超過120,000元前、金融機構非經常電傳轉賬或虛擬資產轉移等於或超過8,000元前進行CDD。單次或看似有關連的多次操作須合併考慮。持牌虛擬資產服務提供者另有非轉賬非經常交易8,000元規則，不能套作所有MSO的一般門檻。', 'CDD precedes a business relationship, general occasional transactions of at least HK$120,000, and financial-institution occasional wire/VA transfers of at least HK$8,000. Consider single or apparently linked operations together. Licensed VAS providers have a separate HK$8,000 non-transfer occasional-transaction rule; it is not every MSO’s general threshold.'),
        ('懷疑涉及洗錢／恐怖分子資金籌集，或懷疑以往識別／核實資料的真確／足夠程度，也須CDD，不受上述金額門檻限制。第13條另有非電傳匯款8,000元的特定識別及紀錄責任。', 'Suspicion of ML/TF or doubt about previous identification/verification information also triggers CDD, regardless of those thresholds. Section 13 separately imposes specified identification/record duties for non-wire remittance of at least HK$8,000.'),
        ('延後核實只可在不打斷正常業務所必需、風險有效受管理時使用，並須在關係建立後合理切實可行的範圍內盡快完成。不能遵從時不得建立關係／作非經常交易；已建立的須盡快終止。', 'Delayed verification requires necessity to avoid interrupting normal business and effective risk management; complete it as soon as reasonably practicable after establishment. Inability to comply means no relationship/occasional transaction, or prompt termination of an existing relationship.'),
    ], [
        ref('04', '附表2第2–3、13條', 'Schedule 2 ss.2–3, 13', 'before establishing a business relationship with the customer'),
    ], kind='list'),
]),
section('simplification', '簡化審查：只豁免指定措施', 'Simplified CDD: only specified measures are omitted', [
    block('第4條的範圍', 'Scope of section 4', [
        ('有合理理由相信客戶屬合資格類別時，可不做第2(1)(b)條的實益擁有人措施，其餘客戶、代表人及目的／性質措施仍適用。合資格實體出現在擁有權鏈內，豁免只及於該實體及其以上部分，不是整條鏈。', 'Where there are reasonable grounds that the customer qualifies, section 2(1)(b) beneficial-owner measures may be omitted; customer, representative and purpose/nature measures remain. A qualifying entity within a chain stops BO enquiries at/beyond that entity, not throughout the chain.'),
        ('合資格類別：金融機構；在對等司法管轄區成立、經營相若金融業務、有相若措施及受監管的機構；在任何證券交易所上市的法團；符合投資者CDD負責人條件的投資工具；香港政府／公共機構；對等司法管轄區政府／相若公共機構。', 'Qualifying categories: financial institutions; similarly regulated institutions established in equivalent jurisdictions with similar business/measures; corporations listed on any stock exchange; investment vehicles meeting investor-CDD responsibility conditions; Hong Kong Government/public bodies; and equivalent-jurisdiction governments/similar public bodies.'),
        ('產品例外：供款從受僱收入扣除且不可轉讓權益的僱員退休計劃；沒有退保條款且不可作抵押的相關計劃保單；每年保費不多於8,000元或單次保費不多於20,000元的人壽保單。這些是指定產品，不是一般匯款的免審查門檻。', 'Product exceptions cover employee retirement schemes funded by employment-income deductions with non-assignable interests; relevant scheme insurance without surrender/collateral; and life policies with annual premium no more than HK$8,000 or single premium no more than HK$20,000. These are specific products, not general remittance exemptions.'),
        ('律師／律師行客戶帳戶須同時是以其名義開立、混合其客戶金錢／證券、由其作代理管理，才適用第4(6)條的實益擁有人措施例外。出現懷疑或資料疑問仍須按第3條處理。', 'For solicitor/firm accounts, section 4(6) requires the account to be in the solicitor’s/firm’s name, mix clients’ money/securities, and be managed as their agent. Suspicion/information doubts still require section 3 handling.'),
    ], [
        ref('04', '附表2第3–4條', 'Schedule 2 ss.3–4', 'Simplified customer due diligence'),
    ], kind='list'),
]),
section('special-cases', '額外措施：遙距、政治人物及其他高風險', 'Additional measures: remote customers, PEPs and other high risk', [
    block('先完成普通CDD，再加所需措施', 'Additional to ordinary CDD', [
        ('非親身識別至少加一項：用未曾使用的可靠獨立資料再核實；補充核實已取得資料；或確保首筆付款經客戶在認可機構／符合四項條件的對等地區銀行類機構的同名帳戶。以認可數碼識別系統資料完成法定識別者有第9(2)條例外，並非所有視像／電子程序都自動符合。', 'For non-face-to-face identification, add at least one: further verification using previously unused reliable independent material; supplementary verification of obtained information; or first payment through a same-name account at an authorized institution/qualifying equivalent-jurisdiction bank-like institution. Section 9(2) exempts statutory identification using a recognized digital-ID system, not every video/electronic process.'),
        ('非香港政治人物在建立／繼續關係前須高級管理層批准，並合理確立財富來源及資金來源。前政治人物經適當風險評估認定不再高風險時，法定例外才可使用；不能只因離任或過了固定年數便豁免。', 'Non-Hong Kong PEP relationships require senior-management approval and reasonable establishment of both wealth and funds sources before establishment/continuation. A former PEP qualifies for the statutory exception only after appropriate assessment establishes no high risk, not automatically after leaving office or a fixed number of years.'),
        ('第15條其他高風險情況：建立／繼續關係須高級管理層批准，再合理確立財富及資金來源，或採其他額外緩解措施；現有關係另須合理核實實益擁有人。非經常交易須採額外緩解措施。管理層批准不是任選項，政治人物的全部指定措施亦不能被此選擇取代。', 'For section 15 other high-risk cases, establishing/continuing a relationship requires senior approval plus either reasonable establishment of wealth/funds sources or other additional mitigation; existing relationships also require reasonable BO verification. Occasional transactions require additional mitigation. Approval is not optional, and this choice does not replace all PEP measures.'),
        ('不得開立／維持匿名或虛假姓名帳戶。認可機構不得與第17條所界定的空殼銀行法團建立／繼續往來銀行關係。', 'Do not open/maintain anonymous or fictitious-name accounts. Authorized institutions must not establish or continue correspondent relationships with shell-bank corporations defined in section 17.'),
    ], [
        ref('04', '附表2第8–10、15–17條', 'Schedule 2 ss.8–10, 15–17', 'at least one of the following measures'),
    ], kind='list'),
    block('空殼銀行：四項條件與實體經營', 'Shell banks: cumulative conditions and physical presence', [
        ('第17條禁止認可機構建立／繼續代理銀行關係的對象，是同時：(1)在香港以外註冊成立；(2)獲當地授權經營銀行業務；(3)在當地沒有實體經營；(4)並非在某司法管轄區註冊、獲授權且有實體經營的銀行法團的聯屬公司。不是所有境外、網上或無香港分行的銀行都自動屬此類。', 'The section 17 correspondent prohibition for authorized institutions concerns a corporation cumulatively (1) incorporated outside Hong Kong, (2) authorized there to conduct banking, (3) without physical presence there, and (4) not affiliated with a corporation incorporated, banking-authorized and physically present in a jurisdiction. A foreign/online bank or one without a Hong Kong branch is not automatically such a shell bank.'),
        ('實體經營須在當地處所經營銀行業務，並有至少一名全職僱員在該處履行銀行職務。聯屬包括附屬公司，或至少有一名自然人同時是兩家法團的控制人的法定情況。該條的直接責任人是認可機構，不是把MSO當成提供代理銀行服務的銀行。', 'Physical presence requires banking at premises there and at least one full-time employee performing banking duties there. Affiliation includes subsidiary status or at least one individual who is simultaneously a controller of both corporations in the statutory cases. The direct section 17 duty is on authorized institutions, not a rule treating an MSO as a correspondent bank.'),
    ], [
        ref('04', '附表2第17(1)–(3)條', 'Schedule 2 s.17(1)–(3)', 'Correspondent banking relationships with shell banks'),
    ], kind='list'),
]),
section('sector-specific', '其他金融機構的特定要求', 'Specific requirements for other financial activities', [
    block('保單、往來銀行及虛擬資產', 'Insurance, correspondent banking and virtual assets', [
        ('保單受益人指定時記錄姓名；以類別／描述指定則取得足夠資料，確保最遲在行使既得權利或首次付款的較早時間能確立身分。屆時核實受益人；受益人是法人／信託則識別實益擁有人，並在高風險時合理核實。', 'When an insurance beneficiary is designated, record the name or enough information for a described/class beneficiary to establish identity by the earlier of exercise of vested rights or first payout. Verify then; for legal-person/trust beneficiaries identify BOs and reasonably verify them where high risk.'),
        ('認可機構與境外對手建立往來銀行關係前，須了解業務、聲譽／監管及AML制度，取得高級管理層批准、滿意制度足夠有效、記錄雙方責任；直接使用帳戶的對手客戶還須符合CDD／監察及資料提供條件。', 'Before an overseas correspondent relationship, an authorized institution understands the respondent’s business, reputation/supervision and AML controls; obtains senior approval; satisfies itself about effective adequate controls; and documents responsibilities. Payable-through customers require respondent CDD/monitoring and data-access conditions.'),
        ('虛擬資產轉移：代匯款人把虛擬資產轉至受款人於受款機構的安排。匯款機構記錄並提交匯款人及受款人姓名、帳戶／參考編號；達8,000元另加匯款人地址、客戶／識別文件號碼或出生日期地點其中一項。受款機構記錄收到資料，中介機構傳遞全部收到資料。', 'A VA transfer moves virtual assets for an originator to a recipient at a beneficiary institution. The ordering institution records/submits both names and account/reference identifiers; at HK$8,000 add originator address, customer/document identifier or date/place of birth. Beneficiaries record received information; intermediaries transmit all received information.'),
        ('虛擬資產轉移資料欠缺時須盡快索取；取不到則考慮限制／終止機構關係或採合理風險緩解措施。已知資料不完整或無意義也須盡快減低風險。持有MSO牌照不等於獲准經營虛擬資產交易所。', 'Promptly obtain missing VA-transfer information; if unavailable, consider restricting/terminating the institution relationship or take reasonable mitigation. Known incomplete/meaningless information also requires prompt mitigation. An MSO licence does not authorize operation of a VA exchange.'),
    ], [
        ref('04', '附表2第11、13A、14條；附表3B', 'Schedule 2 ss.11, 13A, 14; Schedule 3B', 'Special requirements for virtual asset transfer'),
    ], kind='list'),
    block('參考：其他行業的附表如何配對', 'Reference: pairing the other sector schedules', [
        ('附表3A是TCSP費用；3B界定虛擬資產服務；3C是其費用，3D是相聯實體的通知資料，3E是周年申報資料，3F是財務報表及核數師報告，3G是2023年開始的虛擬資產過渡安排。它們各有適用對象，不可把「周年申報」誤認為MSO第15份的半年申報。', 'Schedule 3A contains TCSP fees; 3B defines VA services; 3C contains VA fees, 3D associated-entity notifications, 3E annual-return information, 3F financial statements/auditor reports, and 3G VA transitional arrangements beginning in 2023. Each has its own subject; these annual returns are not the MSO half-yearly returns in document 15.'),
        ('附表3H／3I分別訂DPMS指明現金／非現金交易120,000元門檻；3J列非香港交易商現金報告所需資料：交易商及客戶基本資料、相關個人出入境資料、交易日期／貨品／現金金額／地點。3K為DPMS費用。上述制度條件見Part 2末節「其他行業制度與MSO的界線」；費用細目及已過啟動期的過渡程序保留原文查考，不當作MSO日常必背清單。', 'Schedules 3H/3I set the HK$120,000 DPMS cash/non-cash thresholds. Schedule 3J requires basic dealer/customer information, specified individuals’ travel details, and the transaction date, goods, cash amount and location. Schedule 3K contains DPMS fees. See the final Part 2 section, Other sector regimes, for applicability; itemised fees and transition procedures whose commencement periods have passed remain source references, not a daily MSO memorisation list.'),
    ], [
        ref('04', '附表3A–3K；Part 2筆記末節', 'Schedules 3A–3K; Part 2 notes, final section', 'Information to be Provided in Cash Transaction Report'),
    ], kind='reference'),
]),
section('ongoing-and-records', '持續監察、中介人及紀錄責任', 'Monitoring, intermediaries and records', [
    block('不能把責任外判掉', 'Responsibility remains with the institution', [
        ('定期覆核客戶資料、審視交易與背景／業務／風險及資金來源是否一致，識別及書面審查複雜、異常大額／模式且沒有明顯經濟或合法目的的交易。政治人物、遙距及其他高風險情況須額外監察。', 'Review customer information, scrutinize consistency with background/business/risk and funds sources, and identify/examine in writing complex, unusually large/patterned transactions without apparent economic/lawful purpose. PEP, remote and other high-risk cases require additional monitoring.'),
        ('MSO原有客戶指2012年4月1日前已建立關係者；異常／可疑或與背景不符交易、帳戶運作重大改變、懷疑及資料疑問會觸發CDD。無法完成須盡快終止；不能以原有客戶作永久豁免。', 'For MSOs, pre-existing customers predate 1 April 2012. Unusual/suspicious or inconsistent transactions, material account-operation changes, suspicion and information doubts trigger CDD. Inability to complete requires prompt termination; pre-existing status is not permanent exemption.'),
        ('合資格中介人須書面同意並能應要求無延誤提供紀錄；CDD資料完成後立即取得，支持文件可在要求後合理切實可行範圍內盡快取得。依賴中介人或代理不移轉本機構的違規責任。持續監察仍由MSO負責。', 'A qualifying intermediary consents in writing and can supply records without delay on request. Obtain CDD information immediately after performance; supporting copies follow as soon as reasonably practicable after request. Reliance/agency does not transfer liability. Ongoing monitoring remains the MSO’s duty.'),
        ('客戶／實益擁有人及相關CDD紀錄：關係持續期間及終止後至少5年；非經常交易相關CDD資料從交易完成後至少5年。交易紀錄從交易完成後至少5年，須可重組交易並迅速應監管要求提供；有關當局可指定延長。', 'CDD/customer/BO records last throughout the relationship and at least five years after termination; occasional-transaction CDD records last at least five years after completion. Transaction records last at least five years after completion, must permit reconstruction and prompt supervisory access; the authority may require longer retention.'),
        ('須建立有效政治人物、轉賬欠缺資料及各類客戶／產品／交易的程序。香港成立或遷冊來港金融機構在海外經營相同業務的分行／附屬公司，須在當地法律容許下實施相若制度；不能實施時通知有關當局並另作緩解。', 'Maintain effective PEP, deficient-transfer and customer/product/transaction procedures. Hong Kong-incorporated or re-domiciled financial institutions apply similar systems in overseas same-business branches/subsidiaries where local law permits; notify the authority and mitigate where not possible.'),
    ], [
        ref('04', '附表2第5–6、18–23條', 'Schedule 2 ss.5–6, 18–23', 'occasional transaction is completed'),
    ], kind='list'),
]),
section('fees', '附表3：金錢服務牌照費用', 'Schedule 3: MSO licensing fees', [
    block('按repo所存2026年綜合版本', 'Amounts in the repo’s 2026 consolidated edition', [
        ('新牌申請：基本3,810元，另每個額外營業處所2,440元，每名須作適當人選評核的人945元。續牌：基本910元，另每個額外處所410元，每名評核人士945元。', 'Grant application: HK$3,810 base, plus HK$2,440 per additional business premises and HK$945 per person subject to the fit-and-proper test. Renewal: HK$910 base, plus HK$410 per additional premises and HK$945 per tested person.'),
        ('申請批准新增董事、最終擁有人或合夥人：每人945元。加新營業處所、或由無特定處所轉特定處所：每個處所2,440元。', 'Approval applications for directors, ultimate owners or partners: HK$945 per person. Adding premises or applying to operate at particular premises: HK$2,440 per premises.'),
        ('核證登記冊副本／摘錄每份160元；非核證副本每頁或不足一頁1.5元；第28(1)(b)條證明書每份160元。公開查閱登記冊免費，與索取副本不同。費用只代表所存版本，實際申請須核對當時表格及法定費表。', 'Certified register copies/extracts cost HK$160 each; uncertified copies HK$1.50 per page or part; section 28(1)(b) certificates HK$160 each. Public inspection is free, unlike copies. These are stored-edition amounts; actual applications require the then-current form/statutory fee schedule.'),
    ], [
        ref('04', '第27–28條；附表3', 'ss.27–28; Schedule 3', '3,810'),
    ], kind='list'),
    block('申請費、適當人選測試費與退費', 'Application fees, fitness-test fees and refunds', [
        ('發牌／續牌申請費一經收取，不論其後批准或拒絕均不退還；每位適當人選測試申請人須付一次性測試費，也不退還。不要把申請不成功誤當成可取回費用，亦不要把每人費用算作整家公司只付一次。', 'Grant/renewal application fees are non-refundable whether approved or refused. Each fit-and-proper test applicant pays a one-off test fee, also non-refundable. An unsuccessful application does not create a refund, and a per-person charge is not one charge for the whole company.'),
    ], [
        ref('05', '第2.8、4.13–4.14、6.3段', '¶2.8, 4.13–4.14, 6.3', 'fee paid for the fit and proper person test is non'),
    ], kind='list'),
]),
section('tribunal-schedule', '附表4：審裁處成員及聆訊安排', 'Schedule 4: tribunal membership and hearings', [
    block('成員、表決及出席', 'Membership, voting and attendance', [
        ('主席須具高等法院法官委任資格，且除審裁處主席等法定例外外不是公職人員。主席任期不超過3年，可續任。局長另委任非公職人員組成委員團，依主席建議為每宗覆核選兩名普通成員。', 'The chair must qualify for appointment as a judge of the High Court and not be a public officer except statutory tribunal-chair exceptions. The term is up to three years, renewable. The Secretary appoints a non-public-officer panel and, on the chair’s recommendation, two ordinary members for each review.'),
        ('一般須主席及兩名普通成員在席，多數票決定；法律問題由主席單獨決定。主席任期在案件中途屆滿可繼續完成該案；成員變更，須各方同意才繼續，否則中止但可重開。', 'Normally the chair and two ordinary members sit and decide by majority; the chair alone decides law. A chair whose term expires mid-review may finish it. Membership changes require parties’ consent to continue; otherwise proceedings discontinue but may restart.'),
        ('一般公開聆訊；為司法公正可依職權或申請決定非公開，申請非公開本身的聆訊也非公開。各方可親身、公司由高級人員／僱員、合夥由合夥人、當局由代表出席，亦可由律師／大律師或獲准其他人代表。', 'Hearings are normally public. Justice may require privacy on initiative/application; the privacy application itself is heard privately. Parties may attend personally, corporations through officers/employees, partnerships through partners and authorities through representatives, and use lawyers or other persons with leave.'),
    ], [
        ref('04', '第56條；附表4第2–6條', 's.56; Schedule 4 ss.2–6', 'a question of law is to be determined by the chairperson alone'),
    ], kind='list'),
    block('初步會議、同意命令及主席單獨處理', 'Preliminary conferences, consent orders and chair alone', [
        ('初步會議須各方同意，協助準備、釐清爭點及公正迅速節省費用處理；主席主持並向審裁處報告。同意命令須各方要求及同意全部條款，並須屬審裁處／主席原有權作出的命令。', 'Preliminary conferences need parties’ agreement and prepare/clarify issues for just, expeditious, economical review; the chair presides/reports. Consent orders need parties’ request and agreement to all terms and must be within the tribunal’s/chair’s existing powers.'),
        ('正式審理前各方書面同意，可由主席作唯一成員裁定覆核；延長申請覆核期限及暫緩指明決定的申請也可由主席單獨處理。暫緩申請遇主席不能／不宜處理時，終審法院首席法官可委任原訟法庭法官／暫委法官代行。', 'Before the determination hearing, parties may agree in writing to the chair alone deciding the review. The chair may also determine time-extension and specified-decision stay applications alone. If unable/unsuitable for the stay, a CFI judge/deputy may be appointed by the Chief Justice.'),
    ], [
        ref('04', '附表4第7–9條', 'Schedule 4 ss.7–9', 'Preliminary conferences'),
    ], kind='list'),
]),
])
