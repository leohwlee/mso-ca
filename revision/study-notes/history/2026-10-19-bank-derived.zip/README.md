# Seven-part study notes / 七部分溫習資料

Open [index.html](index.html), then select Part 1–7. Each part is a self-contained
bilingual reading page, using the approved B annotated-reference design. Keep
this folder in the repository to use its links to original documents and the
locally built practice app. Nothing has been published to GitHub Releases.

開啟 [index.html](index.html)，再選 Part 1–7。每部分均為可離線閱讀的雙語頁面，
採用已選定的 B「批注式研讀冊」設計。保留資料夾在倉庫內，原件及本地練習 App
連結才可正常使用。本次尚未發佈到 GitHub Releases。

## Material / 內容

- Seven authored introductions, reading maps and topic structures.
- All 525 existing bank items are represented across 2,449 statement-level
  reading references: rules, misconceptions, explanations and deciding quotations.
  Exact bilingual duplicates alone may be merged; qualifiers are not shortened.
- Context headings retain the original topic/scenario before the rule references.
  These pages contain no answer options, selected answers or hidden-answer mode.
- Part 6 also retains its fourteen authored topics, seven diagrams and comparison
  tables. The earlier sample URL remains supported in the new visual style.
- Every reference shows the original repository filename and the bank's source
  locator. Document 24's Chinese material is a study translation linked to the
  English original. Linked source quotations remain in their original language.

新增七部分的閱讀導言、閱讀路線及主題結構，並將現有525題的2,449項陳述整理為
規則、易錯說法、解釋及原文對照。保留適用情境，不以答案選項或隱藏答案方式
呈現。第6部分另保留原有十四主題、七個流程圖及對照表；舊樣章網址仍可使用。
引用顯示實際 repo 檔名及原有定位，第24份中文內容仍明示為學習譯文。

This is a bank-derived study reference plus authored reading structure, not a
new independent semantic review or certification of the entire official syllabus.
No source original, bank statement, truth value, option, answer, score rule or
historical review verdict was changed. Coverage and hashes: [coverage.json](coverage.json).

這是以現有題庫解釋及來源為基礎的溫習資料，並非新一輪獨立語義審核，也不宣稱
完整官方考綱認證。沒有更改原件、題目、真假判定、選項、答案、評分或歷史覆核。
對應及內容雜湊見 [coverage.json](coverage.json)。

## Maintain / 維護

`guides.py` owns the reading structure; `build.py` derives the source-bound detail
and the practice app's filename index. `style.css` is shared with the Part 6
compatibility page. Font: bundled DM Sans, [SIL OFL](../../web/fonts/OFL.txt), with
Traditional Chinese system fallbacks. Styles and fonts are embedded in each page.

`guides.py` 維護主題及閱讀結構；`build.py` 建立來源對照內容及練習 App 的檔名索引。
`style.css` 為共用樣式。字型及樣式嵌入各頁，閱讀毋須外部網絡。

```text
python revision/study-notes/build.py
python revision/part6-sample/build.py
python revision/study-notes/build.py --check
python revision/part6-sample/build.py --check
go run . -export-html dist/mso-ca.html
```

Run the repository checks in [DEVELOPMENT.md](../../DEVELOPMENT.md). UI and content
provenance verification is recorded in [QA.md](QA.md).
