"""Build all seven bilingual study parts and the app's filename citation index.

Reading detail is derived without changing the existing question/quote bank.
Original scenarios preserve the scope of each rule; answer options are omitted.
"""
from __future__ import annotations
import argparse
import hashlib
import html
import importlib.util
import json
import re
from collections import defaultdict
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit
from html.parser import HTMLParser
from guides import PARTS

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BANK = json.loads((ROOT / 'web/questions.json').read_text(encoding='utf-8'))
QUOTES = json.loads((ROOT / 'docs/quotes.json').read_text(encoding='utf-8'))
CATALOG = json.loads((ROOT / 'docs/catalog.json').read_text(encoding='utf-8'))
DOCS = {d['id']: d for d in CATALOG['documents']}
e = html.escape

# Reuse the authored Part 6 sample, including its seven original diagrams.
import sys
sys.path.insert(0, str(HERE.parent / 'part6-sample'))
spec = importlib.util.spec_from_file_location('sample_builder', HERE.parent / 'part6-sample/build.py')
sample = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sample)

def pair(value):
    return ''.join(f'<span class="{lang}" lang="{"zh-Hant" if lang == "tc" else "en"}">{e(value[lang])}</span>' for lang in ('tc','en'))

def label(tc,en):
    return pair(dict(tc=tc,en=en))

def clean_note(text):
    return re.sub(r'^(?:Correct|Incorrect|True|False|正確|不正確|錯誤)\s*[:：]\s*','',text,flags=re.I)

def context_title(q):
    # Interrogative clauses can contain exemptions, actors or prerequisites.
    # Keep the original scenario rather than guessing a declarative rewrite.
    return {lang: q[lang]['q'] for lang in ('tc', 'en')}

def topic_for(q):
    for key,title,pattern in PARTS[q['module']]['topics']:
        if not pattern or re.search(pattern,q['tc']['q']):
            return key
    raise AssertionError(q['id'])

def refs(q, index, evidence=True):
    entries=[]
    for lang in ('tc','en'):
        ref=QUOTES[q['id']][lang][index]
        doc=ref['doc']
        assert '01'<=doc<='26'
        ed=DOCS[doc]['editions']['EN' if doc=='24' else lang.upper()]
        path=ROOT/'docs'/ed['path']
        assert path.is_file(),path
        translated=' · 學習譯文，英文原件' if lang=='tc' and doc=='24' else ''
        entries.append(f'<div class="{lang}" lang="{"zh-Hant" if lang=="tc" else "en"}"><a href="../../docs/{e(quote(ed["path"],safe="/"))}" target="_blank" rel="noopener">{e(ed["file"])}</a>'
                       f'<span class="locator">{e(q["source"][lang]+translated)}</span>'
                       + (f'<blockquote class="evidence" lang="{ref.get("language","zh-Hant" if lang=="tc" else "en")}">{e(ref["text"])}</blockquote>' if evidence else '') + '</div>')
    return '<div class="citations">'+''.join(entries)+'</div>'

def ledger(questions):
    # Only exact bilingual duplicates are merged; changed qualifiers survive.
    unique={}
    for q in questions:
        assert len(q['truth'])==len(q['tc']['notes'])==len(q['en']['notes'])
        for i,truth in enumerate(q['truth']):
            key=json.dumps([q['tc']['q'],q['en']['q'],truth,q['tc']['statements'][i],q['en']['statements'][i],q['tc']['notes'][i],q['en']['notes'][i],QUOTES[q['id']]['tc'][i],QUOTES[q['id']]['en'][i],q['source']],ensure_ascii=False,sort_keys=True)
            if key not in unique: unique[key]=dict(q=q,index=i,ids=[])
            unique[key]['ids'].append(q['id'])
    out=[];previous=None
    for item in unique.values():
        q,i=item['q'],item['index']
        if previous!=q['id']:
            out.append('<div class="context-heading"><h3>'+pair(context_title(q))+'</h3></div>')
            previous=q['id']
        statement=pair({lang:q[lang]['statements'][i] for lang in ('tc','en')})
        note=pair({lang:clean_note(q[lang]['notes'][i]) for lang in ('tc','en')})
        if q['truth'][i]:
            detail='' if all(re.sub(r'\W','',q[lang]['statements'][i]) in re.sub(r'\W','',clean_note(q[lang]['notes'][i])) and len(q[lang]['notes'][i])<len(q[lang]['statements'][i])*1.5+30 for lang in ('tc','en')) else '<p class="detail">'+note+'</p>'
            content='<div class="rule-copy"><p>'+statement+'</p>'+detail+'</div>'
        else:
            content='<div class="rule-copy"><h3>'+label('正確理解','Correct interpretation')+'</h3><p>'+note+'</p></div><aside class="misconception"><h3>'+label('容易混淆的說法','Common misconception')+'</h3><p>'+statement+'</p></aside>'
        out.append('<article class="study-rule"><div class="rule-grid">'+content+'</div>'+refs(q,i)+'<p class="question-map">'+label('題庫對照：','Bank cross-reference: ')+e(', '.join(item['ids']))+'</p></article>')
    return ''.join(out),len(unique)

SCRIPT=sample.SCRIPT + r"""
document.querySelectorAll('[data-language]').forEach(button=>button.addEventListener('click',()=>{
  try{sessionStorage.setItem('mso-study-language',button.dataset.language)}catch{}
  document.querySelectorAll('a[href*="mso-ca.html"]').forEach(a=>{const url=new URL(a.href);url.searchParams.set('lang',button.dataset.language);a.href=url.href});
}));
try{const saved=new URLSearchParams(location.search).get('lang')||sessionStorage.getItem('mso-study-language');const b=document.querySelector('[data-language="'+saved+'"]');if(b)b.click()}catch{}
"""

def part_nav(current):
    return '<nav class="part-nav" aria-label="Parts">'+''.join(f'<a href="part-{n}.html"'+(' aria-current="page"' if n==current else '')+f'>Part {n}</a>' for n in range(1,8))+'</nav>'

def overview_features(n):
    """Introductory visual comparisons use verbatim, true bank statements."""
    by_id={q['id']:q for q in BANK}
    if n==6:return ''
    if n==1:
        q=by_id['m1-gn71']
        steps=[dict(tc='存放',en='Placement'),dict(tc='分層交易',en='Layering'),dict(tc='整合',en='Integrating')]
        assert all(s['en'] in q['en']['statements'] for s in steps)
        return '<figure class="flow"><h2 class="diagram-title">'+label('洗錢的三個常見階段','Three common stages of money laundering')+'</h2><div class="flow-stack">'+ '<div class="arrow" aria-hidden="true"></div>'.join('<div class="flow-node">'+pair(s)+'</div>' for s in steps)+'</div>'+refs(q,0,False)+'</figure>'
    choices={
        2:[('m2-310',None,dict(tc='批給牌照',en='Licence grant')),('m2-312',None,dict(tc='有效期與續期',en='Validity and renewal')),('m2-314',None,dict(tc='停止經營',en='Cessation'))],
        3:[('m3-262',None,dict(tc='何時執行',en='When CDD applies')),('m3-264',None,dict(tc='簡化措施',en='Simplified measures')),('m3-266',None,dict(tc='政治人物',en='PEPs'))],
        4:[('m4-ca4',None,dict(tc='本地管理辦事處',en='Local management office')),('m4-313',None,dict(tc='能力評核安排',en='Assessment arrangements')),('m4-314',None,dict(tc='提名應考人士',en='Nominating candidates'))],
        5:[('m5-16',None,dict(tc='高級管理層',en='Senior management')),('m5-16','The CO',dict(tc='合規主任',en='Compliance Officer')),('m5-19',None,dict(tc='洗錢報告主任',en='MLRO'))],
        7:[('m7-155',i,dict(tc=('非經常電傳轉帳' if '非經常電傳' in text else '交易紀錄' if text.startswith('交易紀錄') else '書面延長要求' if '關長' in text else '業務關係盡職審查紀錄'),en=('Occasional wire transfer' if '非經常電傳' in text else 'Transaction records' if text.startswith('交易紀錄') else 'Written extension requirement' if '關長' in text else 'Relationship CDD records'))) for i,text in enumerate(by_id['m7-155']['tc']['statements']) if by_id['m7-155']['truth'][i]],
    }
    rows=[]
    for qid,index,title in choices[n]:
        q=by_id[qid];i=next(i for i,t in enumerate(q['truth']) if t and (index is None or q['en']['statements'][i].startswith(index))) if index is None or isinstance(index,str) else index
        assert q['truth'][i],(qid,i)
        statement=pair({lang:q[lang]['statements'][i] for lang in ('tc','en')})
        rows.append('<tbody><tr><th scope="row">'+pair(title)+'</th><td>'+statement+'</td></tr><tr class="citation-row"><td colspan="2">'+refs(q,i,False)+'</td></tr></tbody>')
    return '<div class="overview-comparison"><h2>'+label('先把這些規定分開看','Start by distinguishing these requirements')+'</h2><p>'+label('以下節選用作比較；相關其他條件、例外及情境在各主題中繼續列出。','These extracts introduce the comparison; the topic sections retain the other conditions, exceptions and scenarios.')+'</p><div class="table-wrap"><table class="overview-table"><thead><tr><th>'+label('範疇／角色','Area / role')+'</th><th>'+label('原有規則節選','Rule extract')+'</th></tr></thead>'+''.join(rows)+'</table></div></div>'

def page(n):
    part=PARTS[n]
    groups=defaultdict(list)
    for q in BANK:
        if q['module']==n:groups[topic_for(q)].append(q)
    nav=[];body=[];points=0
    if n==6:
        for s in sample.SECTIONS:
            nav.append(f'<a data-section="{s["id"]}" href="#{s["id"]}">'+pair(s['title'])+'</a>')
            body.append(f'<section class="chapter" id="{s["id"]}" aria-labelledby="title-{s["id"]}"><div class="section-heading"><h2 id="title-{s["id"]}">'+pair(s['title'])+'</h2></div><p class="intro">'+pair(s['intro'])+'</p>')
            body.extend(sample.render_block(b,s['id']) for b in s['blocks'])
            body.append('</section>')
    for key,title,_ in part['topics']:
        if not groups[key]:continue
        sid='reference-'+key
        nav.append(f'<a data-section="{sid}" href="#{sid}">'+pair(title)+'</a>')
        detail,count=ledger(groups[key]);points+=count
        body.append(f'<section class="chapter" id="{sid}" aria-labelledby="title-{sid}"><div class="section-heading"><h2 id="title-{sid}">'+pair(title)+'</h2></div>'+detail+'</section>')
    overview='<section class="reading-overview"><p>'+pair(part['intro'])+'</p><ol class="reading-map">'+''.join('<li>'+pair(t)+'</li>' for t in part['focus'])+'</ol>'+overview_features(n)+'</section>'
    text='<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MSO · Part '+str(n)+' · Study Notes</title><style>'+sample.FONT_FACE+(HERE/'style.css').read_text(encoding='utf-8')+'</style><body data-lang="tc"><a class="skip-link" href="#content">'+label('跳至正文','Skip to content')+'</a><header class="toolbar"><div class="toolbar-inner"><div class="brand">MSO Competence Assessment Study Note</div><div class="languages" role="group" aria-label="閱讀語言 / Reading language"><button data-language="tc" aria-pressed="true">繁體中文</button><button data-language="en" aria-pressed="false">English</button><button data-language="both" aria-pressed="false">雙語 / Both</button></div><a class="practice-link" href="../../dist/mso-ca.html?part='+str(n)+'">'+label('練習','Practice')+'</a></div>'+part_nav(n)+'</header><div class="layout"><aside class="sidebar"><h2>'+label('本章目錄','In this part')+'</h2><nav>'+''.join(nav)+'</nav></aside><main id="content" tabindex="-1"><header class="hero"><h1>'+label('第'+str(n)+'部分 · '+part['title']['tc'],'Part '+str(n)+' · '+part['title']['en'])+'</h1></header>'+overview+''.join(body)+'<footer><a href="../../dist/mso-ca.html?part='+str(n)+'">'+label('前往本部分練習','Practise this part')+'</a><p>'+label('本資料按現有題庫解釋及指定來源整理。規則、易錯點及原文引句全部直接顯示；來源定位沿用題庫，並非新增獨立語義覆核或完整官方考綱認證。','Prepared from existing bank explanations and selected sources. Rules, misconceptions and source quotations remain visible. Locators follow the bank; this is not a new independent semantic review or certification of complete official-syllabus coverage.')+'</p></footer></main></div><script>'+SCRIPT+'</script></body></html>\n'
    return text,dict(part=n,questions=[q['id'] for q in BANK if q['module']==n],reference_points=points,topics=[key for key,_,_ in part['topics'] if groups[key]])

def source_index():
    documents={}
    for doc in sorted({ref['doc'] for q in BANK for lang in ('tc','en') for ref in QUOTES[q['id']][lang]}):
        documents[doc]={}
        for lang in ('tc','en'):
            ed=DOCS[doc]['editions']['EN' if doc=='24' else lang.upper()]
            documents[doc][lang]=dict(filename=ed['file'],path=ed['path'],studyTranslation=doc=='24' and lang=='tc')
    return dict(documents=documents,questions={q['id']:sorted({r['doc'] for lang in ('tc','en') for r in QUOTES[q['id']][lang]}) for q in BANK})

class Inspector(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.links=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.append(attrs['id'])
        if tag=='a':self.links.append(attrs.get('href',''))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');args=ap.parse_args()
    outputs={};coverage=[]
    for n in range(1,8):
        text,summary=page(n);outputs[HERE/f'part-{n}.html']=text;coverage.append(summary)
    outputs[HERE/'index.html']=outputs[HERE/'part-1.html']
    assigned=[qid for p in coverage for qid in p['questions']]
    assert len(assigned)==len(set(assigned))==len(BANK)==525
    for path,text in list(outputs.items()):
        parser=Inspector();parser.feed(text);assert len(parser.ids)==len(set(parser.ids)),path
        for link in parser.links:
            if link.startswith('#'):assert link[1:] in parser.ids,(path,link)
            else:
                target=(path.parent/unquote(urlsplit(link).path)).resolve()
                assert target in outputs or target.is_file(),(path,link)
    manifest=dict(scope='Selected repository editions 01–26; all seven parts of the existing bank',bank_sha256=hashlib.sha256((ROOT/'web/questions.json').read_bytes()).hexdigest(),quotes_sha256=hashlib.sha256((ROOT/'docs/quotes.json').read_bytes()).hexdigest(),review='Existing bank-derived reading reference plus authored study structure; no new independent semantic review claimed',parts=coverage)
    outputs[HERE/'coverage.json']=json.dumps(manifest,ensure_ascii=False,indent=2)+'\n'
    app=ROOT/'web/app.js';script=app.read_text(encoding='utf-8')
    generated='/* BEGIN GENERATED SOURCE INDEX */\nconst SOURCE_INDEX = '+json.dumps(source_index(),ensure_ascii=False,separators=(',',':'))+';\n/* END GENERATED SOURCE INDEX */'
    pattern=r'/\* BEGIN GENERATED SOURCE INDEX \*/.*?/\* END GENERATED SOURCE INDEX \*/'
    if re.search(pattern,script,flags=re.S):script=re.sub(pattern,lambda _:generated,script,flags=re.S)
    else:script=script.replace("'use strict';","'use strict';\n\n"+generated,1)
    outputs[app]=script
    for path,text in outputs.items():
        if args.check:assert path.read_text(encoding='utf-8')==text,f'Stale: {path}'
        else:path.write_text(text,encoding='utf-8',newline='\n')
    print(json.dumps(dict(status='checked' if args.check else 'built',parts=len(coverage),questions=len(assigned),reference_points=sum(p['reference_points'] for p in coverage)),ensure_ascii=False))

if __name__=='__main__':main()
