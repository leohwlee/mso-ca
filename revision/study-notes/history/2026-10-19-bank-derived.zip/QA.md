# Verification / 核驗

Date: 19 October 2026. Local implementation; no public release is claimed.

## Content and provenance / 內容與來源

- Seven reading parts map all 525 existing question IDs exactly once by Part.
  There are 2,449 statement-level rule/misconception references, with original
  scenario context, bilingual explanations and deciding quotations.
- Authored introductions and topic structures organize that existing material.
  Introductory comparisons copy true bank statements rather than inventing new
  legal summaries. Part 1 adds the source-backed three-stage laundering diagram;
  Part 6 retains its fourteen authored topics and seven existing diagrams.
- Each deciding quote resolves its document through `docs/catalog.json`, shows
  the actual original filename and the existing bank locator. Document 24's
  Chinese view retains the English quote/original and labels its study translation.
- The bank and quotes are unchanged. Their hashes are recorded in `coverage.json`.
  No question IDs, truths, options, answer indices, scoring or prior review
  verdicts were edited. The new reading reference is not an independent semantic
  re-review or certification of the entire official syllabus.
- Prior tracked UI/documentation bytes are preserved in
  `bank/audit/history/2026-10-19-before-study-design.zip`; the new maintenance
  record extends the history rather than changing earlier evidence hashes.

七部分均有導言、閱讀路線及主題分類，覆蓋現有525題的2,449項陳述對照，保留情境、
雙語解釋及原文引句。導入表格直接選用原題庫正確陳述；不是另行創作法律規則。
第1部分補上有來源的洗錢階段圖，第6部分保留原十四主題及七個流程圖。所有原件
引用依文件目錄顯示實際檔名；第24份中文材料保留英文來源並明示學習譯文。
本次沒有改題庫或歷史語義覆核，也不宣稱新一輪獨立覆核或完整考綱認證。

## UI / 界面

- The B blue-gray/ink-blue reference design is applied to all reading parts and
  the practice, exam, result/history, modal and theme surfaces using existing
  functions. Both reading and practice link by Part and selected language.
- Chinese, English and combined views were checked on every reading Part at
  actual widths 1440 and 390px: 42 combinations with no page or reference/table/
  diagram overflow. Additional actual-768px checks on Parts 1, 6 and 7 covered
  all three languages: nine combinations without page overflow. Observations:
  `.impeccable/review/reading-checks.json` and `tablet-checks.json`. After the
  introductory tables and context-heading fix, all seven combined-language pages
  were checked again at actual 1440/390px: fourteen combinations without overflow,
  recorded in `final-reading-checks.json`.
- An initial attempt to resize a non-current browser tab affected another tab;
  those duplicate-width observations were discarded. Only observed viewport
  widths are counted above. Viewport tests do not claim OS/browser zoom coverage.
- Actual practice answering was exercised at 390 and 1440px, including TC/EN/both,
  the next-question action, per-statement explanations and full source filenames.
  The dark theme was also exercised with combined language content. No page
  overflow or captured console errors/warnings were observed.
- An isolated local origin was used for the mock-exam test: 35 answer rows,
  question selection, next-question navigation, the unanswered-question submit
  warning, submission, results and 35 review items with source filenames. The
  generated test result is not a user score and was not written to the user's
  normal preview origin.
- Reading screenshots are representative viewports of long documents; practice
  captures include full question/answer pages. All captures are real browser
  renders in `.impeccable/review/`, not the option sketches. The answered practice
  capture was replaced with a fresh full-page capture at observed scrollY=0.
- Browser checks used the localhost preview. Direct `file:` navigation was
  blocked by the browser tool's URL policy, so no live file-protocol browser
  check is claimed. Embedded assets and relative repository links were checked
  by the generators.
- One mechanical Impeccable scan was run on the final UI targets. It found no
  low-contrast issues, one Part 1 heading-level skip (fixed to h2), and 14
  `reading-map` inset warnings. The latter are static cascade limitations:
  desktop items have 24px left padding; mobile removes the border and padding
  together. No detector ignores or second scan were used; no zero-findings
  claim is made.

已在真正的1440及390像素寬度，核對七部分乘三種語言的42種組合；另在768像素
核對第1、6及7部分的三種語言。未見頁面或內容框水平溢出。另實際測試手機及
桌面作答、解析、檔名引用、下一題及深色主題；模擬試在獨立本地位址測試交卷
及結果，測試成績不屬使用者成績。靜態設計檢查發現的標題層級問題已修正；
未宣稱機械檢查完全零提示。

## Build and checks / 建立與檢查

Passed: both reading generators' validation and deterministic `--check`; Go vet
and tests; all eight JavaScript behavior tests; all eleven Python tests; catalog,
active-scope and scope-render checks. The practice HTML was rebuilt locally.
The four historical audit checks passed against the preserved archive chain.
The fresh finish review found a context-heading truncation issue and an obscured
practice capture. Both were resolved and re-reviewed with a SHIP disposition in
`.impeccable/review/finish-review.md`. A regression test checks exemptions,
simplified-CDD applicability and unsuitable-premises conditions in both languages.

兩個閱讀建立工具的一致性檢查、Go、八項JavaScript、十一項Python、文件目錄及
現行範圍檢查通過；練習HTML已重新建立。四項歷史審核按保留存檔鏈重新檢查通過。
最終界面覆核發現的標題限定遺失及截圖遮擋問題均已修正，再覆核結論為可交付；
不等於重新覆核全部題庫語義。瀏覽器測試使用本地預覽，沒有宣稱直接檔案網址測試。
