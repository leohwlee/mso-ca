"""Source-bound recall comparisons. Full reviewed manuscript prose stays visible.

Evidence resolves to the original citations in the corresponding manuscript,
never to questions, options, answer explanations or the bank's quote ledger.
"""
from model import p
import importlib

PARTS={n:importlib.import_module(f'part{n}').PART for n in range(1,8)}
PANELS={n:{} for n in PARTS}

def evidence(*targets):
    refs=[]
    for n,sid,index in targets:
        s=next(s for s in PARTS[n]['sections'] if s['id']==sid)
        for ref in s['blocks'][index]['refs']:
            if ref not in refs:refs.append(ref)
    return refs

def row(tc,en,value_tc,value_en,condition_tc,condition_en):
    return [p(tc,en),p(value_tc,value_en),p(condition_tc,condition_en)]

def table(n,sid,key,tc,en,rows,refs,note=None,headers=None):
    PANELS[n].setdefault(sid,[]).append(dict(id=key,kind='table',title=p(tc,en),
        headers=headers or [p('概念／情境','Concept / situation'),p('必記區別','Remember the distinction'),p('條件及例外','Conditions and exceptions')],
        rows=rows,refs=refs,note=note))

PANELS[1]['money-laundering']=[dict(id='three-stages',kind='sequence',
    title=p('洗錢的三個常見階段','The three common stages of money laundering'),
    steps=[
        dict(term=p('Placement（存放）','Placement'),meaning=p('把犯罪現金放入金融體系。','Introduce criminal cash into the financial system.')),
        dict(term=p('Layering（分層交易）','Layering'),meaning=p('用多層複雜交易掩藏來源、截斷審計線索及提供匿名性。','Use complex layers of transactions to disguise origin, obscure the audit trail and provide anonymity.')),
        dict(term=p('Integration（整合）','Integration'),meaning=p('使犯罪財富重新出現為貌似合法的資產或業務收益。','Return criminal wealth as apparently legitimate assets or business proceeds.')),
    ], note=PARTS[1]['sections'][0]['blocks'][0]['points'][2],
    refs=evidence((1,'money-laundering',0))) ]

table(1,'terrorist-financing','ml-tf-pf','ML、TF及PF：不要只看資金來源','ML, TF and PF: origin is not the only concern',[
 row('洗錢（ML）','Money laundering (ML)','犯罪得益的來源被掩飾。','Disguises the criminal origin of proceeds.','財產可全部／部分、直接／間接代表得益；境外行為若在港會屬可公訴罪行也可涵蓋。','Property may represent proceeds wholly/partly, directly/indirectly; overseas conduct that would be indictable in Hong Kong may be covered.'),
 row('恐怖分子資金籌集（TF）','Terrorist financing (TF)','合法或非法來源均可能涉及；看用途、對象及法定心理要素。','Lawful or unlawful funds may be involved; purpose, recipient and statutory mental elements matter.','供恐怖行為使用的財產須有意圖或知情，不必實際使用；向恐怖分子／聯繫者提供或為其籌集時，知道或罔顧對方身分均可涵蓋。','Property for terrorist acts requires intent/knowledge, not actual use. Relevant provision/collection for a terrorist/associate covers knowledge or recklessness about that status.'),
 row('擴散融資（PF）','Proliferation financing (PF)','服務可能協助大規模毀滅武器及其運載方式。','Services may assist WMD and their means of delivery.','有合理理由相信或懷疑服務可能涉及PF便可能觸犯第526章；適用制裁禁令另須遵守。','Cap.526 covers belief or suspicion on reasonable grounds that services may be connected to PF; applicable sanctions prohibitions also apply.'),
],evidence((1,'money-laundering',0),(1,'terrorist-financing',0),(1,'legal-framework',0)))

table(1,'international','risk-lists','風險名單與制裁名單','Risk lists and sanctions lists',[
 row('FATF：呼籲採取行動','FATF: call for action','相稱的加強盡職審查；指定情況另有反制措施。','Proportionate EDD; countermeasures in specified cases.','按有關聲明及海關通函區分；具體地區名單保留通函日期，不能當作永久名單。','Distinguish the applicable statement/circular. Country lists are dated snapshots, not permanent lists.'),
 row('FATF：加強監察','FATF: increased monitoring','納入客戶整體風險評估。','Factor into the overall customer risk assessment.','單憑列名不會自動令每宗客戶關係必須EDD。','Listing alone does not automatically require EDD for every customer relationship.'),
 row('受指定人士／實體制裁','Designated-person/entity sanctions','依法凍結及禁止提供／處理資產等。','Statutory freezing and prohibitions on availability/dealing.','不能用「低風險」取代法定禁止；只有適用豁免／有效特許才可在其範圍內行事。','A low-risk rating does not override a prohibition; only act within applicable exemptions/valid licences.'),
],evidence((1,'international',0),(1,'sanctions',0)))

table(1,'cross-boundary-cash','cash-routes','跨境現金：三種申報路徑','Cross-boundary CBNIs: three declaration routes',[
 row('指明管制站入境','Arrival at a specified control point','總值超過HK$120,000：紅通道及書面申報。','Aggregate value above HK$120,000: red channel and written declaration.','「超過」不包括剛好120,000元；須按法定管有、未滿16歲及機場過境規則判斷。','“Above” excludes exactly HK$120,000; apply statutory possession, under-16 and airport-transit provisions.'),
 row('其他地方入境／離境','Other arrival / departure','應獲授權人員要求披露；披露管有大量CBNIs後須申報。','Disclose on an authorized officer’s request; declare after disclosing possession of a large quantity.','不是所有旅客在所有出入口一律自行作同一書面申報。','Do not turn the request-based route into one universal self-declaration rule for every traveller.'),
 row('非旅客方式輸入／輸出','Non-traveller import / export','大量CBNIs須事先電子申報。','Large quantities require advance electronic declaration.','依法合併貨物批次，適用貨物／轉運／郵包等豁除；法例沒有統一24小時期限。','Apply statutory batch aggregation and cargo/transit/postal exclusions; there is no universal 24-hour deadline.'),
],evidence((1,'cross-boundary-cash',0),(1,'cross-boundary-cash',1)))

table(2,'changes','licence-clocks','牌照事項：事先、當月及結業前後','Licence actions: prior approval, a month, and cessation',[
 row('新增董事／最終擁有人／合夥人','New director / ultimate owner / partner','事先取得書面批准。','Obtain written approval beforehand.','適用第35–37條的相應適當人選要求；一個月變更通知不能代替事先批准。','Apply the corresponding fitness test under ss.35–37; one-month notification does not replace prior approval.'),
 row('新營業處所／無處所轉特定處所','New premises / no-particular to particular premises','營業前批准並加入牌照。','Approval and licence registration before operation.','處所須適合；住宅佔用人同意等適用條件仍須符合。','Suitability and applicable domestic-occupant consent conditions remain necessary.'),
 row('續牌','Renewal','最遲屆滿前45日申請。','Apply at least 45 days before expiry.','按指定形式及費用作有效申請；有效申請待決時按第31條繼續有效，法定撤回／撤銷／暫停等情況另論。','Use the prescribed form/fees. A valid pending application continues validity under s.31, subject to statutory withdrawal/revocation/suspension and other outcomes.'),
 row('申請／續牌資料改變','Changed application / renewal particulars','改變當日起一個月內書面通知。','Written notice within one month beginning on the change date.','「一個月」不能自行改成30日；需事先批准的項目仍須事先批准。','Do not substitute “30 days” for “one month”; prior-approval events still require prior approval.'),
 row('停止全部業務／某指定處所','Cease all business / a specified premises','停止前通知；停止當日起計7日內交還牌照。','Notify before cessation; return the licence within seven days beginning on the cessation date.','屬第41條結業規則；第34條撤銷／暫停的交還期限依通知，不能直接套用7日。','This is s.41 cessation; s.34 revocation/suspension surrender follows the notice, not automatically seven days.'),
],evidence((2,'changes',0),(2,'grant-renewal',0),(2,'discipline',0)))

table(2,'discipline','penalty-ceilings','第21條與第43條：兩套罰款上限','Sections 21 and 43: two penalty ceilings',[
 row('第21條','Section 21','最高為HK$10,000,000與所得利益／避免成本3倍，兩者較大者。','Up to the greater of HK$10 million and three times profit gained / costs avoided.','針對指明CDD／紀錄等違規；補救期限後持續不遵從命令，可另處最高每日HK$100,000。','Specified CDD/record-related contraventions; continued non-compliance after the remedial deadline can attract up to HK$100,000 daily.'),
 row('第43條','Section 43','最高HK$1,000,000。','Up to HK$1 million.','發牌紀律處分；補救期限後持續不遵從命令，可另處最高每日HK$10,000。','Licensing discipline; continued non-compliance after the remedial deadline can attract up to HK$10,000 daily.'),
],evidence((2,'discipline',0)),p('兩者均是上限而非固定罰款；須依程序給予陳詞機會。罰款通常自決定生效起30日內或獲准較長期間繳付。','Both are ceilings, not fixed fines, and hearing procedures apply. Fines normally fall due within 30 days after the decision takes effect, or a longer allowed period.'))

table(2,'review','review-clocks','覆核：期限與暫緩是兩件事','Review: time limits and stays are distinct',[
 row('申請覆核','Apply for review','通常在通知送出後21日內，以書面列理由。','Normally within 21 days after the notice is sent, in writing with grounds.','起算是「送出」，不是收到；有充分因由可按法定程序申請延長。','The clock starts at sending, not receipt; a statutory extension may be sought for good cause.'),
 row('決定生效／暫緩','Commencement / stay','分清第75條生效安排及第69條暫緩申請。','Distinguish s.75 commencement from a s.69 stay application.','申請覆核本身不自動暫緩；公眾利益生效安排可能不同。上訴本身亦不自動暫緩。','Review does not itself stay execution; public-interest commencement may differ. Appeal also does not itself stay execution.'),
],evidence((2,'review',0)))

table(3,'core-duties','money-boundaries','金額相近，法律用途不同','Similar amounts, different legal purposes',[
 row('一般非經常交易CDD','General occasional-transaction CDD','等於或超過HK$120,000。','At least HK$120,000.','沒有業務關係的客戶，單次／看似有關連操作合併；持牌VASP的非轉移非經常交易另有8,000元規則。建立關係、懷疑或資料疑問另有無金額門檻的觸發。','For customers without a relationship; aggregate apparently linked operations. Licensed VAS providers have a separate HK$8,000 non-transfer occasional rule. Relationship, suspicion and doubt triggers have no monetary floor.'),
 row('非經常電傳／虛擬資產轉移CDD','Occasional wire / VA-transfer CDD','等於或超過HK$8,000。','At least HK$8,000.','金融機構適用；須考慮相連操作。低於門檻不等於電傳資料要求全免，懷疑／資料疑問仍觸發CDD。','For financial institutions; consider linked operations. Below-threshold wires are not exempt from all information duties; suspicion/doubts still trigger CDD.'),
 row('非電傳外匯款','Non-wire outward remittance','等於或超過HK$8,000。','At least HK$8,000.','附表2第13條的特定發款人核實及紀錄責任；不是把所有一般交易CDD門檻改成8,000元。','Specific originator-verification/record duties under Schedule 2 s.13; this does not change every general CDD threshold to HK$8,000.'),
 row('跨境現金類物品','Cross-boundary CBNIs','總值超過HK$120,000。','Aggregate value above HK$120,000.','第629章申報制度；正好120,000元不屬「超過」。按旅客／貨物路徑、管有及豁除條件判斷。','Cap.629 declaration regime; exactly HK$120,000 is not above it. Apply traveller/cargo routes, possession rules and exclusions.'),
 row('貨幣兌換商條例金額豁除','Cap.34 monetary exclusion','顧客交付款額超過HK$100,000，該交易不適用第34章。','Cap.34 excludes the transaction where the customer tenders more than HK$100,000.','正好100,000元仍在金額範圍；其他法定豁除另論。這不是AMLO的CDD豁免。','Exactly HK$100,000 remains in monetary scope, subject to other exclusions. This is not an AMLO CDD exemption.'),
],evidence((3,'core-duties',0),(1,'cross-boundary-cash',0),(4,'exchange-note',0)))

table(3,'definitions','ownership-boundary','實益擁有人：超過25%與控制權','Beneficial owners: more than 25% and control',[
 row('公司','Corporation','超過25%股本或大會投票權；或最終控制管理。','More than 25% share capital or general-meeting votes; or ultimate management control.','直接／間接均計；正好25%本身不符合擁有權門檻，仍須檢查控制。也包括交易為其進行的人。','Direct/indirect interests count. Exactly 25% alone misses the ownership threshold; still examine control and persons on whose behalf transactions occur.'),
 row('合夥','Partnership','超過25%資本／利潤或投票權；或最終控制管理。','More than 25% capital/profit or voting rights; or ultimate management control.','不能只找股份，或因未找到超過25%的人便停止查控制權。','Do not search only for shares or stop examining control when no person exceeds 25%.'),
 row('信託','Trust','既得資本權益、授予人、受託人、保障人／執行人及最終控制人。','Vested capital interests, settlors, trustees, protectors/enforcers and ultimate controllers.','信託不能套用公司的25%門檻；既得權益可為將來享有或可被終止的權益，依定義判斷。','Do not apply the corporate 25% threshold to trusts; vested interests can include future or defeasible interests under the definition.'),
],evidence((3,'definitions',1),(6,'beneficial-owners',0)))

table(3,'fees','fee-components','牌照費：基本費加附加項目','Licence fees: base plus additive components',[
 row('新牌申請','Grant application','HK$3,810基本費。','HK$3,810 base.','另每個額外營業處所HK$2,440；每名須評核人士HK$945。','Plus HK$2,440 per additional business premises and HK$945 per person subject to the fit-and-proper test.'),
 row('續牌','Renewal','HK$910基本費。','HK$910 base.','另每個額外營業處所HK$410；每名須評核人士HK$945。','Plus HK$410 per additional business premises and HK$945 per tested person.'),
 row('董事／最終擁有人／合夥人批准','Director / ultimate owner / partner approval','每人HK$945。','HK$945 per person.','是批准申請費，不能當作整個牌照申請的全部費用。','An approval application fee, not the total fee for a licence application.'),
 row('新增／改為特定營業處所','Add / move to particular premises','每個處所HK$2,440。','HK$2,440 per premises.','與續牌「額外處所」的HK$410不同；公開查閱登記冊免費，索副本另計。','Different from renewal’s HK$410 additional-premises component. Public register inspection is free; copies have separate charges.'),
],evidence((3,'fees',0)),p('金額按repo所存2026年綜合版本；實際申請須核對當時費表。','Amounts follow the stored 2026 consolidated edition; actual applications require the then-current fee schedule.'))

table(4,'premises','three-places','營業處所、LMO及LPS','Business premises, LMO and LPS',[
 row('營業處所','Business premises','供客戶交易的自有／租用、對外宣傳處所。','Owned/leased, advertised premises where customers transact.','不得全住宅、與另一MSO／申請人共用或須他人協助才可進入；商住混合須全體佔用人書面同意獲授權人員進入。','Not wholly residential, shared with another MSO/applicant or accessible only with others’ assistance; mixed premises need all occupants’ written consent to authorized entry.'),
 row('本地管理辦事處（LMO）','Local management office (LMO)','沒有特定營業處所者須維持，供海關聯絡。','Required for no-particular-premises operators, as a Customs contact point.','香港實體地址，親身及電話可聯絡，由合資格管理／合規人士駐守；非住宅或僅服務商地址。','Physical Hong Kong address, reachable in person/by phone and staffed by qualifying management/compliance personnel; not residential or merely a service-provider address.'),
 row('本地紀錄儲存地方（LPS）','Local place for storage (LPS)','所有申請人須維持，保存其控制的完整紀錄。','Required for all applicants, holding complete records under their control.','香港實體地址，非住宅或僅服務商地址。LMO與LPS名稱相似，但義務及用途不同。','Physical Hong Kong address, not residential or merely a service-provider address. LMO and LPS have different functions and coverage.'),
],evidence((4,'premises',0)))

PANELS[4].setdefault('assessment',[]).append(dict(id='assessment-pass',kind='pass-rule',
    title=p('合格要同時過兩關','Passing requires both gates'),
    facts=p('35題 · 7個Part · 每Part 5題 · 75分鐘 · 每題一個答案','35 questions · 7 Parts · 5 per Part · 75 minutes · one answer per question'),
    gates=[p('全卷最少25／35','At least 25 / 35 overall'),p('每個Part最多錯2題','No more than 2 wrong in every Part')],
    note=p('兩個條件須同時符合；例如總分32／35，但某Part只對2／5，仍不合格。評核合格亦不保證獲發或續牌。','Both conditions must hold. For example, 32/35 overall with only 2/5 correct in one Part still fails. Passing does not guarantee a licence or renewal.'),
    refs=evidence((4,'assessment',0))))

table(4,'assessment','assessment-clocks','相同數字，不同起算點','Same numbers, different starting events',[
 row('新牌評核','New-application assessment','面見海關後30日內。','Within 30 days after the Customs interview.','適用於申請人的合資格人士；須參加，不是隨意延後的建議。','For the applicant’s eligible nominees; this is an attendance requirement.'),
 row('續牌評核','Renewal assessment','收到邀請後30日內。','Within 30 days after receipt of invitation.','需要評核的續牌情況；亦須依通知作提名，不能混同屆滿前45日的續牌申請期限。','For renewal cases requiring assessment, with notice-based nomination; distinct from the 45-day renewal-application deadline.'),
 row('全部通過人士離任','All passing nominees leave','通知海關合夥／董事變更後30日內安排評核。','Arrange assessment within 30 days after notifying Customs of partnership/directorship change.','合夥／公司適用，獨資除外；180日內到期續牌的情況依續牌安排。','Applies to partnerships/corporations, not proprietorships; renewal within 180 days follows renewal arrangements.'),
 row('再次應考','Retake','結果通知後30日才可再考。','Retake after 30 days from result notification.','續牌重考須在牌照屆滿前；不是30日內重考，也不會自動延長牌照。','Renewal retakes must precede licence expiry; this is not “within 30 days” and does not extend the licence.'),
 row('結果通知','Result notification','評核後14日內，電郵通知PASS／FAIL。','Within 14 days after assessment, PASS/FAIL by email.','保留通知作成績證明；不披露分數及試題答案。','Retain it as evidence; exact scores and question answers are not disclosed.'),
 row('要求覆檢','Request rechecking','成績通知發出後7日內書面要求。','Write within seven days after result-notification issue.','不是收到後7日；逾期不受理。','The clock is issue, not receipt; late requests are not considered.'),
 row('覆檢回覆','Rechecking reply','收到覆檢要求後14日內書面回覆。','Written reply within 14 days after receipt of the rechecking request.','覆檢答案紀錄等技術錯誤；覆檢結果為最終。','Rechecks technical matters such as answer-recording errors; the result is final.'),
],evidence((4,'assessment',0),(4,'assessment',1),(4,'assessment',2)))

table(4,'exchange-note','exchange-rights','拒絕未完成交易與撤銷已完成交易','Declining an unfinished exchange versus rescinding a completed one',[
 row('完成前拒絕','Refusal before completion','立即全數退回顧客交來的款項。','Immediately return the full amount tendered.','是交易未完成時的拒絕權，不須等候3日。','This concerns an unfinished transaction; it is not a three-day waiting period.'),
 row('完成後撤銷','Rescission after completion','交易後3日內可依法撤銷。','Statutory rescission within three days after the transaction.','須涉及第4條違規；不是任何已完成兌換均有無條件3日反悔權。','Requires a section 4 breach; this is not an unconditional cooling-off right for every completed exchange.'),
],evidence((4,'exchange-note',0)),p('第34章另要求把正本交顧客，副本至少保留12個月；這不取代同時適用的AMLO備存紀錄要求。','Cap.34 also requires the original for the customer and duplicate retention for at least 12 months; this does not displace concurrently applicable AMLO records duties.'))

table(5,'risk-based','risk-levels','機構風險與客戶風險','Institutional risk and customer risk',[
 row('機構層面','Institutional level','評估整個業務暴露的風險，設計制度及資源。','Assess business-wide exposure to shape systems and resources.','客戶、地區、產品／服務／交易、渠道及其他風險均須考慮；規模小可簡化方法，不是免評估。','Consider customer, country, product/service/transaction, channel and other risks. A small business may use a simpler method, not omit assessment.'),
 row('客戶層面','Customer level','判定個別客戶／關係的CDD及持續監察程度。','Set CDD and ongoing-monitoring intensity for the individual customer/relationship.','初期評估決定審查程度，統合CDD資料後定案，並隨風險改變更新；不能只靠國籍或單一分數。','Initial assessment sets CDD extent; finalise holistically with CDD information and update as risk changes, not solely by nationality or one score.'),
],evidence((5,'risk-based',0),(5,'customer-assessment',0)))

table(5,'institutional-assessment','review-frequency','兩年、每年、事前：覆核節奏不可互換','Two-yearly, annual, before launch: do not interchange review clocks',[
 row('機構風險評估','Institutional risk assessment','每兩年及重大觸發事件時。','Every two years and upon material triggers.','新客戶組別／渠道／產品、重大流程／對手改變或嚴重違規可觸發；不是未滿兩年便毋須重做。','New segments/channels/products, material process/counterparty changes or significant breaches may trigger review before two years.'),
 row('新產品／渠道／科技','New products / channels / technology','推出或使用前先評估並緩解風險。','Assess and mitigate before launch/use.','包括現有產品使用新／發展中科技；不是只適用全新產品。','Includes new/developing technology for existing products, not only entirely new products.'),
 row('高風險客戶CDD資料','High-risk customer CDD records','至少每年覆核，另按事件更新。','Review at least annually, with event-driven updates.','持續監察並非每年才做一次；一般客戶不因這項規則一律有相同年度週期。','Ongoing monitoring is not an annual-only task; this does not impose the same universal annual cycle on every customer.'),
 row('獨立審核','Independent audit','定期，頻率／程度按業務及風險。','Regular, with frequency/extent based on business and risk.','沒有所有機構一律每年或每兩年的固定審核期限。','No single annual or two-year audit deadline applies universally.'),
],evidence((5,'institutional-assessment',1),(5,'new-business',0),(6,'monitoring',0),(7,'independent-audit',0)))

table(5,'roles','governance-roles','Senior management、CO與MLRO','Senior management, CO and MLRO',[
 row('高級管理層','Senior management','理解及管理風險、落實制度、作所需批准及委任。','Understand/manage risk, implement controls, make required approvals and appointments.','在切實可行範圍內，確保CO／MLRO具備適當權力、資訊、資源及與管理層的溝通渠道。','As far as practicable, ensure appropriate authority, information, resources and management access for CO/MLRO.'),
 row('合規主任（CO）','Compliance Officer (CO)','制度設立／持續覆核、成效監察、改善及培訓。','Establish/review systems, monitor effectiveness, improve and ensure training.','管理層級人員；須把重要合規問題呈報管理層。','Management-level appointment; communicate significant compliance issues to management.'),
 row('洗錢報告主任（MLRO）','Money Laundering Reporting Officer (MLRO)','收取及評估內部披露，決定是否向JFIU報告並保留理由。','Receive/evaluate internal disclosures, decide JFIU reporting and retain reasons.','須能接觸相關資料並指導避免通風報訊；不能由無合規職責主管截報。','Needs relevant-information access and guides against tipping off; managers without compliance/reporting duties must not filter reports.'),
],evidence((5,'roles',0),(5,'roles',1),(5,'roles',2),(7,'internal-report',0)),p('可按規模由同一人兼任CO及MLRO，但兩套責任均保留。CO／MLRO須是僱員，獨資經營者、合夥人、董事或最終擁有人擔任者除外；資格、權力、資訊及資源要求仍須符合。','CO and MLRO may be combined according to size, retaining both responsibilities. They must be employees unless the proprietor, partner, director or ultimate owner holds the role; competence, authority, information and resources still matter.'))

table(6,'cdd','four-cdd-measures','CDD四項基本措施','The four basic CDD measures',[
 row('客戶','Customer','識別並用可靠獨立來源核實。','Identify and verify using reliable independent sources.','法人客戶與櫃台代表是不同的人；只核實代表不等於核實法人。','A corporate customer differs from its counter representative; verifying the latter does not verify the corporation.'),
 row('實益擁有人','Beneficial owner','識別並採合理措施核實。','Identify and take reasonable verification measures.','有實益擁有人時適用；法人／信託須了解擁有權及控制結構，指定法定簡化例外另論。','Applies where there is a BO; understand legal-person/trust ownership/control, subject to specified statutory simplification exceptions.'),
 row('目的及擬具有的性質','Purpose and intended nature','取得業務關係目的及性質資料。','Obtain relationship-purpose/intended-nature information.','已顯而易見者毋須另取；非自然人客戶亦須了解業務性質。','Unless obvious; also understand the business nature of non-individual customers.'),
 row('代表人（PPTA）','Person purporting to act (PPTA)','識別及合理核實身分，另核實授權。','Identify/reasonably verify identity, and separately verify authority.','有人代表客戶行事才適用；身分和授權是兩項核查，不能互相取代。','Applies when someone acts for the customer; identity and authority are separate checks, not substitutes.'),
],evidence((6,'cdd',0),(6,'cdd',1)))

table(6,'identity','party-roles','客戶、實益擁有人、代表及關連人士','Customer, beneficial owner, representative and connected party',[
 row('客戶','Customer','與MSO建立關係，或由MSO為其執行交易的一方。','Party entering the relationship or for whom the MSO transacts.','交易第三方通常不自動是本機構客戶；法律實體本身仍須識別及核實。','Transaction third parties are not automatically its customers; identify/verify the legal entity itself.'),
 row('實益擁有人（BO）','Beneficial owner (BO)','最終擁有／控制或交易為其進行的自然人。','Individual ultimately owning/controlling or for whom the transaction occurs.','公司／合夥的超過25%及控制替代條件、信託特別定義均須檢查；不能只看名義戶名。','Examine corporate/partnership over-25% and alternative control tests and trust-specific definitions, not just account names.'),
 row('代表人（PPTA）','Representative (PPTA)','替客戶行事的人。','Person acting for the customer.','取得適用識別資料、合理核實及核實授權；不是每名董事／BO都必須親身開戶。','Obtain relevant identity data, reasonably verify and check authority; not every director/BO must attend opening.'),
 row('關連人士','Connected party','例如董事、合夥人、受託人等適用人士。','Applicable directors, partners, trustees and other specified persons.','須取得姓名；若兼任客戶、BO或PPTA，另按該角色作適用識別／核實，不能只記姓名。','Obtain names; overlapping customer, BO or PPTA roles attract their applicable checks, not name collection alone.'),
],evidence((6,'cdd',1),(6,'identity',1),(6,'beneficial-owners',0),(6,'representatives',1)))

table(6,'enhanced','sow-sof','SOW與SOF：財富與本次資金','SOW and SOF: accumulated wealth and specific funds',[
 row('財富來源（SOW）','Source of wealth (SOW)','整體財富／資產如何累積。','How the overall body of wealth/assets was accumulated.','例如事業、投資及繼承；按風險取得及核對資料，並非每宗都須追溯同一長度歷史。','For example business, investment or inheritance; obtain/corroborate proportionately, not an identical historical lookback in every case.'),
 row('資金來源（SOF）','Source of funds (SOF)','這次關係／交易的特定資金由甚麼活動產生。','The activity generating the specific funds in this relationship/transaction.','只知道從哪家銀行匯出並不足夠；銀行是傳送渠道，不等於已確立資金的產生來源。','The sending bank’s name alone is insufficient; a transmission route does not establish the generating source.'),
],evidence((6,'enhanced',1),(6,'identity',2)),p('法例要求確立SOW及SOF時，須兩者處理；不是在兩者之間任選一個。措施程度仍須與風險相稱。','Where law requires establishment of SOW and SOF, address both, not a choice of one; calibrate the extent to risk.'))

table(6,'simplified','due-diligence-levels','普通、簡化及加強審查','Ordinary, simplified and enhanced due diligence',[
 row('普通CDD','Ordinary CDD','按適用情況完成四項措施並持續監察。','Perform the four measures where applicable, with ongoing monitoring.','以風險決定資料及核實程度；不是只有高風險才做CDD。','Risk determines information/verification extent; CDD is not limited to high-risk customers.'),
 row('一般低風險簡化','General low-risk simplification','有足夠分析支持低風險，措施相稱地減省。','Proportionate reductions supported by adequate low-risk analysis.','不自動豁免BO或全部CDD；仍須監察，風險不再屬低風險、懷疑或身分資料疑問時停止簡化。','No automatic BO/all-CDD waiver. Monitoring remains; stop simplification when risk is no longer low, or on suspicion or identity-information doubts.'),
 row('附表2第4條BO例外','Schedule 2 s.4 BO concession','只在指定客戶／產品／帳戶等條件下省去指定BO措施。','Omit specified BO measures only for qualifying customers/products/accounts.','其餘客戶／代表／目的性質措施仍適用；擁有權鏈只在合資格實體及以上部分停止追查。','Other customer/representative/purpose measures remain; the chain concession stops enquiries only at/beyond the qualifying entity.'),
 row('其他高風險關係','Other high-risk relationship','必須先有高級管理層批准；另外二選一：確立SOW及SOF，或採取其他額外緩解措施。','Senior approval PLUS either SOW and SOF establishment or other additional mitigation.','繼續現有關係另須合理核實BO；高風險非經常交易須額外緩解。特定PEP措施不能用此選擇取代。','Continuing relationships additionally require reasonable BO verification; high-risk occasional transactions need additional mitigation. This choice does not replace prescribed PEP measures.'),
],evidence((6,'simplified',0),(6,'simplified',1),(6,'enhanced',0),(6,'enhanced',2)))

table(6,'peps','pep-categories','PEP類別與加強措施','PEP categories and enhanced measures',[
 row('非香港PEP','Non-Hong Kong PEP','建立／繼續關係前：高級管理層批准、合理確立SOW及SOF、加強持續監察。','Before establishment/continuation: senior approval, reasonable SOW and SOF establishment and enhanced ongoing monitoring.','包括客戶或其BO；並非三選一。現有關係後來才發現PEP身分也須處理。','Covers customer/BO; these are not alternatives. Later discovery within an existing relationship also requires action.'),
 row('香港／國際組織PEP','Hong Kong / international-organisation PEP','高風險關係須上述全部加強措施。','All those enhanced measures for high-risk relationships.','建立時高風險、後來變高風險，或高風險關係後來發現PEP身分均涵蓋；本地PEP不自動一律高風險。','Covers high risk at establishment, later becoming high risk, or PEP discovery in a high-risk relationship. Domestic status is not universally high risk.'),
 row('前PEP','Former PEP','離任不會自動取消措施，也沒有通用「過幾年就免」期限。','Leaving office does not automatically end measures; there is no universal elapsed-years exemption.','適當評估剩餘影響等，確定不再高風險並獲管理層批准，才可停止指定EDD；須記錄理由。','Only cease prescribed EDD after appropriate assessment finds no remaining high risk and senior approval; retain reasons.'),
],evidence((6,'peps',0),(6,'peps',1)),p('PEP範圍亦包括適用家庭成員及密切聯繫者；中／初級人員不因一般職位便成為PEP。','PEP scope also includes applicable family and close associates; ordinary middle/junior roles do not themselves qualify.'))

table(6,'wire-transfers','transfer-information','電傳與非電傳匯款：8,000元的不同作用','Wire and non-wire remittance: different roles of HK$8,000',[
 row('跨境電傳：≥HK$8,000','Cross-border wire: ≥HK$8,000','雙方姓名及戶口／參考號碼，加發款人額外識別資料。','Both names and account/reference identifiers, plus additional originator identification information.','額外項為地址、客戶識別碼、證件號碼或自然人出生日期及地點其中一項；所需發款人資料須準確，適用CDD亦須完成。','Additional item: address, customer ID, document number, or individual date/place of birth. Required originator information must be accurate and applicable CDD performed.'),
 row('跨境電傳：<HK$8,000','Cross-border wire: <HK$8,000','仍附雙方姓名及戶口／參考號碼。','Still carry both names and account/reference identifiers.','非經常發款人一般毋須核實，但相連總額達門檻、有懷疑或對原有身分資料有疑問時仍須核實；不是無資料規定。','An occasional originator generally need not be verified unless linked totals meet the threshold, suspicion arises or previous identity information is doubted; not an information-free transfer.'),
 row('非電傳外匯款：≥HK$8,000','Non-wire outward remittance: ≥HK$8,000','執行前以法定識別文件識別／核實發款人，並記錄指定資料。','Identify/verify the originator by statutory identification document and record specified data before execution.','記姓名、證件號碼（旅行證件加簽發地）、地址、幣種金額、指示日期時間、受款人姓名地址及交付方式。','Record name, document number (plus travel-document issue place), address, currency/amount, instruction date/time, recipient name/address and delivery method.'),
 row('本地電傳資料例外','Domestic-wire information exception','發款人資料可簡化為可追蹤的發款人戶口號碼；如無戶口，則用獨特參考號碼。所需受款人資料仍須隨附。','Originator data may be shortened to a traceable originator account number, or a unique reference where no account exists. Required recipient data must still accompany the transfer.','須應接收電傳指示的機構或關長要求，在收到要求後3個營業日內提供完整發款人資料；應執法機構要求則立即提供。經海外中介機構便不屬此本地電傳例外。','Supply full originator data within three business days after receiving a request by the institution receiving the instructions or the CCE, and immediately on law-enforcement request. An overseas intermediary prevents this domestic exception.'),
],evidence((6,'wire-transfers',1),(6,'wire-receiving',0),(6,'remittances',0),(6,'remittances',1)),p('先辨識發出、中介或受益機構角色；機構間各為自己行事及卡交易等豁除須符合全部條件。批量轉帳有指定資料例外，並非所有電傳都可只留一個編號。','Identify the ordering, intermediary or beneficiary role first. Own-account institutional and card exclusions require all conditions. Batch transfers have specified exceptions; not every wire may carry only one reference.'))

table(6,'intermediaries','reliance-outsourcing','依賴中介人與外判','Intermediary reliance and outsourcing',[
 row('依賴合資格中介人','Reliance on a qualifying intermediary','中介人通常有獨立的既有客戶關係及程序。','The intermediary usually has an existing independent customer relationship/procedures.','須合資格、書面同意、立即取得CDD資料並可按要求無延誤取得支持文件；MSO責任不轉移。','Eligibility, written consent, immediate CDD data and supporting-record availability without delay are required; MSO liability remains.'),
 row('外判／代理','Outsourcing / agency','按MSO程序及其控制執行。','Acts under the MSO’s procedures/control.','與法定中介人依賴不同；不能因此移轉CDD責任。第5條持續監察仍由MSO負責。','Different from statutory reliance; CDD liability is not transferred. Schedule 2 s.5 ongoing monitoring remains with the MSO.'),
],evidence((6,'intermediaries',0),(6,'intermediaries',1)))

table(7,'retention','retention-clocks','保存期：記「多久」也要記「何時開始」','Retention: remember the duration AND its starting event',[
 row('業務關係CDD','Relationship CDD','關係全程＋結束日起至少5年。','Throughout the relationship PLUS at least five years beginning when it ends.','不能從開戶日起算5年後便刪除。關長書面要求更長期限時須延長。','Do not delete five years after opening. Extend for a longer CCE written requirement.'),
 row('達CDD門檻的非經常交易CDD','CDD for threshold occasional transactions','交易完成日起至少5年。','At least five years beginning on transaction completion.','附表2第20(3A)條；相關8,000／120,000元觸發條件須按交易類型判斷。','Schedule 2 s.20(3A); apply the relevant HK$8,000/HK$120,000 triggers by transaction type.'),
 row('交易紀錄','Transaction records','每宗交易完成日起至少5年。','At least five years beginning when each transaction is completed.','期間關係結束不縮短保存期；不能一律把起算點改成關係結束。','Relationship termination during that period does not shorten it; do not replace the starting event universally with relationship end.'),
 row('培訓紀錄','Training records','至少3年。','At least three years.','保存受訓者、日期及類型；與CDD／交易的5年規則不同。','Keep trainee, date and type; distinct from the five-year CDD/transaction rule.'),
],evidence((7,'retention',0),(7,'retention',1)),p('中介人保存紀錄不免除MSO責任；境外儲存亦須符合香港規定。未獲接納申請的一般AMLO紀錄義務與其他舉報責任須分開判斷。','Intermediary retention does not discharge the MSO; offshore storage must meet Hong Kong requirements. Distinguish unsuccessful applicants’ ordinary AMLO record position from other reporting duties.'))

table(7,'after-report','report-consent-defence','STR、同意與法定抗辯','STR, consent and statutory defence',[
 row('提交STR','File an STR','有知悉／懷疑便在合理情況下盡快披露。','Disclose knowledge/suspicion as soon as reasonable.','無最低金額；嘗試／未完成交易也可觸發；不能等收齊全部資料才報。','No minimum value; attempted/uncompleted activity can trigger reporting. Do not delay for complete information.'),
 row('JFIU同意','JFIU consent','不是戶口或交易的「無風險證明」。','Not a clean bill of health for the account or transaction.','不免除其他法律／監管／聲譽風險；仍須覆核、緩解及考慮後續STR。','Other legal/regulatory/reputational risks remain; review, mitigate and consider further STRs.'),
 row('法定抗辯','Statutory defence','事前披露並取得同意後行事；或事後主動在合理情況下盡快披露。','Prior disclosure and action with consent, or later disclosure on one’s own initiative as soon as reasonable.','須符合相應法定條件；「交了STR」本身不等於無條件免責。','The statutory conditions must hold; filing alone is not unconditional immunity.'),
],evidence((7,'reporting-duty',0),(7,'internal-report',0),(7,'after-report',0)))

table(7,'periodic-return','return-period-deadline','半年資料期間，不是半年提交寬限期','A half-year data period is not a half-year filing extension',[
 row('資料涵蓋期','Data period','每年兩次：1–6月及7–12月。','Twice yearly: January–June and July–December.','按第15份通函改為半年制；使用MSOS電子提交，不接受紙本。','Document 15 changes the former quarterly regime; submit through MSOS electronically, not on paper.'),
 row('提交期限','Filing deadline','每個半年度開始起兩星期內。','Within two weeks beginning each half-year.','申報上個半年度；除非關長另以書面指定。不是半年結束後還可再等半年。','Report the preceding half-year unless the CCE specifies otherwise in writing; not another six-month extension.'),
],evidence((7,'periodic-return',0),(7,'periodic-return',1)))

# Selective lexical anchors; values/qualifiers are emphasized only as complete units.
# Full paragraph text is never rewritten, shortened or made dependent on this mapping.
EMPHASIS={
 'tc':['存放','分層交易','分層','整合','財富來源','資金來源','實益擁有人','非經常交易','高級管理層批准','合規主任','洗錢報告主任','法定抗辯','通風報訊','每兩年','至少每年','至少5年','至少3年','至少12個月'],
 'en':['Placement','Layering','Integration','source of wealth','source of funds','beneficial owner','occasional transaction','senior approval','senior management approval','Compliance Officer','Money Laundering Reporting Officer','statutory defence','tipping off','every two years','at least annually','at least five years','at least three years','at least 12 months'],
}
