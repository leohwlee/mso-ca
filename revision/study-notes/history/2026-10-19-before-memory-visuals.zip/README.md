# Seven-part study notes / 七部分溫習筆記

Open [index.html](index.html) and select Part 1–7. These are source-authored,
bilingual reading notes in the approved B blue-gray annotated-reference style.
The purpose is to learn the concepts and rules directly from the notes.

開啟 [index.html](index.html)，選擇 Part 1–7。筆記直接從01–26份原文整理概念、
定義、要求、條件及例外，讓日常複習毋須逐份翻原文；保留已選定的B風格，
提供繁體中文、英文及雙語閱讀。

## Content / 內容

- Concepts and declarative topic headings replace question stems and answer
  explanations. Requirements retain actors, thresholds, timing and exceptions.
- The original editions are resolved through `docs/catalog.json`. Citations show
  actual repo filenames and paragraph/section/page locators. Source 24 has no
  official Chinese edition: its Chinese material is labelled a study translation
  and links to the English original.
- Publication-specific findings retain their dates, especially the 2022 risk
  assessment and dated FATF circular. This does not claim a live update of laws
  or country lists beyond the stored editions.
- The existing 525-question bank is used only in a separate, post-authoring gap
  pass. It supplies no reading-page headings, options, statements or explanations.
- Definitions and core legal duties are in Parts 1–3; licensing/assessment in
  Part 4; institutional governance in Part 5; operational CDD/monitoring/transfers
  in Part 6; reporting/records/audit/training/returns in Part 7. A subject can be
  relevant to questions in more than one Part.

正文不再用題幹作標題，亦不把真假陳述或答案解釋包裝成筆記。引用仍可用於核對
細節；第24份學習譯文明示來源為英文。不同Part有交叉主題，應按全套筆記理解。
題庫只作事後查漏，題目、答案、評分及歷史證據均未更改。

## Maintain / 維護

`part1.py`–`part7.py` hold the authored manuscripts. Each block contains bilingual
points and original-source references. `build.py` validates references and renders
the pages without reading the question or quote bank. `gap_check.py` separately
checks the bank's source routes and records the topics supplemented during the
gap pass. Source overlap is not a claim of statement-level semantic completeness.

`part1.py`至`part7.py`保存雙語文稿；`build.py`只讀文稿及原文目錄生成網頁。
`gap_check.py`另外執行題庫查漏；自動來源對應不等於逐項語義覆蓋證明。

```text
python revision/study-notes/build.py
python revision/study-notes/gap_check.py
python revision/study-notes/build.py --check
python revision/study-notes/gap_check.py --check
```

Keep this folder inside the repository for original-file and practice links.
Styles and the bundled DM Sans font are embedded; reading itself is offline.
See [QA.md](QA.md), [coverage.json](coverage.json) and [gap-audit.json](gap-audit.json).
The earlier bank-derived version is preserved only as
[a historical ZIP](history/2026-10-19-bank-derived.zip). The separate Part 6 sample
is an earlier design sample; these seven pages are the current reading material.

保留在repo內可使用原件及練習連結；字型與樣式嵌入頁面，閱讀本身毋須網絡。
舊版只保留於歷史壓縮檔；舊Part 6樣章不作本版正文。未作公開發佈。
