"""Source-authored bilingual manuscript; source-checked 2026-10-19. No bank input."""
from model import p, ref, block, section

PART = dict(title=p('有關打擊洗錢及恐怖分子資金籌集與打擊擴散資金籌集的常識', 'General knowledge on AML/CFT and Counter Proliferation Financing'),
intro=p('理解資金如何被濫用、香港的法律與風險背景，以及制裁和跨境現金申報的作用。', 'Understand how funds are misused, Hong Kong’s legal and risk context, and the roles of sanctions and cross-boundary cash declarations.'), sections=[
section('money-laundering', '洗錢：犯罪得益及三個階段', 'Money laundering: criminal proceeds and three stages', [
    block('定義與過程', 'Definition and process', [
        ('洗錢是把犯罪得益偽裝成合法財產的過程；包括處理明知或有合理理由相信代表犯罪得益的財產。財產本身不一定看來可疑，亦不限於現金。', 'Money laundering disguises criminal proceeds as legitimate property. It includes dealing with property known or reasonably believed to represent criminal proceeds. The property need not look suspicious and is not limited to cash.'),
        ('存放：把犯罪現金放入金融體系，例如分拆存款或兌換。分層：透過多次轉移、不同帳戶或司法管轄區掩藏來源。整合：使資金以投資、資產或業務收益等形式重新出現為合法財富。', 'Placement introduces criminal cash into the financial system, for example through split deposits or exchange. Layering obscures its origin through transfers, accounts or jurisdictions. Integration returns it as apparently legitimate investments, assets or business income.'),
        ('三個階段是理解典型模式的工具，實際交易可同時涉及多個階段。匯款或兌換業務可能協助存放及分層，交易有商業外觀也不表示資金合法。', 'The stages explain typical patterns; actual transactions can overlap them. Remittance and exchange can facilitate placement and layering, and a commercial appearance does not establish legitimacy.'),
    ], [
        ref('03', '第1.9–1.10段', '¶1.9–1.10', 'Placement - the disposal'),
    ], kind='list'),
    block('財產及境外犯罪得益的涵義', 'Property and proceeds from overseas conduct', [
        ('AMLO的財產不限於現金，也包括貨品、據法權產及土地，不論在香港或境外；以及由該等財產產生的義務、地役權、各類產業／權益／收益，無論現在或將來、既得或或有。洗錢不能只以有沒有實體鈔票判斷。', 'AMLO property includes money, goods, choses in action and land in Hong Kong or elsewhere, and associated obligations, easements, estates, interests and profits, present/future and vested/contingent. Choses in action are rights enforceable by legal action; laundering is not limited to physical banknotes.'),
        ('洗錢定義涵蓋香港可公訴罪行所得，以及若在香港發生便會構成可公訴罪行的境外行為所得；財產可全部／部分、直接／間接代表得益。「境外所得」並不自動免除香港洗錢風險。', 'The ML definition covers proceeds of Hong Kong indictable offences and overseas conduct that would constitute an indictable offence in Hong Kong. Property may represent proceeds wholly/partly and directly/indirectly. Overseas origin does not by itself remove Hong Kong laundering risk.'),
    ], [
        ref('04', '附表1第1部第1條', 'Schedule 1 Part 1 s.1', 'choses in action'),
        ref('03', '第1.9段', '¶1.9', 'not to appear to be or so represent such proceeds'),
    ], kind='list'),
]),
section('terrorist-financing', '恐怖分子資金籌集：合法資金也可被濫用', 'Terrorist financing: legitimate funds can also be misused', [
    block('與洗錢的分別', 'Distinction from money laundering', [
        ('恐怖分子資金籌集包括：有意圖或知道財產會全部／部分用於恐怖主義行為而提供／籌集財產，不論是否實際使用；向某人提供財產／金融或相關服務，或為其利益籌集財產／要求服務，而知道或罔顧該人是否恐怖分子或聯繫者。可直接或間接進行，不能只看資金來源。', 'TF includes providing/collecting property intending or knowing it will be used wholly/partly for terrorist acts, whether actually used or not; making property or financial/related services available to a person, or collecting property/soliciting services for their benefit, knowing or reckless as to whether they are a terrorist/associate. Direct and indirect activity is covered; origin alone is insufficient.'),
        ('洗錢著重犯罪得益的來源；恐怖活動可以由合法收入、捐款或犯罪收入資助。金額小、來源合法或經註冊組織轉移，均不能自動排除恐怖分子資金籌集風險。', 'Money laundering concerns the criminal origin of proceeds. Terrorist activity may be funded by legitimate income, donations or crime. Small amounts, lawful origins or transfers through registered organisations do not automatically exclude TF risk.'),
    ], [
        ref('03', '第1.11–1.12、1.23–1.25段', '¶1.11–1.12, 1.23–1.25', 'terrorist financing'),
    ], kind='list'),
    block('理解：合法資金也可被用於恐怖融資', 'Understand: lawful funds can finance terrorism', [
        ('2022年報告第8章說明，資金可來自捐款、會員費、商業收益或犯罪；轉移可經銀行、MSO、現金攜帶者或其他渠道。資金來源合法不代表用途或受益對象合法，評估仍須連同人物、目的、地區及交易背景。', 'Chapter 8 of the 2022 report discusses donations, membership fees, commercial income and crime as possible sources, with banks, MSOs, cash couriers and other channels for movement. Lawful origin does not establish lawful purpose or beneficiary; assess persons, purpose, geography and transaction context together.'),
        ('報告把香港非牟利組織（NPO）的TF脆弱程度評為低；較易被濫用的是在香港運作及籌款、支援衝突地區人道服務的組織。原文也列出緩減因素：不少屬國際網絡、具內部盡職審查，捐款大多可追蹤，並有匿名捐款風險評估及銀行監察。這是2022年報告的評估，不能因此把所有慈善團體列為高風險，亦不是現時地區評級。', 'The report rates Hong Kong non-profit organisations’ (NPOs’) inherent TF vulnerability low. Greater exposure concerns organisations operating and raising funds in Hong Kong to support humanitarian services in conflict zones. It also identifies mitigation: many belong to international networks with internal due diligence, donations are mostly traceable, and anonymous-donation risk assessment and bank monitoring apply. These are findings in the 2022 report, not grounds to classify every charity as high risk or current geographical ratings.'),
    ], [
        ref('25', '2022年版，第8.5、8.11、8.27–8.32段', '2022 edition, ¶8.5, 8.11, 8.27–8.32', 'CHAPTER 8'),
    ], kind='list'),
]),
section('legal-framework', '香港法律：各條例處理的問題', 'Hong Kong’s laws: the role of each ordinance', [
    block('六組核心法例', 'Six core legal frameworks', [
        ('第615章《打擊洗錢及恐怖分子資金籌集條例》（AMLO）：訂明客戶盡職審查、備存紀錄、監管及金錢服務經營者發牌制度。第405章《販毒（追討得益）條例》（DTROP）及第455章《有組織及嚴重罪行條例》（OSCO）：處理犯罪得益、披露、調查、限制及沒收。', 'Cap.615 AMLO establishes CDD, record-keeping, supervision and MSO licensing. Cap.405 DTROP and Cap.455 OSCO address criminal proceeds, disclosure, investigation, restraint and confiscation.'),
        ('第575章《聯合國（反恐怖主義措施）條例》（UNATMO）：恐怖分子財產、相關服務及披露。第537章《聯合國制裁條例》（UNSO）：在香港實施聯合國安全理事會決議所要求的制裁。第526章《大規模毀滅武器（提供服務的管制）條例》：管制可能協助大規模毀滅武器發展、生產、獲取、儲存及運載方式的服務；有合理理由相信或懷疑服務可能涉及擴散融資時，禁止提供。', 'Cap.575 UNATMO addresses terrorist property, related services and disclosure. Cap.537 UNSO implements sanctions required by UN Security Council resolutions. Cap.526 controls services that will/may assist WMD development, production, acquisition, stockpiling or delivery, and prohibits services where the provider believes or suspects on reasonable grounds that they may be connected to PF.'),
        ('第405／455章的洗錢罪最高可罰款500萬元及監禁14年；不披露知悉／懷疑事項最高可罰款5萬元及監禁3個月；通風報訊最高可監禁3年。恐怖分子資金籌集相關罪行可監禁14年及罰款。須分清犯罪、披露及監管處分是不同責任。', 'The DTROP/OSCO laundering offence carries up to HK$5 million and 14 years. Failure to disclose carries up to HK$50,000 and three months; tipping-off up to three years. Relevant TF offences carry up to 14 years and a fine. Criminal liability, disclosure duties and regulatory sanctions are distinct.'),
    ], [
        ref('03', '第1.14–1.28、6.1–6.4段', '¶1.14–1.28, 6.1–6.4', 'imprisonment for 14 years'),
    ], kind='list'),
    block('六項法例的英文全名及常用縮寫', 'Full names behind the six legal abbreviations', [
        ('AMLO是第615章《打擊洗錢及恐怖分子資金籌集條例》；DTROP是第405章《販毒（追討得益）條例》；OSCO是第455章《有組織及嚴重罪行條例》。不要把一般犯罪得益的洗錢責任只限於毒品得益。', 'AMLO: Anti-Money Laundering and Counter-Terrorist Financing Ordinance, Cap.615. DTROP: Drug Trafficking (Recovery of Proceeds) Ordinance, Cap.405. OSCO: Organized and Serious Crimes Ordinance, Cap.455. Laundering liability for indictable-crime proceeds is not confined to drug proceeds.'),
        ('UNATMO是第575章《聯合國（反恐怖主義措施）條例》；UNSO是第537章《聯合國制裁條例》；WMD(CPS)O是第526章《大規模毀滅武器（提供服務的管制）條例》。三者分別涉及反恐措施、聯合國制裁及可能協助大規模毀滅武器的服務，不能混成同一項禁令。', 'UNATMO: United Nations (Anti-Terrorism Measures) Ordinance, Cap.575. UNSO: United Nations Sanctions Ordinance, Cap.537. WMD(CPS)O: Weapons of Mass Destruction (Control of Provision of Services) Ordinance, Cap.526. Their counter-terrorism, UN-sanctions and WMD-service controls are distinct.'),
    ], [
        ref('03', '第1.14、1.19–1.27段', '¶1.14, 1.19–1.27', 'Drug Trafficking (Recovery of Proceeds)'),
    ], kind='list'),
]),
section('international', 'FATF與司法管轄區風險', 'FATF and jurisdiction risk', [
    block('標準、名單與法律須分開理解', 'Distinguish standards, lists and law', [
        ('財務行動特別組織（FATF）制定打擊洗錢、恐怖分子資金籌集及擴散融資的國際標準；香港是成員。FATF建議及相互評估促進有效制度，但不是直接取代香港法例的發牌或定罪條文。', 'The Financial Action Task Force (FATF) sets international AML/CFT and proliferation-financing standards. Hong Kong is a member. Recommendations and mutual evaluations support effective regimes; they do not replace Hong Kong’s licensing or criminal provisions.'),
        ('「呼籲採取行動」類別要求加強盡職審查；特定高風險地區另有反制措施。「加強監察」類別須納入風險評估，但並非單憑列名便一律要求加強盡職審查。FATF風險名單亦不是聯合國的指定人士制裁名單。', 'The call-for-action category requires enhanced due diligence, with countermeasures for specified high-risk jurisdictions. Increased monitoring informs risk assessment but does not by itself require EDD in every case. FATF risk lists are distinct from UN designated-person sanctions lists.'),
        ('第19份2026年7月3日通函記錄：朝鮮及伊朗須採取反制措施；緬甸須採取與風險相稱的加強措施；加強監察新增波斯尼亞和黑塞哥維那及伊拉克。這是該通函日期的名單，運作時須使用最新官方更新。', 'Document 19, dated 3 July 2026, records countermeasures for DPRK and Iran, proportionate enhanced measures for Myanmar, and additions of Bosnia and Herzegovina and Iraq to increased monitoring. This is the circular’s dated snapshot; operations require current official updates.'),
    ], [
        ref('03', '第1.13段', '¶1.13', 'As a member of the FATF'),
        ref('06', '打擊洗錢問答A17', 'AML/CFT FAQ A17', 'conducting EDD is not mandatory'),
        ref('19', '正文第1–3頁', 'Main text pp.1–3', 'Myanmar'),
    ], kind='list'),
    block('反制措施不是加強審查的另一個名稱', 'Countermeasures are more than another name for EDD', [
        ('第19份2026年7月3日通函所舉朝鮮反制措施包括終止與其銀行的往來關係、關閉其境內分行／附屬機構及限制與朝鮮人士的業務／交易；須按適用機構及法律框架執行。加強審查則包括提高監察程度及性質。不要把通函所述緬甸未來可能面對的反制，寫成當時已實施的同一措施。', 'The 3 July 2026 circular gives DPRK countermeasure examples including terminating its banks’ correspondent relationships, closing local branches/subsidiaries and limiting DPRK-person business/transactions, within the applicable institutional/legal framework. EDD includes increasing monitoring degree/nature. The circular’s possible future Myanmar countermeasures are not the same as already-operative snapshot measures.'),
    ], [
        ref('19', '第1頁註2、第2頁註5', 'p.1 note 2; p.2 note 5', 'terminating correspondent relationships with DPRK banks'),
    ], kind='list'),
]),
section('risk-assessment', '香港風險評估：威脅、脆弱性與行業風險', 'Hong Kong risk assessment: threats, vulnerabilities and sector risk', [
    block('第25份報告的2022年結論', '2022 findings in document 25', [
        ('威脅是犯罪、犯罪者及其可能濫用金融體系的活動；脆弱性是可被利用的制度／行業弱點。風險評估結合定量及定性資料分析威脅和脆弱性，不是把一宗交易機械地套入一個數學公式。', 'Threat concerns crime, criminals and their potential misuse of the financial system. Vulnerability concerns exploitable weaknesses. Assessment combines quantitative and qualitative information on both; it is not a mechanical formula for an individual transaction.'),
        ('2022年整體洗錢風險為中高，威脅中高、脆弱性中等；恐怖分子資金籌集及擴散融資整體均為中低。這些屬報告當年的整體評估，不能代替個別機構或客戶評估。', 'The 2022 overall ML risk is medium-high, with medium-high threat and medium vulnerability. Overall TF and PF risks are medium-low. These are dated aggregate findings, not substitutes for institutional or customer assessment.'),
        ('本地詐騙洗錢威脅高、毒品相關中高；外地詐騙高，外地毒品、貪污及稅務犯罪中高。金錢服務行業的威脅、脆弱性及整體洗錢風險均中高，跨境詐騙得益是重要威脅。', 'Local fraud presents high ML threat and drug crime medium-high. Foreign fraud is high, and foreign drugs, corruption and tax crime medium-high. MSO threat, vulnerability and overall ML risk are medium-high; cross-boundary fraud proceeds are an important threat.'),
        ('行業弱點包括現金密集、跨境及一次性客戶、資源有限、難核實貿易背景、網上／流動服務和不透明結算。Hawala透過經紀網絡、信任及其他結算安排轉移價值；不經傳統銀行不代表沒有金錢服務或洗錢風險。', 'Vulnerabilities include cash, cross-boundary/one-off customers, limited resources, difficulty verifying trade, online/mobile services and opaque settlement. Hawala moves value through broker networks, trust and alternative settlement; operating outside traditional banking does not remove money-service or ML risk.'),
        ('政府以跨部門協作及風險為本監管應對；海關結合機構風險及業務影響程度安排實地／非實地監察、外展、培訓及執法。報告中的歷史數字及季度申報安排不能當成現時統計或半年申報規則。', 'Interdepartmental coordination and risk-based supervision support mitigation. C&ED combines institutional risk and business impact in on/off-site monitoring, outreach, training and enforcement. Historical statistics and quarterly returns in the report are not current statistics or the half-yearly rule.'),
    ], [
        ref('25', '行政摘要；第2.1–2.10、5.4.1–5.4.29段', 'Executive summary; ¶2.1–2.10, 5.4.1–5.4.30', 'The overall ML risk is therefore assessed to be medium-high'),
    ], kind='list'),
    block('報告的研究背景及行業概況', 'Research context and sector profile', [
        ('香港2018年發表首份評估。第二次評估於2021年完成，報告於2022年發表；主要分析2016–2020年的五年數據，並載有其後部分發展。資料來自政府、監管、執法及私人業界。世界銀行方法結合數據及專家判斷分析威脅與脆弱性，先收集／分析及採取中期措施，再覆核更新。', 'Hong Kong published its first assessment in 2018. The second assessment was completed in 2021 and published in 2022, primarily analysing five-year data for 2016–2020 and also reporting some later developments. Government, regulators, law enforcement and the private sector contributed. The World Bank methodology combines data and expert judgement on threats/vulnerabilities, with initial analysis/interim measures followed by review/update.'),
        ('2021年有805個持牌MSO，621個有特定處所、184個沒有（約77%／23%）；首份評估的比較數為1,309。報告列街舖型約53%、外傭匯款約12%、兼營型約9%、不向公眾開放的公司客戶型約3%。這些是該版研究統計，不能用作現時持牌人數。', 'In 2021 there were 805 licensees: 621 with and 184 without particular premises (about 77%/23%), compared with 1,309 in the first assessment. Street-level operators accounted for about 53%, foreign-domestic-helper remitters 12%, side-business operators 9%, and corporate-only operators not open to the public 3%. These are the report’s historical statistics.'),
        ('外傭匯款研究以菲律賓／印尼銀行渠道為主，當時未見Hawala明顯威脅；不代表其他渠道或未來永遠低風險。網上服務需要相稱科技、紀錄、核實及監察，持牌身份不會令替犯罪集團匯款的行為合法。', 'The FDH remittance study mainly found Philippine/Indonesian banking routes and no evident Hawala threat then; it does not establish permanently low risk elsewhere. Online services need proportionate technology, records, verification and monitoring. Licensing does not legalise remitting for criminal groups.'),
        ('報告首次評估擴散融資：威脅及整體風險中低，開放跨境金融、國際貿易及複雜企業／付款網絡可被規避制裁者利用；依定向制裁、擁有權透明度、海關與金融監管／情報合作減低風險。', 'The report’s first PF assessment rates threat and overall risk medium-low. Open cross-border finance, international trade and complex corporate/payment networks can be exploited for sanctions evasion. Targeted sanctions, ownership transparency and Customs/financial-supervisory/intelligence cooperation mitigate it.'),
    ], [
        ref('25', '2022年版，前言；行政摘要第3–5、24–29段；第2.4–2.9、5.4.1–5.4.12段', '2022 edition, Foreword; Executive summary ¶3–5, 24–29; ¶2.4–2.9, 5.4.1–5.4.12', '805'),
    ], kind='list'),
    block('五級風險尺度與恐怖主義／融資的區別', 'Five risk levels and terrorism versus financing', [
        ('第25份把威脅理解為犯罪得益／恐怖主義相關資金的產生、流入及流出的規模與特徵；脆弱性是整體或行業防線的弱點／缺口。五級是低、中低、中、中高、高；評估不等於替個別交易指定一個固定數學分數。', 'Document 25 treats threat as the scale/patterns of generation, inflows and outflows of proceeds or terrorism-linked funds, and vulnerability as territory/sector defence weaknesses. Its five levels are low, medium-low, medium, medium-high and high; these are not a fixed mathematical transaction score.'),
        ('2022年報告第8.5段的恐怖襲擊威脅為「中（moderate）」：屬高／中／低的三級警戒，意思是香港可能受到襲擊，但沒有具體情報顯示會成為襲擊目標。這與五級風險尺度下的恐怖分子資金籌集威脅／風險「中低」不同；襲擊威脅與籌資／轉資風險不可互換，亦不是現時已核實的安全判斷。', 'Paragraph 8.5 of the 2022 report rates terrorist-attack threat “moderate” on a three-level high/moderate/low alert scale: an attack is possible, but there is no specific intelligence suggesting Hong Kong is likely to be a target. This differs from medium-low TF threat/risk on the five-level risk scale. Attack threat and fund-raising/movement risk are distinct, and these dated findings are not a verified current security assessment.'),
    ], [
        ref('25', '2022年版，第2.4–2.5、8.5段；行政摘要第18–23段', '2022 edition, ¶2.4–2.5, 8.5; Executive summary ¶18–23', 'Threats refer to the scale and characteristics'),
    ], kind='list'),
    block('理解：2022年報告中的公司及戶口濫用', 'Understand: company and account misuse in the 2022 report', [
        ('空殼公司（shell company）可沒有實質營運而被用作隱藏擁有人或轉款；掛名公司（front company）則以貌似或實際合法業務及收支掩飾犯罪得益。2022年報告提到單一股東／董事、與香港無關連、業務含糊及資金頻繁大額進出而結餘低的組合警號；單一特徵不等於犯罪。', 'A shell company may lack substantive operations and be used to hide ownership or move funds. A front company uses apparently or actually legitimate business and receipts/payments to disguise criminal proceeds. The 2022 report describes combinations of sole ownership/directorship, no Hong Kong nexus, vague business and frequent large flows with low balances; no single feature proves crime.'),
        ('錢騾／傀儡戶口（money mule／stooge account）：由他人名義持有或控制、被用來接收及轉移犯罪得益的戶口；應留意持有人是否真正控制及了解交易。報告所述高速收轉款、小額試轉及更換戶口／裝置等，是需要與客戶背景一起評估的手法。', 'Money-mule or stooge accounts are accounts in other persons’ names or control used to receive and move criminal proceeds. Examine whether the holder genuinely controls and understands the activity. Rapid receipt and dissipation, small test transfers and changing accounts/devices described in the report need assessment alongside the customer profile.'),
        ('挪用現金補空（cash kiting，循環轉款）：在同一方控制的多個個人／公司之間循環轉款，虛增營業額或薪酬以取得未獲授權的額外貸款／信貸。最初循環的款項未必是犯罪得益，但藉欺詐取得的額外貸款／信貸款項會被視作犯罪得益；不是每個循環轉帳都自動構成這種手法。', 'Cash kiting circulates funds among individuals/entities under common control to inflate turnover or payroll and obtain unauthorized additional loans/credit. The initial circulating money need not be criminal proceeds; money generated from the additional loan/credit obtained through the fraud would be considered crime proceeds. Not every circular transfer automatically constitutes this method.'),
    ], [
        ref('25', '2022年版，第4.39–4.41、4.52–4.59、4.63、7.11–7.12段及註94', '2022 edition, ¶4.39–4.41, 4.52–4.59, 4.63, 7.11–7.12 and footnote 94', 'Cash kiting'),
    ], kind='list'),
    block('2022年報告：跨行業風險如何連到MSO', '2022 report: how cross-sector risks connect to MSOs', [
        ('身分真實不等於實際使用者或用途真實。第5.2.13–5.2.17段區分遙距假冒身分風險與招募真人開傀儡戶口；可靠身分技術可減低前者，後者仍須靠客戶背景、控制者及交易行為辨識。傀儡戶口也存在於親身開戶，並非虛擬銀行特有。', 'A genuine identity does not prove the real user or purpose. Paragraphs 5.2.13–5.2.17 distinguish remote impersonation from recruiting real people to open stooge accounts. Reliable identity technology can reduce the former; the latter still requires attention to customer background, control and transaction behaviour. Stooge accounts also occur with face-to-face onboarding, not only virtual banks.'),
        ('多重支付中介可遮蔽最初匯款人及最終受益人；證券第三者付款、代名投資及TCSP成立多層公司，也可能掩蓋實益擁有權／資金來源。理解共同機制，不把「經銀行轉來」「由專業人士介紹」視為資金合法的證明。報告中的他業監管措施並不因此自動變成MSO的同一套法定程序。', 'Multiple payment intermediaries can obscure the original payer and ultimate recipient. Securities third-party payments, nominee investments and layered companies formed through TCSPs can also conceal beneficial ownership or source of funds. Understand the shared mechanism: a bank transfer or professional introduction is not proof of lawful funds. Other sectors’ controls in this report do not automatically become identical statutory MSO procedures.'),
        ('按產品功能看風險：本地小額交通／零售支付與可海外提款、跨境匯款、人對人轉撥的電子錢包，脆弱性不同。報告第5.6節的整體中等評級不能把每種產品或每名客戶都定為同一級，也不能用低額交易自動排除非法博彩或分拆操作。', 'Assess product functionality: small domestic transport/retail payments differ from wallets supporting overseas cash withdrawal, cross-border remittance and peer-to-peer transfers. The sector’s medium rating in section 5.6 does not assign every product/customer the same risk, nor do small transactions automatically exclude illegal bookmaking or structuring.'),
        ('理解例子：虛假投資可以先叫受害人在真實平台買入虛擬資產，再轉到騙徒錢包；也可能只收法幣到傀儡銀行戶口，根本沒有虛擬資產交易。不能只看「加密貨幣投資」名稱或網頁顯示的收益，須理解實際資金流。這是第5.7.5段的2022年案例機制，不是所有虛擬資產活動都屬詐騙。', 'Illustration: a fake investment may first send a victim to a genuine platform to buy VAs and then transfer them to a fraudster’s wallet; alternatively, it may collect fiat money into stooge bank accounts without any VA transaction. Understand the actual funds flow rather than relying on the crypto-investment label or displayed returns. This is the 2022 paragraph 5.7.5 typology, not a claim that all VA activity is fraud.'),
        ('版本分開：第25份在2022年把虛擬資產發牌及DPMS註冊寫為擬議制度；第04份所存2026年綜合條例已載第5B／5C部，Part 2的制度參考以第04份為據。第25份行業數量、風險評級、監管改革與下一步措施均保留2022年時點，不用來判定今天的名單或法律狀態。', 'Separate editions: document 25 in 2022 describes VA licensing and DPMS registration as proposed regimes; the stored 2026 consolidated document 04 contains Parts 5B/5C, which support the Part 2 reference notes. Sector counts, risk ratings, regulatory reforms and next steps in document 25 retain their 2022 date and do not establish today’s lists or legal position.'),
    ], [
        ref('25', '第5.2.13–5.2.17、5.2.21、5.3.25–5.3.38、5.6.2、5.6.7–5.6.15、5.6.21、5.7.5、5.7.22、6.4.3、6.6.6–6.6.13段', '¶5.2.13–5.2.17, 5.2.21, 5.3.25–5.3.38, 5.6.2, 5.6.7–5.6.15, 5.6.21, 5.7.5, 5.7.22, 6.4.3, 6.6.6–6.6.13', 'Mule account networks'),
        ref('04', '第5B、5C部', 'Parts 5B, 5C', 'Regulation of Dealings in Precious Metals and Stones'),
    ], kind='list'),
]),
section('sanctions', '恐怖主義及擴散融資的定向金融制裁', 'Targeted financial sanctions for terrorism and proliferation', [
    block('禁止、凍結及許可', 'Prohibitions, freezing and licences', [
        ('定向金融制裁通常包括凍結指定人士／實體的資金或其他資產，及禁止直接或間接向其提供資金、資產或相關服務。篩查不只看國籍或姓名，也須涵蓋有關實體、國家、活動及交易參與者。', 'Targeted financial sanctions generally freeze designated persons’/entities’ funds or other assets and prohibit direct or indirect provision of funds, assets or related services. Screening concerns relevant entities, countries, activities and transaction parties, not just nationality or names.'),
        ('第575章下，行政長官在憲報刊登有關指定；保安局局長可依權力凍結財產及處理有關許可。第537章下，實際限制及豁免須看適用規例；行政長官可批出法定特許，申請者須向商務及經濟發展局提出書面申請。不要把不同法例的主管人員混為一談。', 'Under Cap.575 the Chief Executive publishes relevant designations in the Gazette; the Secretary for Security exercises relevant freezing/licensing powers. Under Cap.537 restrictions and exemptions depend on applicable regulations, with licences granted by the Chief Executive; applicants write to the Commerce and Economic Development Bureau. These roles differ.'),
        ('不得把法定禁止交易當成可以自行接受的高風險業務。只有符合適用法例的豁免或有效許可，才可在其範圍內處理；有需要時須報告懷疑及保存處理紀錄。', 'A prohibited transaction is not simply a high-risk business choice. Deal only within an applicable statutory exemption or valid licence where available, and report suspicion and retain handling records where required.'),
        ('聯合國指定與香港落實之間可能有時間差；第26份通函指出，在本地制裁實施前，相關活動已可能觸犯現有洗錢、恐怖分子資金籌集或擴散融資相關罪行。須及早更新風險及監察，不能一律等待本地規例生效。', 'There may be a gap between UN designation and local implementation. Document 26 explains that activity before implementation may already breach existing ML/TF/PF-related offences. Update risk and monitoring promptly rather than automatically waiting for local regulations.'),
        ('第09份通函要求盡快把擴散融資納入機構風險評估，包括現有業務及客戶；留意指定對象利用空殼、貿易、代理及複雜付款鏈規避制裁的風險。', 'Document 09 calls for prompt inclusion of PF in institutional assessment, covering existing business/customers. Consider evasion through shells, trade, agents and complex payment chains.'),
    ], [
        ref('03', '第6.1–6.8段', '¶6.1–6.8', 'Secretary for Security'),
        ref('09', '正文第1–2頁', 'Main text pp.1–2', 'proliferation financing'),
        ref('26', '正文第1–3頁', 'Main text pp.1–3', 'time gap'),
    ], kind='list'),
    block('全球措施、特定地區與境外制裁', 'Global measures, country-specific measures and foreign sanctions', [
        ('指引以聯合國安理會第1540號及其後決議說明全球擴散防制，並以朝鮮第1718號、伊朗第2231號及其後決議說明特定國家措施。實際禁止及特許須按適用香港法例及更新名單判斷，決議年份本身不是現行名單證明。', 'The Guideline illustrates global counter-proliferation through UNSCR1540/successors and country-specific measures through DPRK1718 and Iran2231/successors. Actual prohibitions/licences follow applicable Hong Kong laws and updated lists; resolution years do not prove a current list.'),
        ('其他司法管轄區的單邊制裁一般不直接成為香港法下的義務，但跨境經營仍可能受境外法規、交易對手及業務限制影響，須理解及管理其風險。', 'Foreign unilateral sanctions generally do not directly impose Hong Kong-law duties, but international operations can face overseas law, counterpart and business restrictions; understand/manage that exposure.'),
    ], [
        ref('03', '第6.9–6.11段', '¶6.9–6.11', 'two-tiered approach'),
    ], kind='list'),
    block('第1373號決議與兩項制裁法例', 'Resolution 1373 and the two sanctions frameworks', [
        ('聯合國制裁一般透過UNSO第537章下的規例在港落實；涉及恐怖主義的安理會第1373號決議則由UNATMO第575章處理。行政長官的指明及憲報更新使相關指定在港生效；仍須留意前述時間差，不能一概等到本地規例更新才留意風險。', 'UN sanctions are generally implemented through regulations under UNSO, Cap.537; terrorism-related UNSCR1373 is covered by UNATMO, Cap.575. Chief Executive specifications and Gazette updates give effect to relevant designations locally. The timing-gap risks above still apply; do not wait indiscriminately for local regulations before addressing risk.'),
    ], [
        ref('26', '預期監管標準第1頁', 'Expected regulatory standards, p.1', 'except for UNSC Resolution 1373'),
    ], kind='list'),
    block('恐怖分子財產、跨國旅行及間接控制', 'Terrorist property, inter-state travel and indirect control', [
        ('恐怖分子財產包括恐怖分子或其有聯繫者的財產，以及擬用於或曾用於資助／協助恐怖行為的其他財產。來源合法的財產亦可符合，不能把恐怖分子財產只理解成犯罪所得。', 'Terrorist property includes property of a terrorist/associate and other property intended or used to finance/assist terrorist acts. Lawful-source property can qualify; it is not confined to criminal proceeds.'),
        ('UNATMO第8A條禁止明知或罔顧財產是否指明恐怖分子財產，或指明恐怖分子／有聯繫者財產而處理。第11L條禁止提供／籌集財產資助跨國旅行，意圖或明知旅行用於實施、計劃、準備、參與恐怖行為或相關訓練；不必實際發生恐怖行為。', 'UNATMO section 8A prohibits dealing knowing or reckless as to whether property is specified terrorist property or property of a specified terrorist/associate. Section 11L prohibits providing/collecting property for inter-state travel intending or knowing the terrorist-act/planning/preparation/participation or related-training purpose; an actual terrorist act need not occur.'),
        ('保安局局長可在UNATMO適用範圍發牌准許例外，例如合理生活／法律開支及法定僱傭款項；MSO須向保安局提出申請。不可把此許可與UNSO下向商經局申請、由行政長官批准的特許混為一談。', 'The Secretary for Security can license exceptions within UNATMO’s scope, such as reasonable living/legal expenses and statutory employment payments; an MSO applies to the Security Bureau. This differs from UNSO applications to the Commerce and Economic Development Bureau for a Chief Executive licence.'),
        ('UNSO適用規例的禁令不限於直接列名者，也涵蓋代其／按其指示行事、由其擁有或控制的人士／實體，以及由上述人士／實體擁有的實體。除有效法定特許外，禁止直接／間接為其利益提供資金、金融資產或經濟資源，或處理屬於或由其擁有／控制的資產。', 'Applicable UNSO prohibitions extend beyond named designees to persons/entities acting for or at their direction or owned/controlled by them, and entities owned by the foregoing. Subject to a valid statutory licence, prohibitions cover direct/indirect availability of funds, financial assets or economic resources for their benefit and dealing with assets belonging to or owned/controlled by them.'),
    ], [
        ref('03', '第6.5–6.8段及註56', '¶6.5–6.8; footnotes 56', 'section 11L prohibits any person from providing or collecting any property to'),
    ], kind='list'),
    block('第03份所列兩層反擴散框架', 'The two-tier counter-proliferation framework in document 03', [
        ('第03份第6.9段說明：全球層面為安理會第1540(2004)號及後續決議；國別層面為針對朝鮮的第1718(2006)號、針對伊朗的第2231(2015)號及其後續決議。這是該版原文的框架及決議對應，不能把它當成已核實至今的完整制裁名單或現行限制。', 'Document 03 paragraph 6.9 describes a global tier under UNSCR1540(2004)/successors and country-specific tiers under UNSCR1718(2006) for DPRK and UNSCR2231(2015) for Iran/their successors. This is the stored edition’s framework mapping, not a verified-current complete sanctions list or set of restrictions.'),
    ], [
        ref('03', '第6.9段', '¶6.9', 'a two-tiered approach'),
    ], kind='list'),
    block('2022年PF評估範圍與PACE', 'The 2022 PF assessment and PACE', [
        ('就報告引用的FATF第1項建議而言，PF風險嚴格限於可能違反、沒有實施或逃避第7項建議的針對性財政制裁（TFS）責任。這個評估範圍與更廣的擴散活動概念須分開；不能只找「資金直接購買武器」，而漏看代名人、受控公司或制裁規避。', 'For FATF Recommendation 1 as discussed in the report, PF risk refers strictly to potential breach, non-implementation or evasion of the targeted financial sanctions (TFS) obligations in Recommendation 7. Distinguish this assessment scope from the broader proliferation concept; focusing only on direct weapon purchases can miss nominees, controlled entities or sanctions evasion.'),
        ('PACE是報告列明的四項策略，沒有先後流程：Prevention預防——法律制度、培訓及認識責任；Alert警報——及時傳遞制裁更新；Coordination協調——跨部門及監管合作、情報分享；Enforcement執法——調查及監督遵從。須記名稱並理解各自作用；不把2022年當時的制裁名單數字當作現況。', 'PACE names four strategy elements, not sequential steps: Prevention—legal controls, training and awareness; Alert—timely sanctions updates; Coordination—inter-agency/regulatory cooperation and intelligence sharing; Enforcement—investigation and compliance supervision. Recognize the names and purposes; the report’s 2022 sanctions-list counts are not current facts.'),
    ], [
        ref('25', '2022年版，第9.1、9.17、9.26、9.45–9.46段', '2022 edition, ¶9.1, 9.17, 9.26, 9.45–9.46', 'Prevention'),
    ], kind='list'),
]),
section('cross-boundary-cash', '跨境現金類物品：超過12萬元的申報制度', 'Cross-boundary CBNIs: declarations above HK$120,000', [
    block('物品、門檻與旅客', 'Items, threshold and travellers', [
        ('現金類物品（CBNIs）包括香港或外地的法定貨幣紙幣／硬幣，以及不記名或其他可透過交付轉移權利的可轉讓票據，例如不記名支票、匯票、旅行支票及本票。按面值合計，總值超過港幣120,000元才是「大量」；正好120,000元並不超過。', 'CBNIs include legal-tender notes/coins of Hong Kong or elsewhere and bearer or other negotiable instruments transferable by delivery, such as bearer cheques, bills, travellers’ cheques and promissory notes. Aggregate nominal value must exceed HK$120,000 to be a large quantity; exactly HK$120,000 does not exceed it.'),
        ('從指明管制站入境而管有大量CBNIs的人須使用紅通道並作書面申報；從其他地方入境及離境人士，須應獲授權人員要求披露，披露管有大量CBNIs後須按要求作申報。', 'At specified entry points, persons possessing large quantities use the red channel and make a written declaration. Arrivals elsewhere and departing persons disclose on an authorized officer’s request and then declare where large quantities are disclosed.'),
        ('管有包括隨身物品、由該運輸工具運載的個人物品，以及托運行李；托運行李不論是否由或將會由同一運輸工具運載，均可計入。陪同未滿16歲人士的成人，在知道該幼年人管有大量CBNIs時承擔相應責任。純粹過境、在香港機場未通過入境檢查的法定情況獲豁免。', 'Possession includes personal belongings carried by the person, belongings on the conveyance and checked baggage. Checked baggage counts whether or not carried, or to be carried, on the same conveyance. An accompanying adult has relevant duties when aware that a person under 16 possesses large quantities. The statutory airport-transit case without immigration clearance is exempt.'),
        ('旅客外幣按有關事件當日的參考匯價；非公布日或公布前使用前一公布日。未能按該方法計算時，按法定指定國際機構匯價，再無則用管有人通常採用的匯價。', 'For travellers, use the reference rate on the relevant-event date; use the preceding publication day if no rate is published that day or the event precedes publication. Statutory fallbacks are a specified international institution’s rate and then the holder’s ordinarily used rate.'),
    ], [
        ref('22', '正文第1頁', 'Main text p.1', 'HK$120,000'),
        ref('23', '第2–7條及附表4', 'ss.2–7; Schedule 4', 'nominal value'),
    ], kind='list'),
    block('貨物輸入／輸出與違規', 'Cargo imports/exports and breaches', [
        ('非旅客方式以跨境運輸工具輸入／輸出大量CBNIs，負責人須事先透過指定電子系統申報；須依第10條處理同一運輸工具及同一客戶等合併情況。系統產生接受申報的參考編號才視為申報。不要自行添加法例沒有訂出的統一24小時期限。', 'For non-traveller imports/exports of large quantities on cross-boundary conveyances, the responsible person declares in advance through the designated electronic system. Apply section 10 aggregation rules, including same-conveyance/customer cases. Declaration occurs when the system generates the acceptance reference; there is no invented universal 24-hour deadline.'),
        ('例外包括適用旅客物品、只經香港而全程留在飛機／船上的貨物、航空轉運貨物及郵包等法定情況。貨物外幣通常用上月15日的參考匯價（非公布日用之前公布日），與旅客的當日基準不同。', 'Statutory exclusions include covered travellers’ belongings, goods remaining aboard aircraft/vessels solely transiting Hong Kong, air-transhipment cargo and postal packets. Cargo normally uses the previous month’s 15th-day reference rate, or preceding publication day, unlike the traveller’s event-date basis.'),
        ('沒有遵從申報／披露或作出在要項上虛假的申報可罰款500,000元及監禁2年。部分指明罪行可由關長發通知，以2,000元在指定合理時間內繳付而不提控；並非人人都有此權利：既往相關定罪／繳付紀錄、指定洗錢或恐怖主義定罪或按第17條檢取等情況不適用。', 'Non-compliance or materially false declarations/disclosures can carry HK$500,000 and two years. For specified offences the Commissioner may issue a notice allowing HK$2,000 payment within a specified reasonable time instead of prosecution. This is not an entitlement: relevant prior convictions/payment records, specified ML/terrorism convictions or section 17 seizure exclude it.'),
    ], [
        ref('23', '第8–14條、附表5', 'ss.8–14; Schedule 5', 'Written notice about not instituting criminal proceedings on payment'),
    ], kind='list'),
    block('現金類物品的五類票據及匯價日期', 'Five instrument forms and the exchange-rate event', [
        ('可轉讓票據包括：持有人形式、無限制背書、向虛構受款人付款、所有權隨交付轉移，以及已簽署但未寫受款人姓名的票據。例子有不記名支票、本票、匯票及旅行支票，須符合上述票據形式；法定貨幣紙幣／硬幣是另一類，並非只有現金及不記名支票才計算。', 'Negotiable instruments include bearer form, unrestricted endorsement, a fictitious payee, title passing on delivery, and signed instruments without a named payee. Examples include bearer cheques, promissory notes, bills and travellers’ cheques meeting those instrument-form conditions; legal-tender notes/coins form the other limb. CBNIs are not limited to cash and bearer cheques.'),
        ('旅客的「有關事件」：第4條是抵達指明管制站；第5／6條是獲授權人員要求披露。參考匯價指香港銀行公會公布的外匯賣出開市參考牌價。套用前文的公布日／公布前及後備方法；貨物仍採上月15日基準，不可混用。', 'The traveller’s relevant event is arrival at the specified control point for section 4, and the officer’s disclosure request for sections 5/6. Reference rates are the Hong Kong Association of Banks opening indicative counter exchange selling rates. Apply the publication-day/time and fallback rules above; cargo retains its previous-month 15th-day basis.'),
    ], [
        ref('23', '第2(1)、7(6)條', 'ss.2(1), 7(6)', 'signed but does not state a payee’s name'),
        ref('23', '第7條', 's.7', 'means the person arrives at the specified control point concerned'),
    ], kind='list'),
    block('檢取與扣留：十個工作日、三個月、兩年', 'Seizure and detention: ten working days, three months, two years', [
        ('行使第16(1)條權力而發現現金類物品，獲授權人員合理懷疑屬第455章第25(1)條犯罪得益，或第575章所指恐怖分子財產，可依第17條檢取。此項權力針對懷疑財產，不能套用申報制度的超過12萬元門檻。', 'CBNIs found through section 16(1) powers may be seized under section 17 on reasonable suspicion that they represent OSCO section 25(1) crime proceeds or UNATMO terrorist property. This suspected-property power does not import the declaration regime’s above-HK$120,000 threshold.'),
        ('在第18、19條規限下，第17條通常准許扣留至檢取日後不超過10個工作日。此處工作日排除星期六、公眾假期、黑色暴雨警告日及烈風警告日；不要直接套用AMLO的營業日定義。這是物品扣留期，不是拘捕後扣留人的期限。', 'Subject to sections 18/19, section 17 ordinarily allows detention for no more than ten working days after the seizure day. Here working days exclude Saturdays, general holidays and black-rainstorm/gale-warning days. Do not substitute AMLO business days. This is detention of property, not a period of personal custody after arrest.'),
        ('懷疑犯罪得益，獲授權人員可在上述期間內向原訟法庭或區域法院申請第18條繼續扣留令。法院須信納合理懷疑及扣留有理據，例如進一步調查來源、考慮相關刑事程序或沒收／充公程序。每次命令期不超過自命令日起3個月；新命令不得令總扣留超過首個法院命令日起2年。', 'For suspected crime proceeds, an authorized officer may apply within that period to the Court of First Instance or District Court under section 18. The court must be satisfied of reasonable suspicion and justification, such as source investigation or consideration of relevant criminal/forfeiture/confiscation proceedings. Each order permits no more than three months from its date; renewals must not take total detention beyond two years from the first court order.'),
        ('第19條所列相關程序在扣留期間提起時，可扣至程序完結，故兩年不是沒有例外的絕對上限。第18條扣留條件不存在／不再存在或再無理據時，法院可按關係人／人員申請指示發還。第18條延長機制針對懷疑犯罪得益，不應不加區分地當成恐怖分子財產的相同延長程序。', 'If the relevant section 19 proceedings are instituted during detention, detention may continue until they conclude, so two years is not an exception-free absolute limit. Under section 18, the court may direct return on an interested person’s/officer’s application when conditions do not/no longer exist or detention is no longer justified. Section 18 continuation concerns suspected crime proceeds; do not indiscriminately apply it as the same terrorist-property extension mechanism.'),
    ], [
        ref('23', '第17–19條', 'ss.17–19', 'not more than 10 working days after the day of seizure'),
    ], kind='list'),
    block('申報內容的基本清單', 'Basic declaration information', [
        ('旅客申報須提供適用的身分、聯絡及運輸工具資料，現金類物品種類／面值，日期、來源及目的地，以及不是本人擁有時的擁有人等資料。非旅客方式申報包括負責人／客戶資料、運輸工具、物品種類及價值、日期及來源／目的地，並在適用時列收受人及貨單識別資料。須按附表2／3相應表格填報，不能只報一個總額。', 'Traveller declarations require applicable identity/contact/conveyance details, CBNI type/value, dates/source/destination and ownership particulars where not owned by the holder. Non-traveller declarations include responsible-person/customer details, conveyance, type/value, dates/source/destination and applicable recipient/consignment identifiers. Follow the corresponding Schedule 2/3 information requirements; reporting a total alone is insufficient.'),
    ], [
        ref('23', '附表2–3', 'Schedules 2–3', 'If applicable, the name and address of the recipient of the CBNIs'),
    ], kind='list'),
    block('貨物的合併與申報責任', 'Cargo aggregation and declaration responsibility', [
        ('非承運人：合併同一人以同一跨境運輸工具輸入／輸出的現金類物品。承運人：合併同一承運人為同一客戶在同一運輸工具運送的物品；客戶須直接聘用承運人，或直接聘用把物品交給承運人的代運人。同一客戶聘用多名代運人時，只有同一代運人交予同一承運人的物品才按這項規則合併。客戶指非承運人，不能把物流代運人自行當成客戶。', 'For a non-carrier, aggregate CBNIs imported/exported on the same carrier for the same customer. For a carrier, aggregate consignments for the same customer on that conveyance; where multiple consignors use the same freight forwarder, section 10 treats the forwarder as customer. Splitting consignments does not defeat aggregation.'),
        ('輸入、輸出或安排輸入／輸出的人須確保事前已有合規申報；僅掌管運輸工具而無其他輸入／輸出責任者有第9(2)條例外。通常以電子方式申報；獲系統接納及編配參考編號才算完成。關長認為電子傳送並非切實可行時，可依關長指示採另一方式；不是自行改用任意紙本程序。旅客、郵包及法定過境／航空轉運貨物豁除另按第8條判斷。', 'A person importing/exporting or causing import/export must ensure a compliant declaration has been made beforehand; section 9(2) excepts a conveyance operator with no other responsibility for the import/export. Normally declare electronically; acceptance and allocation of a reference number complete submission. Where the CCE considers electronic transmission impracticable, use an alternative manner directed by the CCE, not an arbitrary paper route. Apply section 8 exclusions for travellers, postal packets and the specified transit/air-transhipment cargo separately.'),
    ], [
        ref('23', '第8–11條', 'ss.8–11', 'same carrier for the same customer'),
    ], kind='list'),
    block('參考：申報資料的完整分類', 'Reference: declaration-information checklist', [
        ('旅客申報：管有人全名、身分證號碼或旅行證件號碼及簽發地、國籍、出生日期及地點、永久地址（境外者另填在港地址）；運輸工具識別、現金類物品種類及價值、出入境方向、日期及來源／目的地。如不是物品擁有人，填擁有人姓名／名稱及地址；代報者另填相同個人資料。', 'Traveller declaration: possessor’s full name, ID number or travel-document number and issuing place, nationality, birth date/place, permanent address (plus Hong Kong address if the permanent address is overseas); conveyance identifier, CBNI type/value, direction, date and origin/destination. If not the owner, give owner name/address; a separate declarant supplies the same personal particulars.'),
        ('貨物申報：非承運輸入／輸出人或承運人客戶的基本資料；自然人為上述個人資料但不另列在港地址，非自然人為名稱、適用商業登記號碼及業務地址。另填運輸工具、物品種類／價值、方向、日期、來源／目的地，以及適用收受人姓名／名稱及地址、貨單等批次識別。', 'Cargo declaration: basic information of the non-carrier importer/exporter or carrier’s customer. Individuals provide the above personal particulars without a separate Hong Kong-address item; entities provide name, applicable BR number and business address. Add conveyance, type/value, direction, date, origin/destination and, where applicable, recipient name/address and consignment identifier such as waybill number.'),
    ], [
        ref('23', '附表2、3', 'Schedules 2–3', 'Information to be Provided in Declaration'),
    ], kind='reference'),
]),
])
