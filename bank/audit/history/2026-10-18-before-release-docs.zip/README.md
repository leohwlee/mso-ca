# MSO Competence Assessment — Mock Exam

[繁體中文版 →](README.zh-Hant.md)

An offline English / Traditional Chinese practice app for the Hong Kong Money
Service Operator Competence Assessment. **525 combination questions**, based
only on documents **01–26** in the [reading library](docs/README.md).

## Two modes

- **Mock exam:** 35 questions, five from each of seven parts, 75 minutes. Pass
  requires at least 25/35 overall and no more than two wrong in any part.
- **Custom practice:** select one or more Parts 1–7. No time limit; each answer
  reveals the explanation, source and precise defect in each false statement.

Questions use four to six statements and five combination options. Statements
are shuffled at each draw, with their options and explanations kept aligned.
EN, 繁體中文 and side-by-side views are available. Results and review stay inside
the two modes; there is no separate statement-drill mode.

## Use

Build the current version with `go run . -export-html dist/mso-ca.html`, then open
`dist/mso-ca.html` in a browser. It works without a server, network or account.
See [development](DEVELOPMENT.md) for prerequisites and checks. A previously
downloaded release may contain an older bank; this README describes the source.

Completed scores remain in the same browser. Expand **Mock exam results and
history** to review, export or import them. If a bank update removes an item from
an unfinished paper, start a new full paper; completed historical scores remain.

## Question bank

| Part | Topic | Questions |
|---|---|---|
| 1 | General AML/CFT and counter-proliferation financing | 60 |
| 2 | AMLO Parts 1–7 | 75 |
| 3 | AMLO Schedules | 65 |
| 4 | C&ED guidelines | 80 |
| 5 | Governance and strategy | 80 |
| 6 | AML/CFT control areas | 100 |
| 7 | Demonstrating and monitoring compliance | 65 |

The bank keeps 8 official sample questions.
Other questions are authored practice material, not released past papers.
Plausible distractors test actors, timing, thresholds, conditions, exceptions
and mandatory versus discretionary duties. Distinct application scenarios test
how those rules interact; superficial rewrites are not new coverage.

Only the local contents of 01–26 support answers. The 21 publications numbered
27–47 remain historical reference and are excluded from the active bank.
Document 24 has no official Chinese edition: its Chinese questions are labelled
**study translations**, and their deciding quotations retain the English source.
Findings drawn from the 2022 risk report are explicitly report-dated.

[Source accounting](docs/QUESTION-SOURCES.md) and
[current review evidence](bank/audit/ACTIVE-SCOPE.md) describe the actual scope.
The older 23-source audits and retired questions remain preserved as history;
they are not presented as a review of the new bank.

## Maintain or adapt

Any agent or human can start with [AGENTS.md](AGENTS.md),
[question format](bank/FORMAT.md) and the
[agent-neutral authoring workflow](docs/authoring/exam-prep/GUIDE.md).
These are ordinary Markdown files, without a required vendor, plugin or slash
command. The source finder, patch tools, blind-review workflow and tests remain.

The [legacy revision-pack generator](revision/README.md) is retained as reference
and for historical evidence. It is separate from the two-mode exam app and its
legacy scope is not the current question-bank scope.

## Limits and licensing

This is a personal study scope, not a claim that the official exam excludes
other documents. Source checks and review reduce errors but cannot guarantee
every answer or complete exam coverage. Recorded source conflicts are in
[the decisions register](revision/CONFLICT-CALLS.md); original publications prevail.
This is not an official C&ED product or legal advice.

Code, authored questions, reference-pack content and authoring guides are
[MIT-licensed](LICENSE). Fonts use [SIL OFL](web/fonts/OFL.txt). Official
publications and quotations retain their publishers' rights; see
[content licensing](LICENSE-CONTENT.md).
