# Maintaining the source documents

[繁體中文版 →](SOURCE-MAINTENANCE.zh-Hant.md)

## One document number

The number in the [reading directory](README.md) is the only document ID.
`catalog.json` lists documents in that order; `id` is the two-digit number.
Daily reading is a selected subset: gaps represent archived items, without a
second source-ID scheme. Medium filenames distinguish Essential and Selected.
For example, the AML/CFT Guideline is **03** everywhere:

- Official files: `EN/03_High_…pdf` and `TC/03_高_…pdf`.
- Extracted text: `text/EN/03.txt` and `text/TC/03.txt`.
- Question quotes: `"doc": "03"` in `quotes.json`.
- Image transcripts, where needed: `transcripts/NN.json` with the same number.

Cap. 615 is **04**; the periodic-return circular and its transcript are **18**.
There is no separate stable source ID or old-name lookup.

## Editing or adding material

Use `catalog.json` for filenames, priority, reading status, official URLs, editions
and hashes. `editions.path` is relative to `docs/` and resolves the current location.
Active main files are directly in `TC/` and `EN/`; archived main sources are in
`archive/TC/` and `archive/EN/`. Every bank source remains available for citation
checks even when it is outside the daily reading set.
The original 23 bank sources are marked `original_bank_source`; the nine additions
are reading materials, not evidence that their contents are already covered by
questions. Verify edition, language, applicability and citation patterns in
`sources_test.go` before writing questions against an addition. Item 20 is an
archived statutory extract, covered by the full companion law under 19. Item 22
now places the English original in both language folders, explicitly labelled as
English in TC; the old pointer is retained as a superseded file.

After replacing source content, regenerate text with `python docs/extract_text.py`
(requires PyMuPDF) and review affected quotes. Recheck image transcripts against
the new PDF. PDF hashes use raw bytes; Markdown hashes use LF line endings.
Generate the directory with `python docs/build_catalog.py`.

Active companion publications live beside their circulars in `TC/` and `EN/`,
using the parent's number and a Supplement/配套 filename that sorts after it.
`companions` records language, edition, URL, raw-file and extracted-text hashes.
For a bilingual edition, `file` is the canonical original and `copies` records
the two identical reading copies. Extracted companion text lives separately in
`text/companions/`; do not add duplicate text files to the reading folders.
Archived companions and their texts are in `archive/related/NN/`, outside daily
reading. `reading_status`, `study_focus` and bilingual `archive_reason` describe
the selection; the generator builds both active and archive directories.
Run `python docs/extract_related.py` after changing companion files. These files
are reading supplements, not additional numbered bank sources: do not cite a
companion passage under its parent circular's `doc` value without explicitly
extending the bank's citation checks. Preserve later documentation review evidence
in `bank/audit/maintenance/`; earlier hash records and snapshots stay unchanged.

If reading order changes, renumber filenames, catalog IDs, extracted text,
manifest keys, quotes, transcripts, citation patterns, reports and authoring
examples together. Preserve question IDs, question wording and saved-answer
compatibility. Archive prior audit evidence and record a verified mechanical
migration; a hash change alone is not evidence of a correct migration.

## Checks

```bash
python docs/build_catalog.py --check
go test ./...
python bank/audit/report.py --check
python bank/audit/terms_report.py --check
python bank/audit/p1_report.py --check
python bank/audit/remaining_report.py --check
go run . -export-html dist/mso-ca.html
python revision/pack_build.py dist/mso-revision-pack.html
```

The mock exam stores progress by question ID, not document number. This cleanup
does not change question IDs or stored answers. Historical evidence before the
numbering cleanup is retained in [the audit archive](../bank/audit/history/README.md);
it is not a numbering system to maintain or use for new questions.
