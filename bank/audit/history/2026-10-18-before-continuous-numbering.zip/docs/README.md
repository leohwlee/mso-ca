# MSO focused reading directory

[繁體中文 →](README.zh-Hant.md)

**26 publications for daily reading: 24 main materials and 2 complete companion laws.** All originals are directly in [TC](TC/) and [EN](EN/), 26 files per folder. Each bilingual law is copied to both folders and follows its circular.

Sort by filename. The single document-number sequence is retained; gaps identify materials moved out of daily reading, without a second source-ID system. Medium filenames distinguish Essential and Selected reading. For the same number, read the circular before its Supplement.

**Master 03, 04 and 05 first:** the AML/CFT Guideline, Cap. 615 and Licensing Guide. Skim 01-02 for exam setup and examples; use 06-09 for application and specific expectations. After High, finish Medium Essential before selecting weaker topics from Medium Selected.

Basis: [official Guidance Notes, paragraphs 5.2-6.1](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_en.pdf). The seven-module syllabus includes law, core and other guidelines, and circulars. These are study recommendations, not official exam weights.

21 of the 47 publications have been removed from daily reading: covered extracts, old notices, repeat training, historical resolutions and lower-priority extensions. See [the decisions and reasons](archive/README.md). Originals and question evidence remain. Archiving does not establish withdrawal or exam exclusion; existing questions may still cite archived circulars.

## High priority · first pass

| Number | Publication and original | What it is | Reading focus |
|---|---|---|---|
| <a id="doc-01"></a><a id="related-01"></a>01 | [Guidance Notes on the Competence Assessment (Dec 2022)](<EN/01_High_Guidance Notes on the Competence Assessment (Dec 2022).pdf>) | Assessment rules and syllabus. | Read sections 5-7, passing rules and attendance arrangements first. |
| <a id="doc-02"></a><a id="related-02"></a>02 | [Competence Assessment - Sample Questions (12 May 2021) · MSSB/CA_01/2021](<EN/02_High_Competence Assessment - Sample Questions (12 May 2021).pdf>) | Seven official sample questions. | Attempt first, understand every statement, then repeat after the core reading. |
| <a id="doc-03"></a><a id="related-03"></a>03 | [Guideline on AML-CFT for Money Service Operators (Jun 2023)](<EN/03_High_Guideline on AML-CFT for Money Service Operators (Jun 2023).pdf>) | The principal AML/CFT operating guideline for MSOs. | Study chapters 1-11 and Appendix A, including all control areas and remittance rules. |
| <a id="doc-04"></a><a id="related-04"></a>04 | [AMLO Cap 615 - Consolidated (24 Sep 2026)](<EN/04_High_AMLO Cap 615 - Consolidated (24 Sep 2026).pdf>) | The statutory text of AMLO, Cap. 615. | Read Parts 1-7 and the Schedules; focus on MSO licensing, supervision, sanctions, review and Schedule 2. |
| <a id="doc-05"></a><a id="related-05"></a>05 | [Licensing Guide (May 2026)](<EN/05_High_Licensing Guide (May 2026).pdf>) | Licensing, renewal and continuing operating requirements. | Read exemptions, procedures, premises, local management office, personnel and returns. |
| <a id="doc-06"></a><a id="related-06"></a>06 | [FAQ applicable to all MSOs (C&ED portal)](<EN/06_High_FAQ applicable to all MSOs (C&ED portal).md>) | Official FAQs on AML/CFT and licence applications. | Read practical identity, ownership, representative and non-face-to-face cases alongside the current rules. |
| <a id="doc-07"></a><a id="related-07"></a>07 | [Circular - Supervisory Findings on Customer Due Diligence (22 Nov 2023) · MSSB/MIS_03/2023](<EN/07_High_Circular - Supervisory Findings on Customer Due Diligence (22 Nov 2023).pdf>) | Supervisory findings on customer due diligence. | Read the deficiencies, expected standards and good practices for risk, ownership, screening and authority. |
| <a id="doc-08"></a><a id="related-08"></a>08 | [Circular - ML-TF Risks of Third Party Payments (17 Sep 2024) · MSSB/MIS_01/2024](<EN/08_High_Circular - ML-TF Risks of Third Party Payments (17 Sep 2024).pdf>) | Risks and controls for third-party payments. | Study acceptance, approval, identity, relationships, funds, monitoring, records and reporting. |
| <a id="doc-09"></a><a id="related-09"></a>09 | [Circular - Identification and Mitigation of Proliferation Financing Risks (22 Dec 2021) · MSSB/MIS_06/2021](<EN/09_High_Circular - Identification and Mitigation of Proliferation Financing Risks (22 Dec 2021).pdf>) | Institutional proliferation-financing risk assessment and mitigation. | Read in full with guideline chapters 2 and 6, including review of existing business and customers. |

## Medium priority · essential

| Number | Publication and original | What it is | Reading focus |
|---|---|---|---|
| <a id="doc-10"></a><a id="related-10"></a>10 | [Guideline on Criteria for Determining Fitness and Propriety (Apr 2018)](<EN/10_Medium-Essential_Guideline on Criteria for Determining Fitness and Propriety (Apr 2018).pdf>) | Criteria for fitness and propriety. | Read with the supplement; distinguish adverse factors from automatic exclusions. |
| <a id="doc-11"></a><a id="related-11"></a>11 | [Supplementary Guideline on Fitness and Propriety (Jan 2020)](<EN/11_Medium-Essential_Supplementary Guideline on Fitness and Propriety (Jan 2020).pdf>) | Supplementary fitness and propriety criteria. | Read competence, integrity, business intent, consumer interests and continuing compliance. |
| <a id="doc-14"></a><a id="related-14"></a>14 | [Disciplinary Action Guideline on Pecuniary Penalty (Apr 2018)](<EN/14_Medium-Essential_Disciplinary Action Guideline on Pecuniary Penalty (Apr 2018).pdf>) | Pecuniary penalties for licensing and operating breaches. | Read with AMLO sections 43 and 45; distinguish from disciplinary fining. |
| <a id="doc-15"></a><a id="related-15"></a>15 | [Disciplinary Fining Guideline (May 2018)](<EN/15_Medium-Essential_Disciplinary Fining Guideline (May 2018).pdf>) | Disciplinary fining for specified AML/CFT breaches. | Read with sections 21 and 23: seriousness, deterrence, remediation, cooperation and history. |
| <a id="doc-16"></a><a id="related-16"></a>16 | [Circular - ML-TF Risks of Delivery Channels (13 Dec 2021) · MSSB/MIS_05/2021](<EN/16_Medium-Essential_Circular - ML-TF Risks of Delivery Channels (13 Dec 2021).pdf>) | Risks arising from delivery channels and counterparties. | Read pre-engagement assessment, periodic review and suspicious transaction follow-up. |
| <a id="doc-18"></a><a id="related-18"></a>18 | [Circular - E-submission of the Periodic Return (30 May 2025) · MSSB/MIS_02/2025](<EN/18_Medium-Essential_Circular - E-submission of the Periodic Return (30 May 2025).pdf>) | Electronic periodic returns, reporting periods and data fields. | Study half-yearly submission, periods, electronic format and required fields. |
| <a id="doc-19"></a><a id="related-19"></a>19 | [Circular - Amendments to the Money Changers Ordinance Cap 34 (17 Nov 2025) · MSSB/MIS_04/2025](<EN/19_Medium-Essential_1_Circular - Amendments to the Money Changers Ordinance Cap 34 (17 Nov 2025).pdf>) | Notice of amendments to the Money Changers Ordinance. | Read the short notice, then sections 3-8 and Schedules 1-3 of the full Ordinance immediately after it. No separate pass through the archived item 20 extract is needed. |
| 19 supplement | **Full Money Changers Ordinance, Cap. 34** · [Bilingual original](<EN/19_Medium-Essential_2_Supplement - Full Cap 34 (2025-08-24, Bilingual).pdf>) | Complete bilingual verified law, separate from its circular. | Bilingual verified copy dated 24 August 2025, including sections 1-11 and Schedules 1-3. Focus on sections 3-8 and all three schedules; this includes the former item 20 extract. The 17 PDF pages contain facing legislative pages; use printed page labels for citations. |
| <a id="doc-21"></a><a id="related-21"></a>21 | [Circular - Trade-based Money Laundering Guidance (20 Jan 2026) · MSSB/MIS_01/2026](<EN/21_Medium-Essential_Circular - Trade-based Money Laundering Guidance (20 Jan 2026).pdf>) | Trade-based money laundering risks and controls. | Read customer/funds checks, alerts, analysis and reporting, then the risk indicators. |
| <a id="doc-23"></a><a id="related-23"></a>23 | [Circular - Statements issued by the FATF (3 Jul 2026) · MSSB/FATF_02/2026](<EN/23_Medium-Essential_Circular - Statements issued by the FATF (3 Jul 2026).pdf>) | FATF statements on high-risk and monitored jurisdictions. | Learn the different responses and check for a newer statement before the exam. |

## Medium priority · selected reading

| Number | Publication and original | What it is | Reading focus |
|---|---|---|---|
| <a id="doc-12"></a><a id="related-12"></a>12 | [Guidelines for Submission of Business Plan (Ver 12-2019)](<EN/12_Medium-Selected_Guidelines for Submission of Business Plan (Ver 12-2019).pdf>) | Required contents of a business plan. | Understand the business model, customers, jurisdictions, funds, staff, agents and outsourcing. |
| <a id="doc-13"></a><a id="related-13"></a>13 | [Guidelines for Submission of AML-CFT Policy (Ver 12-2019)](<EN/13_Medium-Selected_Guidelines for Submission of AML-CFT Policy (Ver 12-2019).pdf>) | Required contents of an AML/CFT policy. | Use as a checklist for risk assessment, compliance, reporting, training, monitoring and audit. |
| <a id="doc-17"></a><a id="related-17"></a>17 | [Circular - Cross-boundary Movement of Currency Ordinance Cap 629 (31 Jul 2018) · MSSB/MIS_06/2018](<EN/17_Medium-Selected_1_Circular - Cross-boundary Movement of Currency Ordinance Cap 629 (31 Jul 2018).pdf>) | Summary of cross-boundary currency and bearer instrument requirements. | Distinguish thresholds, arrival/departure, passengers and cargo. |
| 17 supplement | **Full Cross-boundary Movement of Physical Currency and Bearer Negotiable Instruments Ordinance, Cap. 629** · [Bilingual original](<EN/17_Medium-Selected_2_Supplement - Full Cap 629 (2026-07-31, Bilingual).pdf>) | Complete bilingual verified law, separate from its circular. | Bilingual verified copy dated 31 July 2026, including Parts 1-4 and Schedules 1-6. Read definitions, passenger/cargo declaration and disclosure duties and the Schedule 4 threshold alongside the circular. Check control points against Schedule 1 of this edition. Use section numbers and printed legislative page labels when citing. |
| <a id="doc-22"></a><a id="related-22"></a>22 | [Trade-Based Money Laundering Risk Indicators - FATF and Egmont (Mar 2021)](<EN/22_Medium-Selected_Trade-Based Money Laundering Risk Indicators - FATF and Egmont (Mar 2021).pdf>) | Joint FATF/Egmont trade-based money laundering risk indicators. | Read the handling notes and four indicator groups; understand rather than memorise the lists. |
| <a id="doc-25"></a><a id="related-25"></a>25 | [Hong Kong Money Laundering and Terrorist Financing Risk Assessment Report (2022)](<EN/25_Medium-Selected_Hong Kong Money Laundering and Terrorist Financing Risk Assessment Report (2022).pdf>) | Hong Kong territory-wide and sectoral risk assessment. | Focus on section 5.4 and MSO cases; selectively read TF and PF chapters. |
| <a id="doc-26"></a><a id="related-26"></a>26 | [Circular - United Nations Sanctions - Principles and Early Alerts (7 Feb 2018) · MSSB/SAN_01/2018](<EN/26_Medium-Selected_Circular - United Nations Sanctions - Principles and Early Alerts (7 Feb 2018).pdf>) | Principles of UN sanctions screening and early alerts. | Read alongside guideline chapter 6, including sanctions not yet implemented locally. |

## Online reading still required

The two FATF statements dated 19 June 2026 and June plenary outcomes linked by item 23 still have no complete local copies. Check for newer lists before the exam.

- 17 · [Official CBNI information page](https://www.customs.gov.hk/en/service-enforcement-information/anti-money-laundering/cds/index.html)
- 23 · [High-Risk Jurisdictions subject to a Call for Action](https://www.fatf-gafi.org/en/publications/High-risk-and-other-monitored-jurisdictions/call-for-action-june-2026.html)
- 23 · [Jurisdictions under Increased Monitoring](https://www.fatf-gafi.org/en/publications/High-risk-and-other-monitored-jurisdictions/increased-monitoring-june-2026.html)
- 23 · [Outcomes FATF Plenary, 17-19 June 2026](https://www.fatf-gafi.org/en/publications/Fatfgeneral/outcomes-fatf-plenary-june-2026.html)
- 26 · [Current UN sanctions committee information](https://main.un.org/securitycouncil/en/sanctions/information)

## Use and maintenance

Item 22 gives the English original directly in TC, replacing a pointer-only file; it is not a Chinese translation. Item 20 is archived; use the full Cap. 34 under item 19.

The two full companion laws are not automatically bank sources. Question IDs, answers and existing citation numbers are unchanged. All 23 original bank sources, including circulars outside daily reading, remain tracked with original text.

[Source maintenance](SOURCE-MAINTENANCE.md) · [Question source mapping](QUESTION-SOURCES.md) · [Complete register](catalog.json)

Rights remain with the publishers; the repository MIT licence does not license their texts. See [content licensing](../LICENSE-CONTENT.md).
