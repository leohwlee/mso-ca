"""Build and validate selected reading folders and the reference archive."""
import hashlib
import json
import pathlib
import posixpath
import sys
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
PRIORITIES = {'high': ('高', 'High'), 'medium': ('中', 'Medium'), 'low': ('低', 'Low')}

def primary_path(doc, lang):
    e = doc['editions'][lang]
    return e.get('path', f'{lang}/{e["file"]}')

def active(item):
    return item.get('reading_status', 'active') == 'active'

def title(doc, lang):
    value = pathlib.Path(doc['editions'][lang]['file']).stem.split('_', 2)[2]
    value = value[2:] if value.startswith('1_') else value
    return value + (' · ' + doc['circular'] if doc.get('circular') else '')

def link(path, label, archive=False):
    return f'[{label}](<{posixpath.relpath(path, "archive") if archive else path}>)'

def count(catalog, wanted):
    return sum(active(d)==wanted for d in catalog['documents']) + sum(active(c)==wanted for d in catalog['documents'] for c in d.get('companions',[]))

def companion_links(companion, lang, archive=False):
    result=[]
    for language,e in companion['editions'].items():
        path=e.get('copies',{}).get(lang,e['file'])
        label=('中英雙語原件' if lang=='TC' else 'Bilingual original') if language=='BI' else language
        result.append(link(path,label,archive))
    return ' · '.join(result)

def render(catalog, lang):
    tc=lang=='TC';docs=catalog['documents']
    def text(zh,en):return zh if tc else en
    lines=[text('# MSO 精簡閱讀目錄','# MSO focused reading directory'),'',
           text('[English →](README.md)','[繁體中文 →](README.zh-Hant.md)'),'',
           text('日常閱讀保留 **26項材料：24份主材料＋2份完整法例**。全部原件直接放在[中文資料夾](TC/)及[英文資料夾](EN/)，每個資料夾26份。雙語法例各放一份，配套緊跟對應通函。','**26 publications for daily reading: 24 main materials and 2 complete companion laws.** All originals are directly in [TC](TC/) and [EN](EN/), 26 files per folder. Each bilingual law is copied to both folders and follows its circular.'),'',
           text('按檔名排序即可。仍只用原來一套閱讀編號；精簡後空缺的編號對應已移出的資料，不另編一套來源ID。中優先級檔名已標「中重點」或「中選讀」；同一編號先讀通函，再讀「配套」。','Sort by filename. The single document-number sequence is retained; gaps identify materials moved out of daily reading, without a second source-ID system. Medium filenames distinguish Essential and Selected reading. For the same number, read the circular before its Supplement.'),'',
           text('**最先掌握03、04、05**：反洗錢指引、第615章及牌照指引。01、02先快速了解考試及試題；06至09用來補足實際應用和明確監管要求。完成高優先級後，先讀「中重點」，再按薄弱範圍讀「中選讀」。','**Master 03, 04 and 05 first:** the AML/CFT Guideline, Cap. 615 and Licensing Guide. Skim 01-02 for exam setup and examples; use 06-09 for application and specific expectations. After High, finish Medium Essential before selecting weaker topics from Medium Selected.'),'',
           text('依據：[官方《能力評核須知》第5.2至6.1段](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_zh_TW.pdf)。七個單元涵蓋法例、核心指引、其他指引及通函；以下是復習建議，並非官方出題權重。','Basis: [official Guidance Notes, paragraphs 5.2-6.1](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_en.pdf). The seven-module syllabus includes law, core and other guidelines, and circulars. These are study recommendations, not official exam weights.'),'',
           text('從47項收錄材料中移出21項：完整法例已覆蓋的摘錄、舊期通知、重複培訓、歷史決議及較遠離核心範圍的材料，見[移出清單及原因](archive/README.zh-Hant.md)。原件及題庫證據仍保留；移出不代表失效或不會考，現有題庫仍可能引用其中的通函。','21 of the 47 publications have been removed from daily reading: covered extracts, old notices, repeat training, historical resolutions and lower-priority extensions. See [the decisions and reasons](archive/README.md). Originals and question evidence remain. Archiving does not establish withdrawal or exam exclusion; existing questions may still cite archived circulars.'),'']
    for focus,zh,en in [('core','高優先級 · 先讀','High priority · first pass'),('focus','中優先級 · 重點','Medium priority · essential'),('select','中優先級 · 選讀','Medium priority · selected reading')]:
        lines += ['## '+text(zh,en),'',text('| 編號 | 文件及本地原件 | 它是甚麼 | 閱讀重點 |','| Number | Publication and original | What it is | Reading focus |'),'|---|---|---|---|']
        for d in docs:
            if not active(d) or d['study_focus']!=focus:continue
            note=' **英文原文，非中文譯本**' if tc and d['editions'][lang].get('language')=='EN' else ''
            anchors=f'<a id="doc-{d["id"]}"></a><a id="related-{d["id"]}"></a>'
            lines.append(f'| {anchors}{d["id"]} | {link(primary_path(d,lang),title(d,lang))}{note} | {d["summary"][lang]} | {d["reading"][lang]} |')
            for c in d.get('companions',[]):
                if active(c):lines.append(f'| {d["id"]} '+text('配套','supplement')+f' | **{c["title"][lang]}** · {companion_links(c,lang)} | '+text('完整中英雙語經核證法例；與通函是不同原件。','Complete bilingual verified law, separate from its circular.')+f' | {c["reading"][lang]} |')
        lines += ['']
    lines += [text('## 尚需在線查閱','## Online reading still required'),'',text('第23項所指的兩份2026年6月19日FATF聲明及6月全體會議成果仍沒有完整本地副本，不能視作已下載；名單可能更新，考前核對最新版本。','The two FATF statements dated 19 June 2026 and June plenary outcomes linked by item 23 still have no complete local copies. Check for newer lists before the exam.'),'']
    for d in docs:
        if active(d):
            for r in d.get('online_references',[]):lines.append(f'- {d["id"]} · [{r["title"][lang]}]({r["url"]})')
    lines += ['',text('## 使用及維護','## Use and maintenance'),'',
              text('第22項在中文資料夾直接放英文原件，已移出只有連結的中文閱讀入口；沒有冒充官方中文譯本。第20項摘錄移入歷史資料，完整第34章在第19項配套。','Item 22 gives the English original directly in TC, replacing a pointer-only file; it is not a Chinese translation. Item 20 is archived; use the full Cap. 34 under item 19.'),'',
              text('兩部完整法例是配套閱讀，未自動成為題庫引用來源。題號、答案及現有引用編號均未改。原有23份題庫來源，包括移出日常閱讀的通函，其原件及擷取文字仍由目錄追蹤。','The two full companion laws are not automatically bank sources. Question IDs, answers and existing citation numbers are unchanged. All 23 original bank sources, including circulars outside daily reading, remain tracked with original text.'),'',
              text('[來源維護說明](SOURCE-MAINTENANCE.zh-Hant.md) · [題庫來源對照](QUESTION-SOURCES.zh-Hant.md) · [完整資料登記](catalog.json)','[Source maintenance](SOURCE-MAINTENANCE.md) · [Question source mapping](QUESTION-SOURCES.md) · [Complete register](catalog.json)'),'',
              text('官方原件的權利仍屬發布機構；本庫MIT授權不授予這些原文的使用權。見[內容授權](../LICENSE-CONTENT.md)。','Rights remain with the publishers; the repository MIT licence does not license their texts. See [content licensing](../LICENSE-CONTENT.md).'),'']
    return '\n'.join(lines)

def render_archive(catalog,lang):
    tc=lang=='TC'
    def text(zh,en):return zh if tc else en
    lines=[text('# 移出日常閱讀的材料','# Materials removed from daily reading'),'',text('[返回精簡閱讀目錄](../README.zh-Hant.md)','[Back to focused reading](../README.md)'),'',
           text('共21項，保留原件供查閱及驗證題庫，不需要在第一輪逐份閱讀。這是復習取捨，不是判定文件已失效。部分材料仍有獨立例子或歷史資訊；只是不再列入日常閱讀。','21 publications retained for reference and bank-source verification, outside first-pass reading. This is a study selection, not a withdrawal finding. Some contain distinct examples or history; they are not additional daily required reading.'),'',
           text('| 原編號 | 文件及原件 | 移出原因／改讀甚麼 |','| Number | Publication and original | Reason / replacement reading |'),'|---|---|---|']
    for d in catalog['documents']:
        if not active(d):
            files=' · '.join(link(primary_path(d,l),l,True) for l in ['TC','EN'])
            lines.append(f'| {d["id"]} | **{title(d,lang)}** · {files} | {d["archive_reason"][lang]} |')
        for c in d.get('companions',[]):
            if not active(c):lines.append(f'| {d["id"]} '+text('配套','supplement')+f' | **{c["title"][lang]}** · {companion_links(c,lang,True)} | {c["archive_reason"][lang]} |')
    lines += ['',text('[先前下載核對記錄](link-review.json)','[Earlier download review](link-review.json)'),'',text('第22項舊中文入口另存於`superseded/`，已由中文閱讀資料夾中的英文原件取代。原件權利仍屬各發布機構，見[內容授權](../../LICENSE-CONTENT.md)。','The superseded item 22 Chinese pointer is in `superseded/`; TC now contains the English original. Rights remain with the publishers; see [content licensing](../../LICENSE-CONTENT.md).'),'']
    return '\n'.join(lines)

def main():
    cat=json.loads((HERE/'catalog.json').read_text(encoding='utf8'));docs=cat['documents'];tracked=set()
    assert [d['id'] for d in docs]==[f'{i:02d}' for i in range(1,len(docs)+1)]
    assert sum(d['original_bank_source'] for d in docs)==23
    def verify(path,expected,text=False):
        p=(HERE/path).resolve();assert p.is_relative_to(HERE.resolve()) and p.is_file(),path
        assert p not in tracked,f'Duplicate file: {path}'
        tracked.add(p);raw=p.read_bytes();normal=raw.replace(b'\r\n',b'\n') if text else raw
        assert hashlib.sha256(normal).hexdigest()==expected,path
        if p.suffix=='.pdf':assert raw.startswith(b'%PDF-'),path
        if p.suffix=='.docx':
            with zipfile.ZipFile(p) as z:assert 'word/document.xml' in z.namelist()
    for d in docs:
        assert d['priority'] in PRIORITIES
        for lang,e in d['editions'].items():
            path=primary_path(d,lang);assert pathlib.PurePosixPath(path).name==e['file'] and e['file'].startswith(d['id']+'_'),path
            assert str(pathlib.PurePosixPath(path).parent)==(lang if active(d) else f'archive/{lang}'),path
            verify(path,e['sha256'],path.endswith('.md'))
        for c in d.get('companions',[]):
            assert set(c['title'])==set(c['reading'])=={'TC','EN'}
            for language,e in c['editions'].items():
                paths=e.get('copies',{language:e['file']});assert e['file'] in paths.values()
                for lang,path in paths.items():
                    if active(c):
                        assert lang in {'TC','EN'} and pathlib.PurePosixPath(path).parent==pathlib.PurePosixPath(lang)
                        assert pathlib.PurePosixPath(path).name.startswith(d['id']+'_')
                        assert pathlib.PurePosixPath(primary_path(d,lang)).name<pathlib.PurePosixPath(path).name,path
                    else:assert path.startswith(f'archive/related/{d["id"]}/'),path
                    verify(path,e['sha256'])
                if language=='BI' and active(c):assert set(paths)=={'TC','EN'}
                verify(e['text_file'],e['text_sha256'],True)
    for e in cat.get('retired_files',[]):verify(e['path'],e['sha256'],True)
    for lang in ['TC','EN']:
        assert {p.resolve() for p in (HERE/lang).iterdir() if p.is_file()}=={p for p in tracked if p.parent==(HERE/lang).resolve()},f'Unexpected files in {lang}'
    actual={p.resolve() for p in (HERE/'archive').rglob('*') if p.suffix in {'.pdf','.docx','.html','.md','.txt'} and p.name not in {'README.md','README.zh-Hant.md'}}
    assert actual=={p for p in tracked if p.is_relative_to((HERE/'archive').resolve())},'Uncatalogued or missing archive files'
    for name,content in [('README.zh-Hant.md',render(cat,'TC')),('README.md',render(cat,'EN')),('archive/README.zh-Hant.md',render_archive(cat,'TC')),('archive/README.md',render_archive(cat,'EN'))]:
        target=HERE/name
        if '--check' in sys.argv:assert target.read_text(encoding='utf8')==content,f'Regenerate {target}'
        elif not target.exists() or target.read_text(encoding='utf8')!=content:target.write_text(content,encoding='utf8',newline='\n')
    print(f'Checked {count(cat,True)} selected publications, {count(cat,False)} reference publications, all original hashes and four directories.')

if __name__=='__main__':main()
