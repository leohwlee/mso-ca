import pathlib,json,hashlib,zipfile,copy,collections
ROOT=pathlib.Path(__file__).resolve().parent;TMP=ROOT/'tmp/continuous-numbering';TMP.mkdir(parents=True,exist_ok=True)
archive=ROOT/'bank/audit/history/2026-10-18-before-continuous-numbering.zip'
assert not archive.exists(),'Preflight snapshot already exists; inspect before continuing.'
files=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.md','.txt','.json','.py','.go','.html','.yml','.toml'} and not any(x in p.relative_to(ROOT).parts for x in ['.git','tmp','dist','__pycache__','history'])]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(ROOT).as_posix())
old=json.loads((ROOT/'docs/catalog.json').read_text(encoding='utf8'))
main={d['id']:d for d in old['documents']}
ordered=[]
for focus in ['core','focus','select']:
 for d in old['documents']:
  if d['reading_status']=='active' and d['study_focus']==focus:
   ordered.append(('main',d['id'],None,d))
   for i,c in enumerate(d.get('companions',[])):
    if c['reading_status']=='active':ordered.append(('companion',d['id'],i,c))
assert len(ordered)==26
for d in old['documents']:
 if d['reading_status']=='archive':ordered.append(('main',d['id'],None,d))
 for i,c in enumerate(d.get('companions',[])):
  if c['reading_status']=='archive':ordered.append(('companion',d['id'],i,c))
assert len(ordered)==47
mapping={parent:f'{n:02d}' for n,(kind,parent,i,d) in enumerate(ordered,1) if kind=='main'}
plan=[{'kind':kind,'old_parent':parent,'companion_index':i,'new':f'{n:02d}','focus':d['study_focus']} for n,(kind,parent,i,d) in enumerate(ordered,1)]
assert mapping['18']=='15' and mapping['17']=='22' and mapping['19']=='16'
def remap(obj):
 if isinstance(obj,list):return [remap(x) for x in obj]
 if isinstance(obj,dict):return {k:(mapping[v] if k=='doc' else remap(v)) for k,v in obj.items()}
 return obj
def digest(obj,newline):return hashlib.sha256((json.dumps(obj,ensure_ascii=False,indent=1)+'\n').replace('\n',newline).encode()).hexdigest()
q=json.loads((ROOT/'docs/quotes.json').read_text(encoding='utf8'))
hashes={};snapshots=[]
def record(name,quotes,expected=None,newline=None):
 new=remap(quotes)
 if expected:assert digest(quotes,newline)==expected,name
 for nl in ['\n','\r\n']:
  before=digest(quotes,nl);after=digest(new,nl)
  assert before not in hashes or hashes[before]==after
  hashes[before]=after
 snapshots.append({'name':name,'questions':len(quotes),'before_sha256':digest(quotes,newline or '\n'),'after_sha256':digest(new,newline or '\n')})
record('active',q)
for filename in ['remaining-implementation.json','p1-implementation.json','implementation.json']:
 r=json.loads((ROOT/'bank/audit'/filename).read_text(encoding='utf8'))
 for replacement in r.get('replacements',[]):q[replacement['old_id']]=replacement['quotes']
 b=r['baseline'];q={qid:q[qid] for qid in b['quote_order']}
 record(filename+' baseline',q,b['sha256']['docs/quotes.json'],b['newline']['docs/quotes.json'])
coverage=json.loads((ROOT/'bank/audit/coverage.json').read_text(encoding='utf8'))
added={qid for f in coverage['implemented_followups'] for qid in f['question_ids']}
base={qid:v for qid,v in q.items() if qid not in added}
expected=coverage['baseline']['sha256']['docs/quotes.json']
nl=next(nl for nl in ['\n','\r\n'] if digest(base,nl)==expected)
record('initial coverage baseline',base,expected,nl)
fields=collections.Counter()
def scan(x,key=''):
 if isinstance(x,dict):
  for k,v in x.items():scan(v,k)
 elif isinstance(x,list):
  for v in x:scan(v,key+'[]')
 elif isinstance(x,str) and len(x)==2 and x.isdigit():fields[key]+=1
for p in (ROOT/'bank/audit').glob('*.json'):scan(json.loads(p.read_text(encoding='utf8')))
state={'archive':archive.relative_to(ROOT).as_posix(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'mapping':mapping,'plan':plan,'quote_hashes':hashes,'snapshots':snapshots,'question_bank_sha256':hashlib.sha256((ROOT/'web/questions.json').read_bytes()).hexdigest()}
(TMP/'plan.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf8')
print('Verified all 5 quote versions against their original hashes before deriving new hashes.')
print('Document-number fields:',dict(fields))
print('New active order:',[(p['new'],p['old_parent'],p['kind']) for p in plan[:26]])
