# Working on MSO sources and questions

- Before editing questions, revision content, sources or reading order, read
  [source maintenance](docs/SOURCE-MAINTENANCE.md),
  [question format](bank/FORMAT.md) and the applicable authoring guide.
- Use ONE document number: the reading order in `docs/catalog.json` is also the
  filename prefix, quote `doc`, extracted-text filename and transcript filename.
  `03` is the AML/CFT Guideline; `04` is Cap. 615. Do not add a second source ID.
- There are 32 reading materials. The bank and coverage audits still cover the
  original 23, marked `original_bank_source` in the catalog. Verify edition,
  language, content and citation mapping before using an addition in questions.
  Reading pointers and statutory extracts are not complete source publications.
- Companion originals use the parent document's number under `docs/related/NN/`.
  Their editions, reading notes and hashes are in the catalog. They are not the
  parent circular's body and are not yet additional question-bank sources.
- Preserve question IDs and historical evidence. If reading order changes,
  migrate all document references together and verify the migration. Keep prior
  evidence as history; do not replace hashes merely to silence failures.
- Run `python docs/build_catalog.py --check` and `go test ./...` for source changes.
  For question or evidence changes also run the four audit checks in
  `DEVELOPMENT.md`. Build both HTML outputs when generation may be affected.
