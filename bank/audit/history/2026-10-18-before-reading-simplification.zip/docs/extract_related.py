"""Extract companion files without changing the question bank's source texts.

    python docs/extract_related.py

Requires PyMuPDF for PDFs. DOCX and HTML use the Python standard library.
The catalog records raw-source and LF-normalized extracted-text hashes.
"""
import hashlib
from html.parser import HTMLParser
import json
import pathlib
import re
import xml.etree.ElementTree as ET
import zipfile

HERE = pathlib.Path(__file__).resolve().parent


class HTMLText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ignored = 0
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag in {'script', 'style'}:
            self.ignored += 1
        if tag in {'p', 'div', 'br', 'h1', 'h2', 'li'}:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in {'script', 'style'}:
            self.ignored -= 1

    def handle_data(self, data):
        if not self.ignored:
            self.parts.append(data)


def extract(path):
    if path.suffix == '.pdf':
        import pymupdf
        with pymupdf.open(path) as pdf:
            return '\f'.join(page.get_text() for page in pdf)
    if path.suffix == '.docx':
        with zipfile.ZipFile(path) as archive:
            document = ET.fromstring(archive.read('word/document.xml'))
        ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        return '\n'.join(''.join(p.itertext()) for p in document.findall('.//w:p', ns))
    if path.suffix == '.html':
        parser = HTMLText()
        parser.feed(path.read_text(encoding='utf8'))
        return re.sub(r'\n\s*\n+', '\n\n', ''.join(parser.parts)).strip() + '\n'
    raise ValueError(f'Unsupported companion: {path}')


def main():
    catalog_path = HERE / 'catalog.json'
    catalog = json.loads(catalog_path.read_text(encoding='utf8'))
    count = 0
    for doc in catalog['documents']:
        for companion in doc.get('companions', []):
            for edition in companion['editions'].values():
                source = HERE / edition['file']
                assert source.resolve().is_relative_to((HERE/'related'/doc['id']).resolve())
                assert hashlib.sha256(source.read_bytes()).hexdigest() == edition['sha256'], source
                target = source.with_suffix('.txt')
                text = extract(source).replace('\r\n', '\n')
                target.write_text(text, encoding='utf8', newline='\n')
                edition['text_file'] = target.relative_to(HERE).as_posix()
                edition['text_sha256'] = hashlib.sha256(text.encode('utf8')).hexdigest()
                count += 1
    catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2)+'\n', encoding='utf8', newline='\n')
    print(f'Extracted {count} companion editions; primary texts and quotes unchanged.')


if __name__ == '__main__':
    main()
