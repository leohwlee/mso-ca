"""Generate the bilingual reading directory from catalog.json.

    python docs/build_catalog.py          # write both README files
    python docs/build_catalog.py --check  # verify links, order, hashes and saved output

One document number is shared by reading order, filenames, quotes and audits.
"""
import hashlib
import json
import pathlib
import sys
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
PRIORITIES = {'high': ('高', 'High'), 'medium': ('中', 'Medium'), 'low': ('低', 'Low')}


def local_link(lang, edition):
    return f'[{lang}](<{lang}/{edition["file"]}>)'


def render(catalog, lang):
    tc = lang == 'TC'
    documents = catalog['documents']
    companions = [c for d in documents for c in d.get('companions', [])]
    edition_count = sum(len(c['editions']) for c in companions)
    lines = [
        '# MSO 官方資料閱讀目錄' if tc else '# MSO official reading directory', '',
        '[English version →](README.md)' if tc else '[繁體中文版 →](README.zh-Hant.md)', '',
        ('共 **32 項材料**，按「高 → 中 → 低」及同級建議閱讀順序排列：高9項、中19項、低4項。'
         '在 `TC/` 或 `EN/` 按檔名排序，順次閱讀即可。'
         if tc else
         '**32 materials**, sorted by High → Medium → Low and recommended reading sequence within each level: '
         '9 high, 19 medium, 4 low. Sort filenames in `EN/` or `TC/` and read in order.'), '',
        ('檔名格式：`閱讀序號_優先級_文件名稱（版本）`，例如 `03_高_…`。同一序號的中英文檔案對應同一材料。'
         if tc else
         'Filename format: `reading-order_priority_title (version)`, for example `03_High_…`. '
         'English and Chinese files with the same reading number refer to the same material.'), '',
        (f'另有**{len(companions)}項配套資料、{edition_count}個原始檔案**，存於`related/通函編號/`，見各通函的配套閱讀。'
         '沿用主文件編號，不另設一套來源ID。'
         if tc else
         f'Also archived: **{len(companions)} companion publications, {edition_count} original files**, under `related/circular-number/`. '
         'They use the parent document number, without a second source-ID system.'), '',
        ('優先級是根據官方考綱及文件內容作出的復習建議，並非海關公布的出題權重。'
         '高：第一輪重點讀；中：第二輪完整讀或按建議選讀；低：最後快速讀。低優先級不表示不會考。'
         if tc else
         'Priorities are study recommendations based on the official syllabus and document content, not published exam weights. '
         'High: first-pass essentials; Medium: second-pass reading or selected sections; Low: a final quick pass. Low does not mean unexaminable.'), '',
        ('官方依據：《能力評核須知》第5.2至6.1段。七個單元各5題；每單元至少答對3題，總分至少25/35。'
         '參考類別包括第615章、反洗錢指引、牌照指引、其他指引及通函。'
         if tc else
         'Basis: Guidance Notes paragraphs 5.2-6.1. There are seven modules of five questions; passing requires '
         'at least three correct in every module and at least 25/35 overall. References include Cap. 615, '
         'the AML/CFT Guideline, Licensing Guide, other guidelines and circulars.'), '',
        '[官方考試須知 / Official Guidance Notes](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_zh_TW.pdf)', '',
    ]
    for priority in PRIORITIES:
        label = PRIORITIES[priority][0 if tc else 1]
        lines += [f'## {label}' + ('優先級' if tc else ' priority'), '',
                  '| 順序 | 材料及本地檔案 | 它是甚麼 | 閱讀重點 |' if tc else
                  '| Order | Material and local files | What it is | Reading focus |',
                  '|---|---|---|---|']
        for doc in documents:
            if doc['priority'] != priority:
                continue
            title = pathlib.Path(doc['editions'][lang]['file']).stem.split('_', 2)[2]
            if doc.get('circular'):
                title += ' - ' + doc['circular']
            links = ' · '.join(local_link(l, doc['editions'][l]) for l in ['TC', 'EN'])
            if doc.get('companions') or doc.get('related_documents') or doc.get('online_references'):
                links += f'<br>[{"配套資料及引用去向" if tc else "Companions and linked materials"}](#related-{doc["id"]})'
            added = (' **新增**' if tc else ' **Added**') if not doc['original_bank_source'] else ''
            lines.append(f'| {doc["id"]} | **{title}**{added}<br>{links} | {doc["summary"][lang]} | {doc["reading"][lang]} |')
        lines += ['']
    lines += ['## 通函配套資料及閱讀去向' if tc else '## Circular companions and linked materials', '',
              ('先看通函的本地要求，再讀其指向的材料。已有原件只連結一次；內附附件不拆成重複檔案。'
               '下表的優先級是配套材料本身的閱讀建議。下載不代表已納入題庫。'
               if tc else
               'Read local expectations in the circular before its linked publication. Existing sources are linked rather than duplicated; '
               'embedded appendices stay in their PDFs. Priorities below apply to the companion itself. Downloading does not establish question-bank coverage.'), '']
    by_id = {d['id']: d for d in documents}
    language_labels = {'EN': ('英文', 'English'), 'TC': ('繁體中文', 'Traditional Chinese'),
                       'BI': ('中英雙語', 'Bilingual'), 'ZH': ('簡體中文', 'Simplified Chinese')}
    for doc in documents:
        if not (doc.get('companions') or doc.get('related_documents') or doc.get('online_references')):
            continue
        title = pathlib.Path(doc['editions'][lang]['file']).stem.split('_', 2)[2]
        lines += [f'<a id="related-{doc["id"]}"></a>', '', f'### {doc["id"]} · {title}', '']
        if doc.get('related_documents'):
            linked = []
            for num in doc['related_documents']:
                target = by_id[num]['editions'][lang]
                name = pathlib.Path(target['file']).stem.split('_', 2)[2]
                linked.append(f'[{num} {name}](<{lang}/{target["file"]}>)')
            lines += [('庫內已有：' if tc else 'Already in the archive: ') + ' · '.join(linked), '']
        if doc.get('companions'):
            lines += ['| 配套原件 | 優先級 | 本地下載 | 閱讀重點及版本 |' if tc else
                      '| Companion publication | Priority | Local files | Reading focus and edition |', '|---|---|---|---|']
            for companion in doc['companions']:
                files = []
                for language, edition in companion['editions'].items():
                    label = language_labels[language][0 if tc else 1]
                    pages = f' · {edition["pages"]}' + ('頁' if tc else ' pages') if edition.get('pages') else ''
                    files.append(f'[{label} {pathlib.Path(edition["file"]).suffix[1:].upper()}{pages}](<{edition["file"]}>) · '
                                 f'[{"文字" if tc else "Text"}](<{edition["text_file"]}>) · '
                                 f'[{"官方來源" if tc else "Official source"}]({edition["url"]})')
                priority = PRIORITIES[companion['priority']][0 if tc else 1]
                lines.append(f'| {companion["title"][lang]} | {priority} | {"<br>".join(files)} | {companion["reading"][lang]} |')
            lines += ['']
        if doc.get('online_references'):
            lines += [('僅在線入口（未另存完整檔案）：' if tc else 'Online resources (not archived as complete local files):'), '']
            for resource in doc['online_references']:
                lines.append(f'- [{resource["title"][lang]}]({resource["url"]})：{resource["note"][lang]}')
            lines += ['']
    lines += [
        ('其餘通函核對：07的附錄及18的申報表附件已包含在原PDF內；30有實質防詐提醒，沒有另外指向教材下載。'
         '26的五份歷史決議已補入，但不替代最新制裁名單。29提及的較早風險評估，復習優先看25的2022年報告。'
         if tc else
         'Other circulars checked: 07 already includes its appendix and 18 its return-form annex. 30 contains substantive fraud-prevention advice and no separate publication download. '
         '26 now includes the five historical resolutions, which do not replace current lists. For the earlier risk assessment mentioned in 29, prioritise the 2022 report in 25.'), '',
        ('FATF英文原件沒有冒充繁中譯本；聯合國中文決議保留官方簡體。32的原始草案為DOCX，諮詢已結束，不能當作香港已生效要求。'
         if tc else
         'FATF English originals are not labelled as Traditional Chinese translations. UN Chinese resolutions retain official Simplified Chinese. '
         '32 includes the original DOCX draft; the consultation is closed and its content is not presented as an effective Hong Kong requirement.'), '',
    ]
    lines += ['## 版本、語言及收錄範圍' if tc else '## Editions, languages and scope', '']
    if tc:
        lines += [
            '- 原有23份文件保留原件；另加入9項材料，包括5組建議補充資料、較早機構風險評估通函及兩份培訓講義。',
            '- **第20項**保留第34章附表2及3的官方網頁文字摘錄，不能當作完整條例。2025年8月24日版的完整中英雙語核證PDF現已補入[第19項配套資料](#related-19)，包含第1至11條及附表1至3。摘錄內未能下載PDF的說明屬當時歸檔記錄。',
            '- **第22項**收錄共同發布方Egmont Group官網的FATF／Egmont英文原件。未找到並核實官方繁體中文版，因此TC檔是通往本地英文原件的閱讀入口，不是中文譯本。FATF直接下載回傳403，已改從共同發布方取得原件。',
            '- **第27項**兩個語言版本同於2026年1月7日上載，但官網列出的講座日期不同：中文為2025年11月14日、英文為2025年12月9日。各自保留官方版本，不宣稱是同場逐字翻譯。',
            '- **第28項**講座日期為2024年3月12日，2024年4月12日上載。',
            '- **第04項**第615章沿用2026年9月24日歸檔綜合版；本次未重新核實其是否仍為最新版本。第20項已核實的第34章版本不能替代這項核驗。',
            '- 名單及定期聲明會更新，考前請查海關通函及FATF最新資料。仍被引用的原則性通函可保留；與新指引內容重疊不等於已正式失效。',
            '- 現行題庫和溫習資料仍以原有23份來源為依據；新增9項的收錄不代表題庫已加入或完整測試其考點。培訓講義屬輔助閱讀，不是額外的官方考綱。',
        ]
    else:
        lines += [
            '- The original 23 sources are retained unchanged; nine materials have been added, including the recommended additions, the earlier institutional risk assessment circular and two training decks.',
            '- **Item 20** remains the official-webpage text extract of Cap. 34 Schedules 2 and 3, not the complete Ordinance. The full bilingual verified PDF dated 24 August 2025 is now archived [under item 19](#related-19), including sections 1-11 and Schedules 1-3. The failed-download note in the extract records the earlier archival attempt.',
            '- **Item 22** contains the official English FATF/Egmont PDF downloaded from co-publisher Egmont Group. Its TC file is a reading pointer, not a Chinese translation. The direct FATF download returned 403.',
            '- **Item 27** was uploaded in both languages on 7 January 2026, but the official portal lists different seminar dates: 14 November 2025 for Chinese and 9 December 2025 for English. These are retained as their respective official editions, not described as verbatim translations of one seminar.',
            '- **Item 28** is dated 12 March 2024 and was uploaded on 12 April 2024.',
            '- **Item 04**, Cap. 615, retains the archived consolidated edition dated 24 September 2026. Whether it is still the latest edition was not reverified in this reorganisation.',
            '- Recheck current lists and periodic statements before the exam. Retain still-cited principles circulars; overlap with later guidance does not itself establish formal withdrawal.',
            '- The current bank and revision pack still use the original 23 sources. Archiving the nine additions does not establish question-bank coverage of them. Training decks are reading aids, not an additional official syllabus.',
        ]
    lines += ['', '## 官方來源' if tc else '## Official sources', '',
        ('文件編號就是上面的閱讀順序，也是檔名前綴、題庫引用及擷取文字的編號。'
         if tc else
         'The document number is its reading order, filename prefix and number used in quotes and extracted text.'), '',
        '| 文件編號 | 官方中文來源 | 官方英文來源 |' if tc else
        '| Document | Official Chinese source | Official English source |',
        '|---|---|---|']
    for doc in documents:
        links=[]
        for l in ['TC','EN']:
            ed=doc['editions'][l]
            text='英文原文入口' if l=='TC' and doc['id']=='22' else ('官方來源' if tc else 'Official source')
            links.append(f'[{text}]({ed["url"]})')
        lines.append(f'| {doc["id"]} | {links[0]} | {links[1]} |')
    lines += ['', '## 維護及引用' if tc else '## Maintenance and references', '',
        ('改題、改名或更新官方文件前，先讀[來源維護說明](SOURCE-MAINTENANCE.zh-Hant.md)。全庫只使用這一套文件編號。'
         if tc else
         'Before editing questions, filenames or source content, read [source maintenance](SOURCE-MAINTENANCE.md). The archive uses one document numbering system.'), '',
        ('[`catalog.json`](catalog.json)記錄文件編號、優先級、檔名、官方網址及SHA-256摘要。'
         '例如03是反洗錢指引，對應`text/EN/03.txt`、`text/TC/03.txt`及引文中的`"doc": "03"`。'
         if tc else
         '[`catalog.json`](catalog.json) records document number, priority, filename, official URL and SHA-256. '
         'For example, 03 is the AML/CFT Guideline in filenames, `text/EN/03.txt`, `text/TC/03.txt` and quote field `"doc": "03"`.'), '',
        '```bash', 'python docs/extract_text.py', 'python docs/build_catalog.py --check', 'go test ./...', '```', '',
        ('既有題庫各單元的引用統計見[題庫來源對照](QUESTION-SOURCES.zh-Hant.md)。編號統一前的原始審校證據保存在[歷史存檔](../bank/audit/history/README.md)。'
         if tc else
         'See [question-bank source mapping](QUESTION-SOURCES.md) for the original 23 sources. '
         'Original evidence from before the numbering cleanup is preserved in the [historical archive](../bank/audit/history/README.md).'), '',
        '[海關指引 / Guidelines](https://eservices.customs.gov.hk/MSOS/common/guidelines) · '
        '[海關通函 / Circulars](https://eservices.customs.gov.hk/MSOS/common/circulars) · '
        '[培訓資料 / Capacity building](https://eservices.customs.gov.hk/MSOS/common/capacityBuilding)', '',
        ('官方原文的權利仍屬各發布機構，包括香港特區政府及FATF／OECD與Egmont Group。'
         '本庫的MIT授權不授予這些原文的使用權；詳見[內容授權](../LICENSE-CONTENT.md)。'
         if tc else
         'Rights in official source material remain with its publishers, including the HKSAR Government and FATF/OECD and Egmont Group. '
         'The repository MIT licence grants no rights in those texts; see [content licensing](../LICENSE-CONTENT.md).'), '',
    ]
    return '\n'.join(lines)


def main():
    catalog=json.loads((HERE/'catalog.json').read_text(encoding='utf8'))
    docs=catalog['documents']
    assert [d['id'] for d in docs] == [f'{i:02d}' for i in range(1,len(docs)+1)]
    assert len({d['id'] for d in docs}) == len(docs)
    assert [list(PRIORITIES).index(d['priority']) for d in docs] == sorted(list(PRIORITIES).index(d['priority']) for d in docs)
    seen=set()
    related_seen=set()
    for doc in docs:
        for lang,edition in doc['editions'].items():
            path=HERE/lang/edition['file']
            assert path.parent == HERE/lang and path.is_file(), path
            assert path not in seen, path
            seen.add(path)
            raw=path.read_bytes()
            if path.suffix=='.md':
                raw=raw.replace(b'\r\n',b'\n')
            assert hashlib.sha256(raw).hexdigest()==edition['sha256'], path
            assert path.name.startswith(doc['id'] + '_'), path
        for num in doc.get('related_documents', []):
            assert num in {d['id'] for d in docs} and num != doc['id'], num
        for companion in doc.get('companions', []):
            assert companion['priority'] in PRIORITIES and companion['editions']
            assert set(companion['title']) == set(companion['reading']) == {'EN', 'TC'}
            for edition in companion['editions'].values():
                for key,hash_key in [('file','sha256'),('text_file','text_sha256')]:
                    path=(HERE/edition[key]).resolve()
                    assert path.is_relative_to((HERE/'related'/doc['id']).resolve()), path
                    assert path.is_file() and path not in related_seen, path
                    related_seen.add(path)
                    data=path.read_bytes()
                    if key=='text_file':data=data.replace(b'\r\n',b'\n')
                    assert hashlib.sha256(data).hexdigest()==edition[hash_key], path
                source=HERE/edition['file']
                if source.suffix=='.pdf':assert source.read_bytes().startswith(b'%PDF-'), source
                elif source.suffix=='.docx':
                    with zipfile.ZipFile(source) as archive:assert 'word/document.xml' in archive.namelist()
    related_actual={p.resolve() for p in (HERE/'related').rglob('*') if p.suffix in {'.pdf','.docx','.html','.txt'}}
    assert related_seen==related_actual, 'Uncatalogued or missing companion files/text'
    actual={p for lang in ['EN','TC'] for p in (HERE/lang).iterdir() if p.is_file()}
    assert seen==actual, 'Uncatalogued or missing files'
    for lang,name in [('TC','README.zh-Hant.md'),('EN','README.md')]:
        content=render(catalog,lang)
        target=HERE/name
        if '--check' in sys.argv:
            assert target.read_text(encoding='utf8')==content, f'Regenerate {target}'
        else:
            target.write_text(content,encoding='utf8',newline='\n')
    print(f'Checked {len(docs)} main materials, {len(seen)} main files, {len(related_seen)//2} companion editions and both directories.')


if __name__=='__main__':
    main()
