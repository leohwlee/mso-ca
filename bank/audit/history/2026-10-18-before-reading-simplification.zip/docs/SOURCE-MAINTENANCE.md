# Maintaining the source documents

[繁體中文版 →](SOURCE-MAINTENANCE.zh-Hant.md)

## One document number

The number in the [reading directory](README.md) is the only document ID.
`catalog.json` lists documents in that order; `id` is the two-digit number.
For example, the AML/CFT Guideline is **03** everywhere:

- Official files: `EN/03_High_…pdf` and `TC/03_高_…pdf`.
- Extracted text: `text/EN/03.txt` and `text/TC/03.txt`.
- Question quotes: `"doc": "03"` in `quotes.json`.
- Image transcripts, where needed: `transcripts/NN.json` with the same number.

Cap. 615 is **04**; the periodic-return circular and its transcript are **18**.
There is no separate stable source ID or old-name lookup.

## Editing or adding material

Use `catalog.json` for filenames, priority, official URLs, editions and hashes.
The original 23 bank sources are marked `original_bank_source`; the nine additions
are reading materials, not evidence that their contents are already covered by
questions. Verify edition, language, applicability and citation patterns in
`sources_test.go` before writing questions against an addition. Item 20 is a
statutory extract; item 22's TC file is an English-source pointer.

After replacing source content, regenerate text with `python docs/extract_text.py`
(requires PyMuPDF) and review affected quotes. Recheck image transcripts against
the new PDF. PDF hashes use raw bytes; Markdown hashes use LF line endings.
Generate the directory with `python docs/build_catalog.py`.

Companion publications live under `related/NN/`, using their parent document's
number. `companions` in the catalog records each publication's language, edition,
URL, raw-file hash and extracted-text hash; `related_documents` links originals
already in the main directory and `online_references` distinguishes live webpages.
Run `python docs/extract_related.py` after changing companion files. These files
are reading supplements, not additional numbered bank sources: do not cite a
companion passage under its parent circular's `doc` value without explicitly
extending the bank's citation checks. Preserve later documentation review evidence
in `bank/audit/maintenance/`; earlier hash records and snapshots stay unchanged.

If reading order changes, renumber filenames, catalog IDs, extracted text,
manifest keys, quotes, transcripts, citation patterns, reports and authoring
examples together. Preserve question IDs, question wording and saved-answer
compatibility. Archive prior audit evidence and record a verified mechanical
migration; a hash change alone is not evidence of a correct migration.

## Checks

```bash
python docs/build_catalog.py --check
go test ./...
python bank/audit/report.py --check
python bank/audit/terms_report.py --check
python bank/audit/p1_report.py --check
python bank/audit/remaining_report.py --check
go run . -export-html dist/mso-ca.html
python revision/pack_build.py dist/mso-revision-pack.html
```

The mock exam stores progress by question ID, not document number. This cleanup
does not change question IDs or stored answers. Historical evidence before the
numbering cleanup is retained in [the audit archive](../bank/audit/history/README.md);
it is not a numbering system to maintain or use for new questions.
