# 來源文件維護說明

[English version →](SOURCE-MAINTENANCE.md)

## 只用一套文件編號

[閱讀目錄](README.zh-Hant.md)的順序就是唯一文件編號。
`catalog.json`按此順序排列，`id`使用兩位數字。例如反洗錢指引在所有地方都是**03**：

- 原件：`EN/03_High_…pdf`及`TC/03_高_…pdf`。
- 擷取文字：`text/EN/03.txt`及`text/TC/03.txt`。
- 題庫引文：`quotes.json`中的`"doc": "03"`。
- 圖片轉錄（如有）：`transcripts/NN.json`也用同一編號。

第615章是**04**；定期申報表通函及其圖片轉錄是**18**。
不再另設固定來源ID，也不再維護舊檔名查找對照。

## 修改或新增資料

檔名、優先級、官方網址、版本及檔案摘要統一記在`catalog.json`。
`original_bank_source`標示既有題庫所用的23份來源；新增9項只是閱讀材料，
不代表已補入題庫。使用新增材料出題前，須核對版本、語言、適用範圍，並在
`sources_test.go`確認引用識別規則。第20項是法例摘錄；第22項的中文檔是英文原文入口。

更換原件內容後，執行`python docs/extract_text.py`（需要PyMuPDF），覆核受影響引文。
有圖片人工轉錄時，須對新PDF重新核對。PDF摘要按原始位元組計算；Markdown先統一為LF換行。
執行`python docs/build_catalog.py`更新雙語閱讀目錄。

通函配套原件放在`related/NN/`，沿用主文件編號。目錄中的`companions`記錄
語言、版本、官方網址、原件及擷取文字摘要；`related_documents`連到庫內已有原件，
`online_references`則明確標示僅在線入口。更改配套原件後執行
`python docs/extract_related.py`。配套資料目前只供閱讀，尚未加入題庫引用核驗；
不能把配套原文當作通函正文，用主文件編號直接出題。後續文件說明的變動證據
追加在`bank/audit/maintenance/`，保留原來的審校摘要及快照。

若調整閱讀順序，須一次同步修改檔名、目錄編號、擷取文字、清單、引文、轉錄、
引用識別規則、報告及教學例子。題號及題目內容保留，避免影響舊作答紀錄。
保留原審校證據並記錄已核驗的機械遷移；不能只改摘要值消除檢查錯誤。

## 檢查

```bash
python docs/build_catalog.py --check
go test ./...
python bank/audit/report.py --check
python bank/audit/terms_report.py --check
python bank/audit/p1_report.py --check
python bank/audit/remaining_report.py --check
go run . -export-html dist/mso-ca.html
python revision/pack_build.py dist/mso-revision-pack.html
```

模擬試按題號保存進度，不按文件編號保存。此次清理沒有改題號或作答內容。
統一編號前的原始審校證據保存在[歷史存檔](../bank/audit/history/README.md)，
只供追溯，不作為往後出題或維護的另一套編號。
