# 貿易洗錢風險指標：英文原文閱讀入口

FATF與Egmont共同發布，2021年3月。只收錄已核實的官方英文原文，未製作或冒充官方中文譯本。

[閱讀已歸檔的英文PDF](../EN/22_Medium_Trade-Based Money Laundering Risk Indicators - FATF and Egmont (Mar 2021).pdf)

[共同發布方官方來源](https://egmontgroup.org/wp-content/uploads/2021/10/Trade-Based-Money-Laundering-Risk-Indicators.pdf)

建議：先讀使用說明，再按企業結構、貿易活動、貿易單據及貨物、賬戶及交易活動四組指標閱讀。
