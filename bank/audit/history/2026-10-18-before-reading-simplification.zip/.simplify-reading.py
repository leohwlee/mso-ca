import pathlib,json,hashlib,shutil,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
DOCS=ROOT/'docs'
TMP=ROOT/'tmp/reading-simplification';TMP.mkdir(parents=True,exist_ok=True)
backup=ROOT/'bank/audit/history/2026-10-18-before-reading-simplification.zip'
assert not backup.exists(),'Migration already started; inspect saved state before retrying.'
paths=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.md','.py','.go','.json','.toml','.yml','.txt'} and not any(x in p.relative_to(ROOT).parts for x in ['.git','tmp','dist','__pycache__']) and 'history' not in p.relative_to(ROOT).parts]
with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,p.relative_to(ROOT).as_posix())
baseline={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(TMP/'baseline.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2),encoding='utf8')
cat=json.loads((DOCS/'catalog.json').read_text(encoding='utf8'))
manifest=json.loads((DOCS/'text/manifest.json').read_text(encoding='utf8'))
moves=[]
def move(src,dest):
 src=src.resolve();dest=dest.resolve()
 assert src.is_relative_to(DOCS.resolve()) and dest.is_relative_to(DOCS.resolve()),(src,dest)
 assert src.is_file() and not dest.exists(),(src,dest)
 sha=hashlib.sha256(src.read_bytes()).hexdigest()
 dest.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(src),str(dest))
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==sha
 moves.append({'before':src.relative_to(ROOT).as_posix(),'after':dest.relative_to(ROOT).as_posix(),'sha256':sha})
archive_reasons={
 '20':('完整第34章已包含附表2及3；移出重複網頁摘錄，改讀第19項配套全文。','Schedules 2 and 3 are already in the full Cap. 34 under item 19; the duplicate webpage extract is removed from daily reading.', ['19']),
 '24':('主要為2022年報告發布及閱讀提示；風險評估責任由第03項第2章涵蓋，行業資訊直接讀第25項第5.4節。','Primarily announces the 2022 report. Use chapter 2 of item 03 for risk-assessment duties and section 5.4 of item 25 for sector findings.', ['03','25']),
 '27':('舉報規則與第03項第7章重疊；培訓例子仍可查閱，暫不列為另一份必讀教材。','STR rules overlap with chapter 7 of item 03. Training examples remain available for reference, rather than forming another required reading.', ['03']),
 '28':('風險評估的輔助講義；先讀第03項第2章、第09項及第25項，毋須再完整重讀講義。','Supporting risk-assessment slides. Prioritise chapter 2 of item 03, item 09 and item 25; a second full pass through the slides is unnecessary.', ['03','09','25']),
 '29':('較早機構風險評估通函，核心步驟已見第03項第2.2至2.6段；保留第09項擴散融資的額外要求。','Earlier institutional-risk circular; core steps are covered by paragraphs 2.2-2.6 of item 03. Item 09 retains the additional PF expectations.', ['03','09']),
 '30':('獨立防詐提醒，但相對七個考試單元的核心要求優先級較低；移出不代表正式失效或不會考。','A distinct fraud-prevention reminder, with lower study priority than the core syllabus. Archiving does not mean withdrawal or exclusion from the exam.', []),
 '31':('旅客電子預填流程，與MSO日常合規考點關聯較弱；基本跨境申報及披露要求保留於第17項及配套法例。','Passenger e-form workflow has lower relevance to MSO controls. Basic declaration/disclosure requirements remain in item 17 and the full companion law.', ['17']),
 '32':('支付透明度指引的歷史諮詢通知，非香港已生效要求；本輪不列作主要復習材料。','Historical consultation notice on payment transparency, rather than effective Hong Kong requirements; not a main study item in this pass.', [])}
focus={'10','11','14','15','16','18','19','21','23'}
for d in cat['documents']:
 num=d['id'];active=num not in archive_reasons
 d['reading_status']='active' if active else 'archive'
 d['study_focus']='core' if d['priority']=='high' else ('focus' if num in focus else 'select') if active else 'archive'
 if not active:
  tc,en,targets=archive_reasons[num];d['archive_reason']={'TC':tc,'EN':en};d['read_instead']=targets
 for lang,e in d['editions'].items():
  src=DOCS/lang/e['file']
  old_name=e['file'];new_name=old_name
  if active and d['priority']=='medium':
   label=('中重點' if d['study_focus']=='focus' else '中選讀') if lang=='TC' else ('Medium-Essential' if d['study_focus']=='focus' else 'Medium-Selected')
   new_name=old_name.split('_',2)[0]+'_'+label+'_'+old_name.split('_',2)[2]
  dest=DOCS/(lang if active else f'archive/{lang}')/new_name
  if src!=dest:move(src,dest)
  e['file']=new_name;e['path']=dest.relative_to(DOCS).as_posix()
  manifest[f'{lang}/{num}.txt']['source']=new_name
 # Companion publications retain the parent number, not separate bank IDs.
 for c in d.get('companions',[]):
  keep=num in {'17','19'}
  c['reading_status']='active' if keep else 'archive'
  c['study_focus']=d['study_focus'] if keep else 'archive'
  if not keep:
   if num=='08':reason=('新聞背景，沒有新增MSO合規要求。','News background, without additional MSO compliance duties.')
   elif num=='09':reason=('國際方法及培訓延伸；本輪先掌握第03及09項的本地要求，需要深入例子時再查。','International methodology and training extension. First learn the local requirements in items 03 and 09; consult this for deeper examples.')
   elif num=='23':reason=('國際標準全文或前期通函；本輪讀現行海關通函及所連結的聲明，避免重讀整本國際標準或舊通知。','Full international standards or a preceding circular. Prioritise the current Customs circular and its linked statements rather than rereading an entire international standard or old notice.')
   elif num=='26':reason=('歷史決議原文供追溯；本輪讀第03項第6章及第26項的本地執行要求，制裁對象須查最新名單。','Historical resolutions for traceability. Use chapter 6 of item 03 and item 26 for local implementation duties; check current sanctions lists for designated parties.')
   else:reason=(archive_reasons[num][0],archive_reasons[num][1])
   c['archive_reason']={'TC':reason[0],'EN':reason[1]}
  for language,e in c['editions'].items():
   src=DOCS/e['file'];text=DOCS/e['text_file']
   if keep:
    cap='629' if num=='17' else '34'
    date=e['edition'];label_tc='中選讀' if num=='17' else '中重點';label_en='Medium-Selected' if num=='17' else 'Medium-Essential'
    tc_name=f'{num}_{label_tc}_配套_第{cap}章完整條例（{date}_中英雙語）.pdf'
    en_name=f'{num}_{label_en}_Supplement - Full Cap {cap} ({date}, Bilingual).pdf'
    tc=DOCS/'TC'/tc_name;en=DOCS/'EN'/en_name
    move(src,tc);shutil.copyfile(tc,en)
    assert hashlib.sha256(en.read_bytes()).hexdigest()==e['sha256']
    e['file']=tc.relative_to(DOCS).as_posix();e['copies']={'TC':e['file'],'EN':en.relative_to(DOCS).as_posix()}
    text_dest=DOCS/'text/companions'/f'{num}_Cap_{cap}.txt'
   else:
    dest=DOCS/'archive'/e['file'];move(src,dest)
    e['file']=dest.relative_to(DOCS).as_posix()
    text_dest=DOCS/'archive'/e['text_file']
   move(text,text_dest);e['text_file']=text_dest.relative_to(DOCS).as_posix()
 # Displaying the English original is more useful than a Chinese pointer-only file.
 if num=='22':
  tc=d['editions']['TC'];en=d['editions']['EN'];old=DOCS/tc['path']
  move(old,DOCS/'archive/superseded'/old.name)
  target=DOCS/'TC'/'22_中選讀_貿易洗錢風險指標（2021年3月_英文原文）.pdf'
  shutil.copyfile(DOCS/en['path'],target)
  d['editions']['TC']={**en,'file':target.name,'path':target.relative_to(DOCS).as_posix(),'language':'EN','note':'English original, not a Chinese translation.'}
  (DOCS/'text/TC/22.txt').write_bytes((DOCS/'text/EN/22.txt').read_bytes())
  manifest['TC/22.txt']={**manifest['EN/22.txt'],'source':target.name}
cat['schema_version']=4
cat['ordering']='One document number; main reading sequence retained, companions follow their parent. Archived items leave gaps, without a separate source-ID scheme.'
cat['selection_basis']={'reviewed_on':'2026-10-18','official_syllabus':'https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_zh_TW.pdf','sections':['5.2','5.3','6.1'],'note':'Study prioritisation, not official examination weights or a finding that archived material cannot be examined.'}
(DOCS/'catalog.json').write_text(json.dumps(cat,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
(DOCS/'text/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=1)+'\n',encoding='utf8',newline='\n')
move(DOCS/'related/link-review.json',DOCS/'archive/link-review.json')
for p in sorted((DOCS/'related').rglob('*'),reverse=True):
 if p.is_dir():p.rmdir()
(DOCS/'related').rmdir()
(TMP/'moves.json').write_text(json.dumps(moves,ensure_ascii=False,indent=2),encoding='utf8')
print('Consolidated 26 active publications into each language folder; originals and prior evidence retained.')
