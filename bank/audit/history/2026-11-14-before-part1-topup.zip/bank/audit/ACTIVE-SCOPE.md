# Active 01–24 and 26 question-bank scope

Owner decision: 18 October 2026. Approximately 525 bilingual combination questions; seven parts; mock exam and custom practice only. This personal practice scope is not the official exam syllabus.

Owner request: 2026-10-23. Add about 25–30 questions for the gaps found in the 23 October bank review and correct the statements it flagged; then add about five more questions whose answer is None of the above.
Owner request: 2026-10-23. Second batch of the 23 October review: add 30–40 questions whose false statements turn on a number, period, name or actor (blind-reviewed), replace the statement that mirrored another item, and give the two items that shared a stem their own stems.
Owner request: 2026-11-14. Remove the 2022 Hong Kong Money Laundering and Terrorist Financing Risk Assessment Report from personal MSO Competence Assessment practice materials entirely, including as a reference document and as a source of practice questions. The report did not come up on the exam the owner sat, and he does not want a large study session or questions set from it. This is a personal practice-scope decision, not a claim that the official exam can never use the report.

Active questions: **565**. Statements: **2667**.

| Part | Questions | Mock draw |
|---|---|---|
| 1 | 53 | 5 |
| 2 | 81 | 5 |
| 3 | 71 | 5 |
| 4 | 89 | 5 |
| 5 | 80 | 5 |
| 6 | 123 | 5 |
| 7 | 68 | 5 |

## Review and provenance

The 357-question baseline is preserved byte-for-byte in `history/2026-10-18-before-active26.zip`. Three archived-circular items (m1-140, m1-141, m1-181) are retired, with their IDs reserved. All other baseline questions and their quotes were unchanged by that expansion; later reviewed revisions are listed below.

The four original audit reports describe the original 23-source checklist. They validate a reconstructed historical bank; they do not claim to cover this expansion. The new record validates retained content, retirements, final blind answers, source hashes and topic mappings separately.

New questions: **171**. Final bilingual blind review records: **171**.

Reviewers answered without keys or explanations. Agents inherited the parent model; this is independent context review, not a claimed different-model-family panel. Every recorded verdict is bound to the final stem, statements and citation by a text hash.

## Later reviewed changes

Each later change has its own record in `active-followups/` and an archive of the bank it started from. The check unwinds them newest first and then validates the record above unchanged. Revised items keep their IDs; their earlier text and quotes stay in the archive.

| Date | Added | Revised | Retired | Blind review records | Archive |
|---|---|---|---|---|---|
| 2026-10-23 | 27 | 12 | 0 | 39 | `history/2026-10-23-before-gap-items.zip` |
| 2026-10-23 | 36 | 2 | 0 | 38 | `history/2026-10-23-before-number-traps.zip` |
| 2026-11-14 | 0 | 0 | 23 | 0 | `history/2026-11-14-before-retire-report25.zip` |

2026-10-23: 27 questions added and 12 revised. Every added or revised item was answered blind, statement by statement in both languages, from the cited sources by Claude subagents (claude-opus-5-5, the same model as the author) working in fresh contexts without keys, explanations or quotes; this is independent-context review, not a different-model panel. No verdict differed from the key in any round. After round 1 (34 items) the wording reviewers questioned and the differences between languages were corrected, and 22 items were reviewed again by two new subagents, with doubts limited to cases where a careful candidate could reasonably reach the opposite verdict; round 3 reviewed the five items with no true statement added on the owner's second request. One round-2 doubt (m6-480, how the Chinese writes the more-than-25% threshold) is kept with the author's resolution. Each recorded verdict is bound to the final stem, statements and citation by a text hash.

2026-10-23: 36 questions added and 2 revised. Every statement of every item was answered blind, in both languages, from the cited sources by Claude subagents (claude-fable-5-1, the same model as the author) working in fresh contexts without keys, explanations or quotes; this is independent-context review, not a different-model panel. The batch targets the traps the 23 October review found under-tested: a number, period, name or actor changed in an otherwise faithful statement (14 years / $5 million, 10 working days, 45 days, 7 days, $1,000,000 versus $10,000,000, 21 days, THREE nominees, 102x152 mm, two years, 3 business days, 3-year training records, and the names of the six main laws, the two penalty guidelines, the Immigration Ordinance and the Hong Kong Association of Banks). Each recorded verdict is bound to the final stem, statements and citation by a text hash; doubts carry the author's resolution.

2026-11-14: 23 questions that cited only document 25 were retired and their IDs reserved in bank/retired-ids.json. Document 25 was moved from daily reading to the catalog archive; number 25 stays reserved and document 26 is not renumbered. Extracted texts at docs/text/EN/25.txt and docs/text/TC/25.txt are unchanged so historical source-text bindings still verify. No questions were added or revised, so no new blind answers or coverage mappings were required. Live study-note blocks that depended only on the 2022 report were dropped; a point that also appears in an allowed source was re-cited to that source.

## Coverage boundaries

- Only local publications 01–24 and 26 support answers, including exceptions and distractors. Numbering does not import documents linked by a circular.
- Coverage maps distinguish a new rule from a new application. Decision-changing scenarios may reuse a rule; decorative variants and repeated statements are excluded.
- Document 24 has no official Chinese edition. Its Chinese questions and explanations are study translations, visibly labelled; deciding quotes remain English.
- Document 25, the 2022 risk assessment report, was in the 18 October 2026 01–26 selection and was removed from the active practice scope on 14 November 2026. It cannot support live questions. Its findings remain historical evidence.
- Source quote checks verify occurrence, not legal meaning. Blind answers and explanation review provide the semantic checks; no claim of perfect accuracy or complete official exam coverage is made.

[Source-by-source accounting](../../docs/QUESTION-SOURCES.md) · [Machine-readable evidence](active26-implementation.json) · [2026-10-23 follow-up](active-followups/2026-10-23-gap-items.json) · [2026-10-23 follow-up](active-followups/2026-10-23-number-traps.json) · [2026-11-14 follow-up](active-followups/2026-11-14-retire-report25.json)
