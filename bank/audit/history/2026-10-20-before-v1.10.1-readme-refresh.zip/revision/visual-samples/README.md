# Visual study pilots / 可視化研讀樣例

Open `index.html` directly in a browser. No server, internet connection or build is
needed for reading. Choose 繁體中文, English or 雙語 / Both in the masthead.

直接以瀏覽器開啟 `index.html`，毋須伺服器、網絡或建置。頁首可選繁體中文、
英文或雙語。

## Three samples / 三個樣例

- ML stages: AntV-generated sequence, full definitions and a visible reading
  qualification. / 洗錢階段：AntV順序圖、完整定義及可見的讀圖提示。
- SOW / SOF: neutral scope diagram and aligned comparison, followed by PEP and
  other high-risk conditions. / 財富及資金來源：中立範圍圖、逐項對照，以及政治人物
  和其他高風險情況的條件。
- CDD amounts and renewal clocks: inclusive thresholds, independent CDD triggers,
  linked operations, starting events, retake distinctions and the existing B23
  source-conflict decision. / CDD金額及續牌時鐘：包括相等值的門檻、獨立觸發條件、
  相連交易、起算事件、重考區別及既有B23原文差異處理。

Each citation displays its actual repository filename and paragraph/section.
These are pilots of selected topics, not an audit of the complete seven-part
syllabus. Existing study manuscripts and questions are not generated from these
samples or modified by this builder.

每個引用均顯示實際repo檔名及段落／條文。這是指定主題的樣例，並非七個Part的
完整考綱審核；建置不會修改原有筆記或題庫。

## Rebuild / 重建

`python revision/visual-samples/build.py` rebuilds the browser-ready `index.html`
from source-bound bilingual copy, the catalog, and the two stored AntV SVGs.
`samples.css` uses the established B palette and the existing bundled DM Sans font.

上述指令按雙語內容、目錄及兩個已儲存的AntV SVG重建頁面；樣式沿用B配色及現有
本地DM Sans字體。

To regenerate diagrams or check the browser matrix, Node.js, Playwright and local
Chrome are needed. With Playwright available in Node's module lookup path:

重新產生圖示或檢查各瀏覽模式須有Node.js、Playwright及本地Chrome：

```text
node revision/visual-samples/render-graphs.cjs
python revision/visual-samples/build.py
node revision/visual-samples/verify.cjs
```

`verification.json` records the tested language/viewport cases, offline request
check, citation-file existence and keyboard switching. Captures are in `review/`.
These mechanical checks are not an independent legal/source audit.

`verification.json`記錄語言／視窗、離線請求、引用檔案及鍵盤切換檢查，截圖在
`review/`。這些機械檢查不等於獨立法律／原文審核。

## Design tools and provenance / 設計工具及來源

- [Visual Explainer](https://github.com/nicobailon/visual-explainer): visual-first
  explanation and representation selection. `index.src.html` retains its kit marker
  for optional authoring lint/render. The shipped `index.html` deliberately uses
  project styles instead: the generic kit adds online Google Fonts and conflicts
  with the established B masthead and type. No kit code is copied into the shipped
  page. / 用於圖示優先及表達方式選擇；正式樣例使用項目樣式，避免通用kit的在線
  字體及全局樣式影響B風格。`index.src.html`是可選的kit檢查輸入，不是閱讀入口。
- [AntV Infographic](https://github.com/antvis/Infographic): pinned to the version
  in `vendor/version.json`, MIT licence in `vendor/ANTV-LICENSE`. Only needed for
  regenerating SVGs; the reading page loads no rendering library. / 固定版本及
  MIT授權存於`vendor/`；只在重建SVG時使用，閱讀時不載入渲染庫。
- Comparison templates with built-in PROS/CONS/VS semantics were rejected because
  SOW and SOF are complementary scopes, not competing choices. / 不使用內置
  優缺點或競爭語意的比較模板，避免誤導。

The global design system is preserved; pilot-specific observations belong in
`DESIGN-NOTES.md`. / 保留全局設計系統；樣例設計記錄見`DESIGN-NOTES.md`。
