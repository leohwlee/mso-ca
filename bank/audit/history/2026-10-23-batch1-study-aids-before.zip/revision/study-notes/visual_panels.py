"""Source-bound visual adaptations approved by the owner on 2026-10-19.

The bank is not an input. Examples are explicitly pedagogical illustrations.
The original manuscripts remain fully visible, including exceptions.
"""
from copy import deepcopy

def p(tc,en):return dict(tc=tc,en=en)
def route(label,nodes,edges,note):return dict(label=label,nodes=nodes,edges=edges,note=note)
def relation(a,verb,b,note):return dict(from_=a,verb=verb,to=b,note=note)
def rel(a,verb,b,note):return {'from':a,'verb':verb,'to':b,'note':note}
def clock(label,start,duration,note):return dict(label=label,start=start,duration=duration,note=note)

def apply(original, parts):
    panels=deepcopy(original)
    def refs(n,s,indices=None):
        blocks=next(v for v in parts[n]['sections'] if v['id']==s)['blocks']
        selected=blocks if indices is None else [blocks[i] for i in indices]
        return [deepcopy(r) for b in selected for r in b['refs']]
    def old(key):
        return next(v for ss in panels.values() for ps in ss.values() for v in ps if v['id']==key)
    def add(n,s,key,kind,title,**kw):
        v=dict(id=key,kind=kind,title=title,refs=kw.pop('refs',refs(n,s)),**kw)
        panels[n].setdefault(s,[]).append(v)
        return v
    def replace(key,kind,**kw):
        v=old(key);v['kind']=kind;v.update(kw);return v

    # Part 1: mechanism, purpose and scope; no mandatory three-stage sequence.
    stages=old('three-stages')
    stages['examples']=[
        route(p('同一犯罪得益：進入體系','Same criminal proceeds: entry'),[p('犯罪現金','Criminal cash'),p('存入戶口','Deposit into an account')],[p('存放','Placement')],p('教學例子：改變現金所在位置。','Teaching example: changes where the cash is held.')),
        route(p('同一犯罪得益：掩藏線索','Same proceeds: obscuring the trail'),[p('原來戶口','Original account'),p('多層戶口／交易','Layers of accounts / transactions')],[p('轉移、拆分','Move, split')],p('教學例子：增加追查來源的難度。','Teaching example: makes the origin harder to trace.')),
        route(p('同一犯罪得益：貌似合法','Same proceeds: apparent legitimacy'),[p('犯罪得益','Criminal proceeds'),p('貌似合法的投資／業務收益','Apparently lawful investment / business proceeds')],[p('重新呈現','Reappear as')],p('教學例子：外觀合法不會消除犯罪來源。','Teaching example: a lawful appearance does not erase criminal origin.'))]
    v=old('ml-tf-pf')
    v['headers']=[p('概念','Concept'),p('資金來源','Origin'),p('核心問題','Core concern'),p('法律條件','Legal conditions')]
    origins=[p('犯罪得益','Criminal proceeds'),p('合法或非法','Lawful or unlawful'),p('不可只憑來源判斷','Origin alone is not decisive')]
    v['rows']=[[row[0],origins[i],row[1],row[2]] for i,row in enumerate(v['rows'])]
    add(1,'cross-boundary-cash','cash-scope','paths',p('同一門檻，不同申報途徑','One threshold, different declaration routes'),paths=[
        route(p('旅客攜帶','Carried by travellers'),[p('現金類物品總值 > HK$120,000','CBNI total > HK$120,000'),p('指定管制站入境：書面申報','Entering at a specified control point: written declaration')],[p('觸發','Triggers')],p('其他入境途徑／離境：按獲授權人員要求披露；披露持有大量物品時再按要求申報。未過入境檢查的指定機場過境情況另有豁免。','Other entry routes / departure: disclose on an authorized officer’s request; then declare as required if large quantities are disclosed. The specified airport-transit case without immigration clearance is exempt.')),
        route(p('貨物進出口','Cargo import / export'),[p('同一法定批次總值 > HK$120,000','Same statutory batch total > HK$120,000'),p('進／出口前向海關申報','Declare to Customs before import / export')],[p('觸發','Triggers')],p('法定批次可合併多批貨物：按第10條的同一承運人／運輸工具及客戶規則計算。非旅客進出口或安排進出口者須確保事前申報；第8–9條的過境、空運轉運、郵包及運輸工具經營者例外見正文。','A statutory batch can aggregate multiple consignments under section 10’s carrier / conveyance and customer rules. Non-traveller importers / exporters and persons causing import / export must ensure prior declaration. See the text for ss.8–9 transit, air-transhipment, postal and conveyance-operator exceptions.'))],
        note=p('恰好HK$120,000不因這個「>」門檻觸發；CDD的一般非經常交易門檻是「≥」，不是同一制度。','Exactly HK$120,000 does not cross this “>” threshold. General occasional-transaction CDD uses “≥”: a different regime.'))
    add(1,'risk-assessment','cross-sector-mechanisms','paths',p('2022年報告：跨行業的價值轉移例子','2022 report: cross-sector value-transfer examples'),refs=refs(1,'risk-assessment',[4,5,6]),paths=[
        route(p('公司與戶口','Companies and accounts'),[p('濫用公司架構／代名人','Misuse of corporate structures / nominees'),p('實際控制者／資金來源','Actual controllers / fund origins')],[p('掩藏','Conceals')],p('經公司戶口交易及匯款時，了解實益擁有人及商業目的，不能僅看公司已註冊。','For company-account activity and remittances, understand beneficial ownership and business purpose; registration alone is insufficient.')),
        route(p('保險與物業','Insurance and property'),[p('犯罪得益投入資產','Proceeds placed into assets'),p('退保／轉售所得','Surrender / resale receipts')],[p('改變外觀','Change appearance')],p('是濫用機制例子，不表示每次退保或物業轉售均屬可疑；風險結論屬2022年報告。','Examples of misuse, not a claim that every surrender or resale is suspicious; risk findings belong to the 2022 report.'))])

    # Part 2: separate legal regimes and actual decision branches.
    v=old('licence-clocks');v['kind']='clocks';v['clocks']=[clock(*row) for row in v['rows']] if len(v['headers'])==4 else []
    if not v['clocks']:v['kind']='table'
    v=old('penalty-ceilings')
    replace('penalty-ceilings','formula',formulae=[
        dict(label=p('第21條：違反指明條文','Section 21: specified-provision contraventions'),expression=p('上限 = 較大者 { HK$10,000,000；所得利益／避免成本 × 3 }','Maximum = greater of { HK$10,000,000; benefit gained / cost avoided × 3 }'),note=p('最高額不是必罰額；須按適用程序及罰款指引評估。','A ceiling is not an automatic fine; apply the relevant procedure and penalty guidelines.')),
        dict(label=p('第43條：MSO牌照紀律處分','Section 43: MSO licensing discipline'),expression=p('上限 = HK$1,000,000','Maximum = HK$1,000,000'),note=p('兩項制度不能互換；持續違反補救要求的每日罰款另按法定條件處理，詳見下文。','The two regimes are not interchangeable. Daily penalties for continued failure to comply with remedial requirements have separate statutory conditions below.'))])
    inspection=next(s for s in parts[2]['sections'] if s['id']=='inspection-investigation')
    add(2,'inspection-investigation','inspection-versus-investigation','table',p('日常查察與正式調查','Inspection versus investigation'),headers=[p('維度','Dimension'),p('查察：第9條','Inspection: s.9'),p('調查：第11–12條','Investigation: ss.11–12')],rows=[
        [p('用途／基礎','Purpose / basis'),p('確定正在／曾經遵守及是否可能遵守「訂明規定」：不只指明條文，亦涵蓋適用通知、要求及牌照等條件','Ascertain current / past compliance and likelihood of compliance with prescribed requirements: not just specified provisions, but applicable notices, requirements and licence conditions'),p('第11(1)(a)：有合理因由相信可能犯罪；或(b)：為考慮第21／43條處分，有理由查究指明違反','s.11(1)(a): reasonable cause to believe an offence may have occurred; OR (b): reason to enquire into specified contraventions for considering s.21 / s.43 action')],
        [p('主要權力','Main powers'),p('進入營業處所、查閱及複製紀錄、要求解釋','Enter business premises, inspect / copy records, require explanations'),p('要求紀錄、答覆問題、書面解釋及協助','Require records, answers, written explanations and assistance')],
        [p('共同界線','Shared limits'),p('依法行使；法律專業保密權等保障保留','Exercise lawfully; safeguards including legal professional privilege remain'),p('受查者仍須遵從合法要求；刑事程序使用受強制陳述另有條件','Comply with lawful requirements; use of compelled statements in criminal proceedings has separate conditions')]],refs=refs(2,'inspection-investigation',[1]))
    add(2,'review','review-commencement','decision',p('指明決定：何時生效','Specified decisions: when they take effect'),refs=refs(2,'review',[1]),intro=p('除條例另有規定外，依第75條判斷。申請覆核與申請暫緩是兩件事。','Subject to other provisions, apply section 75. Review and a stay application are distinct.'),nodes=[
        dict(test=p('通知有基於公眾利益指定其他生效時間？','Does the notice specify another commencement time in the public interest?'),yes=p('依通知指定時間；另可按適用條文申請暫緩。','Use the specified time; a stay may separately be sought under the applicable provision.')),
        dict(test=p('通知送出後21日內，書面通知不申請覆核？','Within 21 days after notice is sent, written notice that no review will be sought?'),yes=p('在該書面通知作出時生效。','Effective when that written notice is given.')),
        dict(test=p('在該21日內申請覆核？','Review applied for within those 21 days?'),yes=p('確認：確認時；更改／取代：當時並按其條款；撤回：撤回時。','Confirmed: on confirmation. Varied / substituted: then, subject to its terms. Withdrawn: on withdrawal.'),no_label=p('否','NO'),no=p('沒有上述通知或申請：21日期間屆滿時生效。','Neither notice nor application: effective when the 21-day period expires.'))],note=p('21日起算事件是通知「送出」。覆核申請本身不構成暫緩；上訴也不自動暫緩。延長申請期及暫緩權詳見本節正文。','The 21-day clock starts when notice is sent. Review does not itself constitute a stay; appeal is not an automatic stay either. Extensions and stay powers are explained below.'))

    # Part 3: local AND logic, boundaries and components (no global legal flowchart).
    v=old('money-boundaries');v['note']=p('先辨認制度，再比較數字：≥包含相等；>不包含相等。不同交易類型與合併規則不能互借。','Identify the regime before comparing amounts: ≥ includes equality; > excludes it. Transaction types and aggregation rules are not interchangeable.')
    add(3,'special-cases','shell-bank-and','logic',p('附表2第17條：空殼銀行的四項條件','Schedule 2 s.17: four shell-bank conditions'),refs=refs(3,'special-cases',[1]),operator=p('全部成立 · AND','ALL · AND'),items=[p('法團在香港以外某司法管轄區註冊成立','Corporation incorporated in a jurisdiction outside Hong Kong'),p('獲准在該處從事銀行業務','Authorized to conduct banking there'),p('在該處沒有實體經營','No physical presence there'),p('不隸屬另一家在某司法管轄區成立、獲准在該處經營銀行業務 AND 在該處有實體經營的法團','Unaffiliated with another corporation incorporated in a jurisdiction, authorized to conduct banking there AND physically present there')],note=p('實體經營＝在當地處所經營銀行業務 AND 至少一名全職僱員在該處履行銀行相關職務。第17條的直接禁止對象是認可機構的往來銀行關係，不是把MSO當作往來銀行。隸屬的定義見正文。','Physical presence = banking at premises there AND at least one full-time employee performing banking-related duties there. Section 17 directly prohibits authorized institutions’ relevant correspondent relationships; it does not treat MSOs as correspondent banks. See the text for affiliation.'))
    old('fee-components')['note']=p('應付額＝適用申請基本費用＋額外營業處所費用＋適用的逐人適當人選測試費用。不是每名申請人都付齊表內所有項目；金額依repo所存2026年綜合版本。','Payable fee = relevant application base fee + additional-premises charges + applicable per-person fit-and-proper test charges. Not every applicant pays every component; amounts follow the repo’s 2026 consolidated edition.')
    old('ownership-boundary')['note']=p('公司角色及「25.1%／恰好25%」例子見Part 6「身分資料」圖；控制權是獨立條件，不能只檢查百分比。','See Part 6’s Identity information diagram for corporate roles and the 25.1% / exactly 25% example. Control is a separate limb; do not check percentages alone.')
    old('ownership-boundary')['links']=[dict(href='part-6.html#memory-party-roles',label=p('公司角色與百分比例子','Corporate roles and percentage example'))]

    # Part 4: no timeline shared by unrelated invitation/receipt/issue events.
    v=old('assessment-clocks');v['groups']=[dict(title=p('申請及人事變更','Applications and personnel changes'),rows=v['rows'][:4]),dict(title=p('應考結果及重考','Results and retakes'),rows=[v['rows'][5],v['rows'][4]]),dict(title=p('覆核成績','Rechecking results'),rows=v['rows'][6:])]
    v=old('exchange-rights');replace('exchange-rights','paths',paths=[
        route(p('交易未完成','Transaction not completed'),[p('客戶拒絕繼續','Customer declines to proceed'),p('即時退回所交全數款項','Immediately return the full amount tendered')],[p('須','Must')],v['rows'][0][-1]),
        route(p('交易已完成','Transaction completed'),[p('有第4條違反','Section 4 breach'),p('交易後3日內法定撤銷權','Statutory rescission within 3 days after the transaction')],[p('才觸發這項權利','Triggers this right')],v['rows'][1][-1])])

    # Part 5: responsibilities and risk levels, not a linear compliance checklist.
    replace('risk-levels','relationships',relations=[
        rel(p('機構層面風險評估','Institutional risk assessment'),p('決定配置','Shapes allocation'),p('制度、控制及資源','Systems, controls and resources'),p('涵蓋客戶、地域、產品／服務／交易及渠道等風險；小規模可簡化方法，不能省略。','Covers customer, geographical, product / service / transaction and channel risks; small scale allows simpler methods, not omission.')),
        rel(p('客戶層面風險評估','Customer risk assessment'),p('決定強度','Shapes intensity'),p('該客戶的CDD及持續監察','That customer’s CDD and ongoing monitoring'),p('以初步風險決定審查程度，再結合CDD資料整體評估及更新；不是只憑國籍或機械分數。','Use initial risk to set CDD extent, then assess holistically with CDD data and update; nationality or a mechanical score alone is insufficient.'))],note=p('兩層互相提供資訊：機構風險影響客戶評估方法；客戶及監察的新發現可促使機構評估更新。','The levels inform one another: institutional risk shapes customer assessment; customer and monitoring findings can trigger institutional updates.'))
    add(5,'roles','control-responsibilities','relationships',p('誰設計、誰判斷、誰獨立檢查','Who designs, decides and independently checks'),relations=[
        rel(p('高級管理層','Senior management'),p('委任、支援並承擔管理責任','Appoints, supports and manages risk'),p('CO與MLRO','CO and MLRO'),p('應在切實可行範圍內確保權限、資源、資訊及直接溝通渠道；完整八項條件見正文。','Should, as far as practicable, ensure authority, resources, information and direct communication; see the eight conditions below.')),
        rel(p('合規主任（CO）','Compliance officer (CO)'),p('建立及監察','Establishes and monitors'),p('AML/CFT制度、培訓及合規','AML/CFT systems, training and compliance'),p('應向高級管理層溝通主要AML/CFT事項，包括適當時的重大合規缺失；不限於缺失。','Should communicate key AML/CFT issues to senior management, including significant compliance deficiencies where appropriate; not deficiencies alone.')),
        rel(p('洗錢報告主任（MLRO）','Money laundering reporting officer (MLRO)'),p('評估內部報告，決定是否披露','Assesses internal reports and decides disclosure'),p('聯合財富情報組（JFIU）','Joint Financial Intelligence Unit (JFIU)'),p('保留評估理由及紀錄，防止通風報訊。','Keep assessment reasons and records; prevent tipping off.')),
        rel(p('獨立審計職能','Independent audit function'),p('獨立檢查及提出改善','Independently tests and recommends improvements'),p('制度、程序及控制','Systems, procedures and controls'),p('按規模及性質可內設或外聘，但須保持獨立；不是CO自行審核自己的工作。','May be internal or external depending on size and nature, but must remain independent; not CO self-review.'))],refs=refs(5,'roles')+refs(7,'independent-audit'),note=p('視業務規模及性質，CO與MLRO可由同一人兼任；圖中的職能不同，不代表必須是不同員工。','CO and MLRO may be combined depending on business size and nature; distinct functions do not necessarily mean separate employees.'))

    # Part 6: two-stage CDD decisions, explicit alternatives and relationship maps.
    add(6,'triggers','cdd-trigger-tree','decision',p('何時須做CDD','When CDD is required'),refs=refs(6,'triggers',[0])+refs(6,'monitoring',[0]),intro=p('CDD＝客戶盡職審查。由上至下判斷；任何適用觸發均須處理，不以「低於門檻」取代風險判斷。','CDD = customer due diligence. Read down the branches; address every applicable trigger. A below-threshold amount does not replace risk assessment.'),nodes=[
        dict(test=p('懷疑洗錢／恐怖分子資金籌集，或懷疑原有身分資料真實性／充分性？','ML/TF suspicion, or doubts about the truth / adequacy of existing identification information?'),yes=p('CDD觸發不論金額；另評估STR責任。若合理相信繼續CDD會通風報訊，可停止追查、記錄依據並提交STR。','CDD triggers regardless of amount; assess STR duties separately. If reasonably believing that continued CDD would tip off the customer, may stop pursuing it, document the basis and file an STR.')),
        dict(test=p('將建立業務關係？','Establishing a business relationship?'),yes=p('建立前做CDD，不論金額；只有符合全部條件才可延遲核實身分。','CDD before establishment, regardless of amount; defer identity verification only if all conditions are met.')),
        dict(test=p('已存在業務關係？','An existing business relationship?'),yes=p('持續CDD及交易監察；按觸發事件及風險更新。不是每次交易重新開戶，也不是低額便免查。','Ongoing CDD and transaction monitoring; update on triggers and risk. Neither repeat onboarding for every transaction nor exempt low-value activity.')),
        dict(test=p('非經常交易達門檻？電傳／虛擬資產轉帳 ≥ HK$8,000；其他 ≥ HK$120,000（或等值）。','Occasional transaction at threshold? Wire / VA transfer ≥ HK$8,000; others ≥ HK$120,000 (or equivalent).'),yes=p('執行前做CDD。單筆及看來相連的交易須合計。','CDD before execution. Count a single operation and operations that appear linked.'),no_label=p('否','NO'),no=p('僅表示未觸發這項金額條件。其他義務仍可能適用。','Only this amount-based trigger is absent. Other duties may still apply.'))],note=p('非電傳匯出款項 ≥ HK$8,000另有發款人核實／紀錄要求；低於HK$8,000的電傳亦須附基本資料。虛擬資產列於法定CDD觸發，並不表示MSO牌照准許提供所有VA服務。','Non-wire outward remittances ≥ HK$8,000 have separate originator verification / record duties; wires below HK$8,000 still need basic information. Listing VA in statutory CDD triggers does not authorize all VA services under an MSO licence.'),links=[dict(href='#timing',label=p('延遲核實及無法完成CDD','Deferred verification and inability to complete CDD')),dict(href='#remittances',label=p('非電傳匯款要求','Non-wire remittance requirements'))])
    add(6,'simplified','cdd-extent-tree','decision',p('CDD要做到甚麼程度','How much CDD is needed'),refs=refs(6,'cdd',[0])+refs(6,'simplified')+refs(6,'enhanced',[0])+refs(6,'remote'),intro=p('基本措施：識別及核實客戶；如有實益擁有人，識別並採合理措施核實；業務關係的目的及性質並非明顯時取得資料；有代表時識別、合理核實代表身分，並核實授權。','Basic measures: identify / verify the customer; where there is a BO, identify and take reasonable verification measures; obtain purpose / intended nature information where not obvious for a business relationship; identify and reasonably verify a representative and verify authority.'),nodes=[
        dict(test=p('高風險，或另有適用的加強要求？','High risk, or another applicable enhanced requirement?'),yes=p('基本CDD＋適用加強措施；按風險及具體規定決定內容，不是每種情況都套同一PEP清單。','Basic CDD + applicable enhanced measures, tailored to risk and the specific requirement; not the same PEP checklist in every case.')),
        dict(test=p('風險分析確認低風險 AND 無ML/TF懷疑 AND 無身分資料疑問？','Risk analysis establishes low risk AND no ML/TF suspicion AND no identification doubts?'),yes=p('可採取與風險相稱的簡化措施；仍須識別／核實客戶及持續監察。','May apply proportionate simplified measures; still identify / verify the customer and conduct ongoing monitoring.'),no_label=p('否','NO'),no=p('採一般CDD，並按已識別的風險調整措施。','Apply ordinary CDD and adapt measures to identified risks.'))],note=p('「低風險」不等於自動免識別／核實實益擁有人：附表2第4條須符合指定客戶／產品條件。非面對面等額外要求亦須獨立處理；依賴中介人不轉移MSO責任。','Low risk is not automatic BO identification / verification exemption: Schedule 2 s.4 requires specified customer / product conditions. Address additional requirements such as non-face-to-face situations separately; intermediary reliance does not transfer MSO responsibility.'),links=[dict(href='#enhanced',label=p('加強措施及SOW／SOF','Enhanced measures and SOW / SOF')),dict(href='#remote',label=p('非面對面條件及例外','Non-face-to-face conditions and exceptions'))])
    v=old('party-roles');replace('party-roles','relationships',relations=[
        rel(p('公司甲：客戶','Company A: customer'),p('建立關係／委託交易','Establishes relationship / instructs transaction'),p('MSO','MSO'),p('須識別及核實公司本身，不能只核實到場的人。','Identify and verify the company itself, not only the person attending.')),
        rel(p('個人乙：持股25.1%','Individual B: holds 25.1%'),p('超過25%的擁有權','Ownership above 25%'),p('公司甲','Company A'),p('簡化例子：符合公司BO的持股一項；恰好25%不符合這一項，但其他控制條件仍可能符合。','Simplified example: satisfies the corporate BO shareholding limb; exactly 25% does not satisfy that limb, but other control limbs may apply.')),
        rel(p('個人丙：PPTA代表','Individual C: PPTA representative'),p('獲授權代表','Authorized to act for'),p('公司甲','Company A'),p('識別、合理核實代表身分，並核實授權；代表不會因此取代公司成為客戶。','Identify, reasonably verify the representative, and verify authority; representation does not replace the company as customer.')),
        rel(p('個人丁：董事','Individual D: director'),p('屬關連人士','Is a connected party of'),p('公司甲','Company A'),p('取得姓名；如同時是BO或代表，另按該身分處理。乙、丙、丁可以是同一人。','Obtain the name; apply additional duties if also BO or representative. B, C and D may be the same person.'))],note=p('這是公司例子，不能把25%套到信託。BO各類定義及SCR界線見本部分「實益擁有人」；第三方收款人不自動成為發款MSO的客戶。','A company example: do not apply 25% to trusts. See Beneficial owners for each definition and SCR distinctions; a third-party beneficiary is not automatically the ordering MSO’s customer.'),links=[dict(href='#beneficial-owners',label=p('完整BO定義及SCR','Full BO definitions and SCR'))])
    v=old('sow-sof');replace('sow-sof','paths',paths=[
        route(p('同一位客戶 · SOW財富來源','Same customer · SOW'),[p('多年經營業務所得利潤','Profits from running a business over years'),p('整體累積財富','Overall accumulated wealth')],[p('累積成','Accumulate into')],p('教學例子：回答「整體財富怎樣形成」。可包括投資及繼承等來源。','Teaching example: explains how overall wealth arose. Other sources include investments and inheritance.')),
        route(p('同一位客戶 · SOF資金來源','Same customer · SOF'),[p('本次出售物業所得','Proceeds from this property sale'),p('銀行戶口','Bank account'),p('本次匯款','This remittance')],[p('存入','Deposited into'),p('匯出','Sent as')],p('教學例子：SOF追問本次款項由甚麼活動產生；銀行是傳送渠道，不是充分的來源解釋。','Teaching example: SOF asks which activity generated this money. The bank is a channel, not a sufficient explanation of origin.'))],note=p('按風險採取合理措施取得及佐證資料；需要同時確立SOW與SOF的情況不能任選其一。不是每案都要相同年期的全部財務歷史。','Obtain and corroborate information with reasonable, risk-based measures. Where both SOW and SOF are required, neither substitutes for the other. No identical full historical lookback applies to every case.'))
    v=old('pep-categories');v['headers']=[p('身分類別','Status category'),p('何時適用共同加強措施','When the common enhanced measures apply'),p('條件','Conditions')]
    v['rows'][0][1]=p('客戶／BO屬非香港PEP','Customer / BO is a non-Hong Kong PEP')
    v['rows'][1][1]=p('關係屬高風險','The relationship is high risk')
    former=v['rows'].pop();v['note']=p('前PEP是跨類別的離任狀態，不是第三個互斥地域類別。離任不自動停止措施；須適當評估沒有餘下高風險、獲高級管理層批准並保留理由，不能只按固定年期豁免。','Former PEP is a status across categories, not a third mutually exclusive geographical class. Leaving office does not automatically end measures: assess that no high risk remains, obtain senior approval and retain reasons; no fixed-year automatic exemption.')
    add(6,'peps','pep-common-and','logic',p('適用時，三組措施同時需要','When applicable, all three groups of measures'),refs=v['refs'],operator=p('全部 · AND','ALL · AND'),items=[p('建立／繼續關係前取得高級管理層批准','Senior-management approval before establishing / continuing the relationship'),p('採合理措施確立財富來源 AND 資金來源','Reasonable measures to establish source of wealth AND source of funds'),p('加強持續監察','Enhanced ongoing monitoring')],note=p('上圖先判斷類別及風險；發現既有關係中的PEP或風險轉高時也須處理。親屬／密切關係及前PEP適用細節見正文。','First apply the category and risk matrix above. Act on PEP discovery in existing relationships and increased risk too. See the text for family / close associates and former PEP details.'))
    v=old('transfer-information');replace('transfer-information','packet',groups=[
        dict(title=p('跨境電傳共同資料：不論是否達HK$8,000','Cross-border wires: common information at both amounts'),operator=p('全部 · AND','ALL · AND'),items=[p('發款人姓名 ＋ 發款戶口號碼','Originator name + originator account number'),p('受款人姓名 ＋ 受款戶口號碼','Beneficiary name + beneficiary account number')],note=p('沒有該戶口才用可追查的獨特交易參考編號，不能任意取代現有戶口號碼。','Use a traceable unique transaction reference only where no account exists; not freely in place of an existing account number.')),
        dict(title=p('達HK$8,000：另加發款人資料','At least HK$8,000: additional originator information'),operator=p('至少一項 · OR','AT LEAST ONE · OR'),items=[p('地址','Address'),p('客戶識別號碼','Customer identification number'),p('身分證明文件號碼','Identification-document number'),p('自然人：出生日期 AND 出生地點','Individual: date of birth AND place of birth')],note=p('發款人資料須準確，並完成適用CDD。低於門檻的非經常發款人一般毋須核實，但相連交易達門檻、懷疑及資料疑問仍須處理。','Originator data must be accurate and applicable CDD completed. Below-threshold occasional originators generally need not be verified, but linked totals, suspicion and doubts still matter.'))],note=p('這是跨境電傳資料包；本地電傳、批次檔案及轉帳類型豁免各有條件，見下文。不要把資料要求與機構傳送責任混成同一流程。','This is the cross-border wire information packet. Domestic wires, batch files and excluded transfer types have separate conditions below. Data requirements and institutional transmission responsibilities are different questions.'))
    add(6,'wire-receiving','wire-responsibilities','paths',p('電傳鏈條：每一站的責任','Wire-transfer chain: responsibilities at each stage'),refs=refs(6,'wire-transfers')+refs(6,'wire-receiving'),paths=[
        route(p('資料隨付款鏈傳遞','Information travels with the payment chain'),[p('匯款機構：附上所需資料','Ordering institution: include required data'),p('中介機構：保留隨附資料','Intermediary institution: retain accompanying data'),p('收款機構：偵測缺漏並作適用核實','Beneficiary institution: detect omissions and verify where applicable')],[p('傳遞','Pass on'),p('傳遞','Pass on')],p('中介及收款機構須有風險為本程序，決定缺漏資料時執行、拒絕或暫停及跟進；不是每次缺漏自動拒絕。技術限制及本地轉帳例外見正文。','Intermediary and beneficiary institutions need risk-based procedures to execute, reject or suspend and follow up when data are missing; no automatic rejection for every omission. Technical limitations and domestic exceptions are detailed below.'))])
    add(6,'trade-based-laundering','trade-value-paths','paths',p('貿易洗錢：分開看貨物、單據與付款','Trade-based laundering: separate goods, documents and payments'),refs=refs(6,'trade-based-laundering',[0,2,5]),paths=[
        route(p('高報價格的簡化例子','Simplified over-invoicing example'),[p('實際貨物價值較低','Lower actual goods value'),p('發票聲稱價值較高','Higher invoiced value'),p('買方向賣方支付較多','Buyer pays seller more')],[p('不一致','Mismatch'),p('按單據付款','Payment against invoice')],p('差額可把額外價值移向賣方；低報可反向移動價值。需結合商品、定價及關係評估。','The difference can move extra value to the seller; under-invoicing can reverse the direction. Assess goods, pricing and relationships.')),
        route(p('重複發票的簡化例子','Simplified multiple-invoicing example'),[p('同一批貨物','One shipment'),p('多份發票／融資要求','Multiple invoices / financing requests'),p('多次付款','Repeated payments')],[p('重複表示','Represented repeatedly'),p('造成','Generate')],p('指標是查詢線索，不是自動證明洗錢；虛假貨物、數量差異及單據矛盾見正文。','Indicators prompt enquiry; they do not automatically prove laundering. See the text for phantom goods, quantity differences and document inconsistencies.'))])
    old('trade-value-paths')['paths'][0]['symbols']=['≠','→']

    # Part 7: actual reporting decision, concurrent duties and separate clocks.
    add(7,'internal-report','reporting-route','paths',p('內部報告：不經無關管理層篩選','Internal reporting: no unrelated management filter'),refs=refs(7,'internal-report',[0]),paths=[
        route(p('先內部披露','Internal disclosure'),[p('員工發現知情／懷疑','Staff identify knowledge / suspicion'),p('MLRO評估','MLRO assesses')],[p('無不必要延誤地報告','Report without undue delay')],p('按程序直接交MLRO；非報告／合規管理層不得把報告篩掉。內部報告應載事實及懷疑理由。','Report directly under the procedure; non-reporting / non-compliance management must not filter it out. Include facts and grounds.')),
        route(p('評估後仍知情／懷疑','Knowledge / suspicion after assessment'),[p('MLRO','MLRO'),p('JFIU','JFIU')],[p('迅速報告','Report promptly')],p('考慮合理可得的相關CDD、交易及其他資料；不能無限期等齊所有資料。','Consider reasonably available relevant CDD, transaction and other information; do not wait indefinitely for everything.')),
        route(p('評估後沒有知情／懷疑','No knowledge / suspicion after assessment'),[p('MLRO判斷不報告','MLRO decides not to report'),p('保留理由及處理紀錄','Retain reasons and action records')],[p('必須留痕','Document')],p('不是收到每份內部報告都自動向JFIU提交STR；其後新事實可能要求重新評估。','Not every internal report automatically becomes an STR to JFIU; new facts may require reassessment.'))])
    add(7,'after-report','after-report-parallel','logic',p('提交STR後：並行處理的事項','After an STR: concurrent responsibilities'),refs=refs(7,'after-report')+refs(7,'tipping-off'),operator=p('並行處理，不是先後步驟','CONCURRENT, not sequential'),items=[p('評估法定披露／同意與抗辯條件；提交報告不等於自動獲准處理財產。','Assess statutory disclosure / consent and defence conditions; filing is not automatic permission to deal.'),p('應立即檢視客戶／關係風險及適當措施；不能只等待JFIU回覆。','Should immediately review customer / relationship risk and appropriate measures; do not merely wait for JFIU.'),p('防止通風報訊；繼續監察，新可疑活動再交MLRO判斷是否另報。','Prevent tipping off; keep monitoring and refer new suspicious activity to the MLRO for further-report decisions.')],note=p('這三項是職責分類，不代表每案的措施完全相同；法定抗辯的「事前披露＋同意」或「事後自發且盡快披露」條件見正文。','These are responsibility categories, not identical actions in every case. The statutory defence alternatives—prior disclosure + consent, or own-initiative disclosure as soon as reasonable afterwards—are explained below.'))
    v=old('retention-clocks');replace('retention-clocks','clocks',clocks=[clock(*row) for row in v['rows']],note=p('每一行有自己的起算事件，不共用同一時間軸。海關書面要求較長保存期及未成功開戶的風險考慮見下文。','Each row has its own starting event, not a common timeline. Longer written CCE requirements and risk considerations for unsuccessful applications are detailed below.'))
    old('cdd-trigger-tree')['links'].insert(0,dict(href='#memory-cdd-extent-tree',label=p('接著判斷CDD程度','Then determine CDD extent')))
    old('cdd-trigger-tree')['links'].append(dict(href='part-7.html#tipping-off',label=p('繼續CDD可能通風報訊的例外','Exception where continued CDD may tip off')))
    old('cdd-trigger-tree')['refs']+=refs(7,'tipping-off')
    # Retained tables gain grouping rather than decorative boxes.
    v=old('money-boundaries');v['groups']=[dict(title=p('CDD及匯款核實','CDD and remittance verification'),rows=v['rows'][:3]),dict(title=p('跨境現金申報：獨立制度','Cross-boundary cash: a separate regime'),rows=[v['rows'][3]]),dict(title=p('找換交易保障：獨立制度','Exchange protections: a separate regime'),rows=[v['rows'][4]])]
    v=old('review-frequency');v['headers']=[p('事項','Matter'),p('定期／事前要求','Periodic / advance requirement'),p('另行觸發及界線','Other triggers and limits')]
    old('penalty-ceilings')['formulae'][0]['note']=p('最高額不是必罰額；限期後持續違反補救要求另可每日最高HK$100,000。須依適用程序及條件。','A ceiling is not an automatic fine. Continued non-compliance with remedial requirements after the deadline may separately attract up to HK$100,000 per day, subject to the applicable procedure and conditions.')
    old('penalty-ceilings')['formulae'][1]['note']=p('牌照紀律制度；限期後持續違反補救要求另可每日最高HK$10,000。不可與第21條互換。','Licensing discipline; continued non-compliance with remedial requirements after the deadline may separately attract up to HK$10,000 per day. Do not substitute the section 21 ceiling.')
    # Refinement: visual form must preserve scope, equal alternatives and nested logic.
    old('licence-clocks')['title']=p('牌照事項：事前批准、1個月及結業通知','Licence actions: prior approval, one month and cessation notices')
    old('retention-clocks')['clocks'][-1]['duration']=p('應保存至少3年（指引）','Should retain for at least three years (Guideline)')
    old('retention-clocks')['clocks'][-1]['start']=p('指引沒有另訂起算公式；按培訓日期保留紀錄','No separate starting formula in the Guideline; keep dated training records')
    old('penalty-ceilings')['formulae'][0]['expression']=p('上限＝以下較大者：HK$10,000,000；3 ×（因違反而獲取的利潤或避免的開支）','Maximum = the greater of: HK$10,000,000; 3 × (profit gained or costs avoided through the contravention)')
    old('inspection-versus-investigation')['peers']=True
    old('fee-components')['headers']=[p('申請事項','Application'),p('基本或逐項費用','Base or per-item charge'),p('附加項目及條件','Additions and conditions')]
    old('three-places')['headers']=[p('地方類別','Type of place'),p('用途及適用對象','Purpose and applicability'),p('地址及使用限制','Address and use restrictions')]

    # A suspicion trigger can coexist with ANY of the relationship/transaction cases.
    # Keep the published anchor so existing links still reach the correct material.
    v=old('cdd-trigger-tree')
    original_nodes=v.pop('nodes')
    v['kind']='trigger-cases'
    v['intro']=p('CDD＝客戶盡職審查。先留意適用於所有情況的懷疑／資料疑問，再對照關係及交易類型；各項可同時適用，並非答「是」便略過其餘要求。','CDD = customer due diligence. Check suspicion / identification doubts across all situations, then the relationship or transaction case. Requirements can coexist; a matching case does not remove other applicable duties.')
    v['cases']=[
        dict(label=p('跨情況要求：任何金額','Across all cases: any amount'),condition=p('懷疑ML/TF，或懷疑原有身分資料的真實性／充分性','ML/TF suspicion, or doubts about the truth / adequacy of existing identification information'),action=original_nodes[0]['yes'],cross_cutting=True),
        dict(label=p('建立業務關係','New business relationship'),condition=p('不論交易金額','Regardless of transaction amount'),action=original_nodes[1]['yes']),
        dict(label=p('已存在業務關係','Existing business relationship'),condition=p('關係持續期間','Throughout the relationship'),action=original_nodes[2]['yes']),
        dict(label=p('非經常交易','Occasional transaction'),condition=p('電傳／虛擬資產轉帳 ≥ HK$8,000；其他 ≥ HK$120,000（或等值）。單筆或看來相連的交易合計。','Wire / VA transfer ≥ HK$8,000; others ≥ HK$120,000 (or equivalent). A single operation or linked operations in aggregate.'),action=p('達門檻：執行前做CDD。未達門檻：只表示未觸發這項金額條件；上面的懷疑／資料疑問及其他義務仍適用。','At threshold: CDD before execution. Below threshold: only this amount-based trigger is absent; the cross-cutting suspicion / doubt trigger and other duties still apply.'))]
    old('shell-bank-and')['items'][-1]=dict(lead=p('不隸屬另一家符合以下全部條件的法團：','Unaffiliated with another corporation meeting ALL of these conditions:'),all=[p('在某司法管轄區成立','Incorporated in a jurisdiction'),p('獲准在該處經營銀行業務','Authorized to conduct banking there'),p('在該處有實體經營','Physically present there')])
    old('transfer-information')['groups'][1]['items'][-1]=dict(lead=p('自然人：以下兩項合為一個選項','Individual: these two together form ONE option'),all=[p('出生日期','Date of birth'),p('出生地點','Place of birth')])
    old('pep-common-and')['items'][1]=dict(lead=p('採合理措施確立以下兩者：','Take reasonable measures to establish BOTH:'),all=[p('財富來源（SOW）','Source of wealth (SOW)'),p('資金來源（SOF）','Source of funds (SOF)')])
    for ss in panels.values():
        for ps in ss.values():
            for v in ps:
                if v['kind']!='table':
                    v.pop('rows',None);v.pop('headers',None)
    # Remove false sequencing of statutory caveats; substantive text is unchanged.
    for s in parts[7]['sections']:
        if s['id']=='internal-report':
            for b in s['blocks']:b['kind']='list'

    # Exam-focus pass: near amounts on one ordinal line; filled/hollow shows whether equality counts.
    v=old('money-boundaries');rows=v['rows']
    def lane(row,tick,inclusive,boundary,**kw):return dict(label=row[0],tick=tick,inclusive=inclusive,boundary=boundary,trigger=row[2],detail=row[3],**kw)
    replace('money-boundaries','thresholds',ticks=[
        dict(key='8k',at=16,label=p('HK$8,000','HK$8,000')),
        dict(key='100k',at=58,label=p('HK$100,000','HK$100,000')),
        dict(key='120k',at=80,label=p('HK$120,000','HK$120,000'))],
        lane_groups=[
        dict(title=p('AMLO：CDD及匯款核實','AMLO: CDD and remittance verification'),lanes=[
            lane(rows[1],'8k',True,p('≥ HK$8,000：恰好8,000元亦適用','≥ HK$8,000: exactly HK$8,000 is included')),
            lane(rows[2],'8k',True,p('≥ HK$8,000：恰好8,000元亦適用','≥ HK$8,000: exactly HK$8,000 is included')),
            lane(rows[0],'120k',True,p('≥ HK$120,000：恰好120,000元亦適用','≥ HK$120,000: exactly HK$120,000 is included'))]),
        dict(title=p('第629章：跨境現金申報（獨立制度）','Cap.629: cross-boundary cash declarations (separate regime)'),lanes=[
            lane(rows[3],'120k',False,p('> HK$120,000：恰好120,000元不觸發','> HK$120,000: exactly HK$120,000 does not trigger'))]),
        dict(title=p('第34章：找換交易保障（獨立制度）','Cap.34: exchange-transaction protections (separate regime)'),lanes=[
            lane(rows[4],'100k',False,p('> HK$100,000：恰好100,000元仍受第34章規管','> HK$100,000: exactly HK$100,000 stays within Cap.34'),exclusion=True)])],
        scale_note=p('刻度只表示金額先後，不按比例。同一個120,000元：一般非經常交易CDD用「≥」，跨境申報用「>」。','Positions show order only, not scale. At the same HK$120,000, occasional-transaction CDD uses “≥” while cross-boundary declaration uses “>”.'))

    # Deadlines: each row has its own starting event; no shared timeline across unrelated events.
    def seg(kind,start,end,label=None):return {'kind':kind,'from':start,'to':end,'label':label}
    def deadline(row,anchor,segments,at):
        if isinstance(row,dict):row=[row['label'],row['start'],row['duration'],row['note']]
        return dict(label=row[0],start=row[1],duration=row[2],note=row[3],anchor=anchor,segments=segments,at=at)
    def after(row,anchor,amount):return deadline(row,anchor,[seg('window',8,62,amount),seg('late',62,100,p('逾期','Late'))],8)
    def before(row,anchor,amount):return deadline(row,anchor,[seg('window',0,40,amount),seg('late',40,88,p('太遲','Too late'))],88)
    def prior(row,anchor,amount):return deadline(row,anchor,[seg('window',0,64,amount),seg('late',64,100,p('事後不行','Not after'))],64)
    def wait(row,anchor,blocked,amount):return deadline(row,anchor,[seg('late',8,52,blocked),seg('window',52,100,amount)],8)
    not_scale=p('每行有自己的起算事件，不共用時間軸；線段長度只表示先後，不按比例。','Each row has its own starting event; rows do not share a timeline, and segment lengths show direction only, not scale.')
    v=old('licence-clocks');rows=v.pop('clocks')
    replace('licence-clocks','deadlines',scale_note=not_scale,deadlines=[
        prior(rows[0],p('擬加入','Proposed appointment'),p('事先書面批准','Prior written approval')),
        prior(rows[1],p('開始營業','Start operating'),p('營業前獲批','Approved first')),
        before(rows[2],p('牌照屆滿','Licence expiry'),p('最少提前45日','≥ 45 days before')),
        after(rows[3],p('改變當日','Date of change'),p('1個月內通知','Notify ≤ 1 month')),
        deadline(rows[4],p('停止營業','Cessation'),[seg('window',0,40,p('事先通知','Notify first')),seg('window2',40,70,p('7日內交還','Return ≤ 7 days')),seg('late',70,100,p('逾期','Late'))],40)])
    v=old('assessment-clocks');rows=v.pop('rows');v.pop('headers');v.pop('groups')
    received=p('收到邀請','Invitation received');issued=p('成績發出','Result issued')
    replace('assessment-clocks','deadlines',scale_note=not_scale,deadline_groups=[
        dict(title=p('申請及人事變更','Applications and personnel changes'),rows=[
            after(rows[0],p('面見海關','Customs interview'),p('30日內應考','Attend ≤ 30 days')),
            after(rows[1],received,p('7日內提名','Nominate ≤ 7 days')),
            after(rows[2],received,p('30日內應考','Attend ≤ 30 days')),
            after(rows[3],p('通知變更','Change notified'),p('30日內安排','Arrange ≤ 30 days'))]),
        dict(title=p('應考結果及重考','Results and retakes'),rows=[
            after(rows[5],p('評核','Assessment'),p('14日內電郵','Email ≤ 14 days')),
            wait(rows[4],issued,p('等候30日','Wait 30 days'),p('之後可重考','Retake after'))]),
        dict(title=p('覆核成績','Rechecking results'),rows=[
            after(rows[6],issued,p('7日內書面要求','Request ≤ 7 days')),
            after(rows[7],p('收到要求','Request received'),p('14日內回覆','Reply ≤ 14 days'))])])

    # Part 6 anchor figure: what to collect and verify for each customer type (¶4.3.2–4.3.12).
    add(6,'identity','identity-data','id-columns',p('三類客戶：收集甚麼、核實甚麼','Three customer types: what to collect and what to verify'),refs=refs(6,'identity',[0,4]),columns=[
        dict(title=p('自然人','Individual'),paras=p('第4.3.2–4.3.3段','¶4.3.2–4.3.3'),
            collect=[p('全名','Full name'),p('出生日期','Date of birth'),p('國籍','Nationality'),p('獨特識別號碼（例如身份證或護照號碼）及文件的類別','Unique identification number (e.g. identity card or passport number) and document type')],
            verify=[p('姓名','Name'),p('出生日期','Date of birth'),p('獨特識別號碼及文件的類別','Unique identification number and document type')],
            sources=[p('香港身份證或其他國家的身份證','Hong Kong identity card or other national identity card'),p('有效的旅遊證件（例如未過期的護照）','Valid travel document (e.g. unexpired passport)'),p('其他可靠及獨立來源的文件、數據或資料（例如政府機構發出的文件）','Other documents, data or information from a reliable and independent source (e.g. issued by a government body)')],
            note=p('國籍須收集，但不在一般核實項目內；另須取得住址資料（第4.3.5段），不代表一律要地址證明。','Nationality is collected but is not in the general verification set; also obtain residential address information (¶4.3.5), without a universal address-proof requirement.')),
        dict(title=p('法人','Legal person'),paras=p('第4.3.6–4.3.7段','¶4.3.6–4.3.7'),
            collect=[p('全名','Full name'),p('註冊、成立或登記的日期','Date of incorporation, establishment or registration'),p('註冊、成立或登記的地點（包括註冊辦事處地址）','Place of incorporation, establishment or registration (including registered office address)'),p('獨特識別號碼（例如註冊號碼或商業登記號碼）及文件的類別','Unique identification number (e.g. incorporation or business registration number) and document type'),p('主要營業地點（如與註冊辦事處地址不同）','Principal place of business (if different from the registered office)')],
            verify=[p('名稱','Name'),p('法定形式','Legal form'),p('現時（核實時）仍然存在','Current existence (at the time of verification)'),p('規管和約束該法人的權力','Powers that regulate and bind it')],
            sources=[p('公司註冊證明書','Certificate of incorporation'),p('獨立公司註冊登記冊的記錄','Record in an independent company registry'),p('職權證明書','Certificate of incumbency'),p('良好聲譽證明書','Certificate of good standing'),p('註冊記錄','Record of registration'),p('合夥協議或契約','Partnership agreement or deed'),p('章程文件','Constitutional document'),p('其他可靠及獨立來源的相關文件、數據或資料','Other relevant documents, data or information from a reliable and independent source')],
            note=p('公司註冊證明書未必證明現時仍然存在，可能需要多於一份文件。','A certificate of incorporation may not prove current existence; more than one document may be needed.')),
        dict(title=p('信託或類似法律安排','Trust or similar legal arrangement'),paras=p('第4.3.11–4.3.12段','¶4.3.11–4.3.12'),
            collect=[p('信託或法律安排的名稱','Name of the trust or legal arrangement'),p('成立或結算日期','Date of establishment or settlement'),p('以法律監管有關信託或法律安排的司法管轄區','Jurisdiction whose laws govern it'),p('任何官方機構授予的獨特識別號碼（如有）及文件的類別','Unique identification number (if any) granted by an official body and document type'),p('註冊辦事處地址（如適用）','Registered office address (if applicable)')],
            verify=[p('名稱','Name'),p('法定形式','Legal form'),p('現時（核實時）仍然存在','Current existence (at the time of verification)'),p('規管和約束該信託的權力','Powers that regulate and bind the trust')],
            sources=[p('信託契據或類似文書','Trust deed or similar instrument'),p('成立信託的相關國家的合適登記冊記錄','Record of an appropriate register in the country of establishment'),p('以專業身分行事的受託人簽發的書面確認書','Written confirmation from a trustee acting in a professional capacity'),p('已覆核相關文書的律師簽發的書面確認書','Written confirmation from a lawyer who has reviewed the instrument'),p('同屬一個金融集團的信託公司簽發的書面確認書（如該公司管理有關信託）','Written confirmation from a same-group trust company that manages the trust')],
            note=p('核實的是規管和約束「該信託」的權力（裁決E24）；不要把公司的25%門檻套用到信託。','Verify the powers that bind the trust itself (decision E24); do not apply the corporate 25% threshold to trusts.'))],
        note=p('「收集」與「核實」是兩件事：收集的項目比須核實的多。','Collection and verification differ: more is collected than must be verified.'))
    return panels
