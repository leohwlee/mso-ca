# Working on MSO sources and questions

- Before editing questions, revision content, source files or reading order, read
  [source maintenance](docs/SOURCE-MAINTENANCE.md),
  [question format](bank/FORMAT.md) and the applicable authoring guide.
- `docs/catalog.json` is the authoritative mapping. A filename's leading number
  is its reading order, not its stable source ID. Never infer a quote ID,
  transcript path or extracted-text path from that number.
- Source `02` remains the AML/CFT Guideline (reading item 03); source `10`
  remains Cap. 615 (reading item 04). S02 is a display label; JSON stores `"02"`.
- The archive has 32 reading materials. The existing bank and coverage audits
  still use the original 23 sources. Verify content, edition, language and
  citation mapping before using an addition in questions. A reading pointer or
  statutory extract must not be treated as a complete source publication.
- Preserve question IDs, source IDs and historical audit evidence. Append
  review evidence for later changes; do not replace old hashes to silence checks.
- Run `python docs/build_catalog.py --check` and `go test ./...` for source
  changes. For question or evidence changes also run the four audit checks in
  `DEVELOPMENT.md`. Build both HTML outputs when generation may be affected.
