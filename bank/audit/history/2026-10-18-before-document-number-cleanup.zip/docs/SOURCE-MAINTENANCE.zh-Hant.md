# 文件改名後的來源維護說明

[English version →](SOURCE-MAINTENANCE.md)

改題、改溫習資料、更換官方文件或調整閱讀順序前，先讀本說明。2026年10月18日的整理更改了文件名稱並加入閱讀材料；題號、引文來源編號及原有來源內容保留。

## 閱讀序號與固定來源編號

| 項目 | 用途 | 以《打擊洗錢指引》為例 |
|---|---|---|
| 閱讀序號 `order` | 決定檔名及建議閱讀次序，可調整 | `3`，檔名以 `03_高_` 開頭 |
| 優先級 `priority` | 復習重要程度，可調整 | `high`（高） |
| 固定來源編號 `id` | 題庫識別同一來源，不能移作另一文件 | `"02"`，目錄顯示為S02 |
| 中英文檔名 | 實際原件的位置 | 從 `catalog.json` 查找 |
| 引文的 `doc` | 使用固定來源編號，不加S | `"doc": "02"` |
| 擷取文字 | 按固定來源編號保存 | `text/EN/02.txt`、`text/TC/02.txt` |
| 圖片人工轉錄 | 如有，同樣按固定來源編號保存 | S16仍用 `transcripts/16.json`，閱讀序號現為18 |

以 `catalog.json` 為對照依據。舊決定冊和審核報告中的「文件02」指S02，不是目前排第二的文件。原件內容沒有改動，既有PDF頁碼仍然適用。原題庫來源對照保存在 `QUESTION-SOURCES.zh-Hant.md`。

例如 `python bank/find.py EN 02 "target market"` 仍搜尋《打擊洗錢指引》，不要因為它現在排第三就改成 `EN 03`。

## 對現有功能的影響

模擬試及離線版本讀取 `web/` 和題庫，不按PDF檔名載入官方資料。此次沒有改題號，也沒有改瀏覽器儲存練習紀錄的名稱。溫習資料由 `revision/` 產生，來源仍使用固定編號。擷取程式和來源測試已透過目錄查找新檔名；歷史審核的舊檔名由 `previous_file` 對應，再次改名亦要保留這個欄位。

## 再次改名或調整排序

1. 先在 `catalog.json` 找固定來源編號，再改中英文檔名、閱讀序號和優先級。保留 `id` 及 `previous_file`；內容不變時，原件摘要也不變。
2. 執行 `python docs/extract_text.py`（需要PyMuPDF），更新文字清單中的檔名；再執行 `python docs/build_catalog.py`，重新產生中英文目錄。不要直接改自動產生的README表格。
3. 如維護檔案已記錄於 `source-reorganization.json`，保留原有 `before_text` 及 `before_sha256`。覆核新版本後，只更新 `after_sha256`，使用UTF-8文字及LF換行計算SHA-256；檢查亦容許正常的LF／CRLF轉換。不要為消除錯誤而重算歷史來源或題目證據的摘要。
4. 執行下面的檢查；修正路徑或對應錯誤，不要把引文、擷取文字及轉錄重編為閱讀序號。

## 更新或加入官方內容

同一來源更新版本時保留固定編號；不同材料才分配新的未用編號。歸檔官方內容，記錄網址、版本及摘要。PDF摘要按原始位元組計算，Markdown摘要先統一CRLF為LF。重新擷取文字並覆核受影響引文；有圖內人工轉錄時，須對新PDF重新核對。

新增S24至S32仍未納入題庫覆蓋審核。獲授權按它們出題時，要閱讀相關原文，在 `sources_test.go` 的 `docPatterns` 加入引用名稱與來源的對應，再按 `bank/FORMAT.md` 及既有流程覆核。引文逐字命中不能單獨證明答案正確及屬考試範圍。後續改題須追加覆核證據，不可覆寫舊審核快照；新矛盾依既有決定流程處理。

S27只有第34章附表2及3的官方網頁摘錄；S28的TC檔是通往官方英文風險指標的閱讀入口，不是中文譯本。培訓資料的語言版本亦可能來自不同講座日期，須保留各自來源及這些限制。

## 檢查指令

```bash
python docs/build_catalog.py --check
go test ./...
python bank/audit/report.py --check
python bank/audit/terms_report.py --check
python bank/audit/p1_report.py --check
python bank/audit/remaining_report.py --check
```

可能影響產生HTML時，另執行：

```bash
go run . -export-html dist/mso-ca.html
python revision/pack_build.py dist/mso-revision-pack.html
```

CI及發佈前會自動檢查目錄排序、原件檔名、摘要及目錄內容。Go測試核對原件、文字、引文及轉錄的連結；審核檢查保護已有證據。庫外指向舊實際檔名的書籤，須改用目錄或現行檔名。
