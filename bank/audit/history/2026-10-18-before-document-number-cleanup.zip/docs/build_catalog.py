"""Generate the bilingual reading directory from catalog.json.

    python docs/build_catalog.py          # write both README files
    python docs/build_catalog.py --check  # verify links, order, hashes and saved output

Reading order is independent of the stable IDs used by quotes and audit records.
"""
import hashlib
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
PRIORITIES = {'high': ('高', 'High'), 'medium': ('中', 'Medium'), 'low': ('低', 'Low')}


def local_link(lang, edition):
    return f'[{lang}](<{lang}/{edition["file"]}>)'


def render(catalog, lang):
    tc = lang == 'TC'
    documents = catalog['documents']
    lines = [
        '# MSO 官方資料閱讀目錄' if tc else '# MSO official reading directory', '',
        '[English version →](README.md)' if tc else '[繁體中文版 →](README.zh-Hant.md)', '',
        ('共 **32 項材料**，按「高 → 中 → 低」及同級建議閱讀順序排列：高9項、中19項、低4項。'
         '在 `TC/` 或 `EN/` 按檔名排序，順次閱讀即可。'
         if tc else
         '**32 materials**, sorted by High → Medium → Low and recommended reading sequence within each level: '
         '9 high, 19 medium, 4 low. Sort filenames in `EN/` or `TC/` and read in order.'), '',
        ('檔名格式：`閱讀序號_優先級_文件名稱（版本）`，例如 `03_高_…`。同一序號的中英文檔案對應同一材料。'
         if tc else
         'Filename format: `reading-order_priority_title (version)`, for example `03_High_…`. '
         'English and Chinese files with the same reading number refer to the same material.'), '',
        ('優先級是根據官方考綱及文件內容作出的復習建議，並非海關公布的出題權重。'
         '高：第一輪重點讀；中：第二輪完整讀或按建議選讀；低：最後快速讀。低優先級不表示不會考。'
         if tc else
         'Priorities are study recommendations based on the official syllabus and document content, not published exam weights. '
         'High: first-pass essentials; Medium: second-pass reading or selected sections; Low: a final quick pass. Low does not mean unexaminable.'), '',
        ('官方依據：《能力評核須知》第5.2至6.1段。七個單元各5題；每單元至少答對3題，總分至少25/35。'
         '參考類別包括第615章、反洗錢指引、牌照指引、其他指引及通函。'
         if tc else
         'Basis: Guidance Notes paragraphs 5.2-6.1. There are seven modules of five questions; passing requires '
         'at least three correct in every module and at least 25/35 overall. References include Cap. 615, '
         'the AML/CFT Guideline, Licensing Guide, other guidelines and circulars.'), '',
        '[官方考試須知 / Official Guidance Notes](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_zh_TW.pdf)', '',
    ]
    for priority in PRIORITIES:
        label = PRIORITIES[priority][0 if tc else 1]
        lines += [f'## {label}' + ('優先級' if tc else ' priority'), '',
                  '| 順序 | 材料及本地檔案 | 它是甚麼 | 閱讀重點 |' if tc else
                  '| Order | Material and local files | What it is | Reading focus |',
                  '|---|---|---|---|']
        for doc in documents:
            if doc['priority'] != priority:
                continue
            title = pathlib.Path(doc['editions'][lang]['file']).stem.split('_', 2)[2]
            if doc.get('circular'):
                title += ' - ' + doc['circular']
            links = ' · '.join(local_link(l, doc['editions'][l]) for l in ['TC', 'EN'])
            added = (' **新增**' if tc else ' **Added**') if not doc['original_bank_source'] else ''
            lines.append(f'| {doc["order"]:02d} | **{title}**{added}<br>{links} | {doc["summary"][lang]} | {doc["reading"][lang]} |')
        lines += ['']
    lines += ['## 版本、語言及收錄範圍' if tc else '## Editions, languages and scope', '']
    if tc:
        lines += [
            '- 原有23份文件保留原件；另加入9項材料，包括5組建議補充資料、較早機構風險評估通函及兩份培訓講義。',
            '- **第20項**是第34章附表2及3的官方網頁文字摘錄，不是完整條例或核證PDF。2026年10月18日已在官方瀏覽器頁面核實版本日期為2025年8月24日；PDF下載未能保存。完整法例及第3至8條、附表1的閱讀入口保存在摘錄內。',
            '- **第22項**收錄共同發布方Egmont Group官網的FATF／Egmont英文原件。未找到並核實官方繁體中文版，因此TC檔是通往本地英文原件的閱讀入口，不是中文譯本。FATF直接下載回傳403，已改從共同發布方取得原件。',
            '- **第27項**兩個語言版本同於2026年1月7日上載，但官網列出的講座日期不同：中文為2025年11月14日、英文為2025年12月9日。各自保留官方版本，不宣稱是同場逐字翻譯。',
            '- **第28項**講座日期為2024年3月12日，2024年4月12日上載。',
            '- **第04項**第615章沿用2026年9月24日歸檔綜合版；本次未重新核實其是否仍為最新版本。第20項已核實的第34章版本不能替代這項核驗。',
            '- 名單及定期聲明會更新，考前請查海關通函及FATF最新資料。仍被引用的原則性通函可保留；與新指引內容重疊不等於已正式失效。',
            '- 現行題庫和溫習資料仍以原有23份來源為依據；新增9項的收錄不代表題庫已加入或完整測試其考點。培訓講義屬輔助閱讀，不是額外的官方考綱。',
        ]
    else:
        lines += [
            '- The original 23 sources are retained unchanged; nine materials have been added, including the recommended additions, the earlier institutional risk assessment circular and two training decks.',
            '- **Item 20** is a text extract of Cap. 34 Schedules 2 and 3 from the official webpage, not the complete Ordinance or a verified PDF. The browser showed version 24 August 2025 on 18 October 2026; the PDF could not be saved. The extract links to the full law and identifies sections 3-8 and Schedule 1 for context.',
            '- **Item 22** contains the official English FATF/Egmont PDF downloaded from co-publisher Egmont Group. Its TC file is a reading pointer, not a Chinese translation. The direct FATF download returned 403.',
            '- **Item 27** was uploaded in both languages on 7 January 2026, but the official portal lists different seminar dates: 14 November 2025 for Chinese and 9 December 2025 for English. These are retained as their respective official editions, not described as verbatim translations of one seminar.',
            '- **Item 28** is dated 12 March 2024 and was uploaded on 12 April 2024.',
            '- **Item 04**, Cap. 615, retains the archived consolidated edition dated 24 September 2026. Whether it is still the latest edition was not reverified in this reorganisation.',
            '- Recheck current lists and periodic statements before the exam. Retain still-cited principles circulars; overlap with later guidance does not itself establish formal withdrawal.',
            '- The current bank and revision pack still use the original 23 sources. Archiving the nine additions does not establish question-bank coverage of them. Training decks are reading aids, not an additional official syllabus.',
        ]
    lines += ['', '## 官方來源及舊編號對照' if tc else '## Official sources and stable source IDs', '',
        ('此處的S編號是供題庫、文字擷取及歷史審核使用的固定來源ID；舊資料中的「文件02」即S02，現在閱讀順序為03。'
         '日常閱讀請用上面的「順序」，不要用S編號排序。'
         if tc else
         'S-numbers are stable source IDs for quotes, extracted text and historical audits. Old references to document 02 mean S02, now reading item 03. Use the reading order above for study.'), '',
        '| 閱讀順序 | 固定來源ID | 官方中文來源 | 官方英文來源 |' if tc else
        '| Reading order | Stable source ID | Official Chinese source | Official English source |',
        '|---|---|---|---|']
    for doc in documents:
        links=[]
        for l in ['TC','EN']:
            ed=doc['editions'][l]
            text='英文原文入口' if l=='TC' and doc['id']=='28' else ('官方來源' if tc else 'Official source')
            links.append(f'[{text}]({ed["url"]})')
        lines.append(f'| {doc["order"]:02d} | S{doc["id"]} | {links[0]} | {links[1]} |')
    lines += ['', '## 維護及引用' if tc else '## Maintenance and references', '',
        ('改題、改名或更新官方文件前，先讀[來源維護說明](SOURCE-MAINTENANCE.zh-Hant.md)，避免混淆閱讀序號及固定來源編號。'
         if tc else
         'Before editing questions, filenames or source content, read [source maintenance](SOURCE-MAINTENANCE.md) to distinguish reading order from stable source IDs.'), '',
        ('[`catalog.json`](catalog.json)記錄閱讀順序、優先級、來源ID、檔名、官方網址及SHA-256摘要。'
         '`text/EN/NN.txt`、`text/TC/NN.txt`、`quotes.json`及`transcripts/NN.json`的NN仍是固定來源ID。'
         '改名時不要把這些ID當作閱讀序號重編。'
         if tc else
         '[`catalog.json`](catalog.json) records reading order, priority, source ID, filename, official URL and SHA-256. '
         'NN in `text/EN/NN.txt`, `text/TC/NN.txt`, `quotes.json` and `transcripts/NN.json` remains the stable source ID.'), '',
        '```bash', 'python docs/extract_text.py', 'python docs/build_catalog.py --check', 'go test ./...', '```', '',
        ('既有題庫各單元的引用統計見[原有23份來源對照](QUESTION-SOURCES.zh-Hant.md)。歷史審核的舊檔名及摘要，'
         '由`source-reorganization.json`和目錄映射保留可核驗的遷移記錄。'
         if tc else
         'See [question-bank source mapping](QUESTION-SOURCES.md) for the original 23 sources. '
         '`source-reorganization.json` and the catalog preserve verifiable migration records for historical paths and hashes.'), '',
        '[海關指引 / Guidelines](https://eservices.customs.gov.hk/MSOS/common/guidelines) · '
        '[海關通函 / Circulars](https://eservices.customs.gov.hk/MSOS/common/circulars) · '
        '[培訓資料 / Capacity building](https://eservices.customs.gov.hk/MSOS/common/capacityBuilding)', '',
        ('官方原文的權利仍屬各發布機構，包括香港特區政府及FATF／OECD與Egmont Group。'
         '本庫的MIT授權不授予這些原文的使用權；詳見[內容授權](../LICENSE-CONTENT.md)。'
         if tc else
         'Rights in official source material remain with its publishers, including the HKSAR Government and FATF/OECD and Egmont Group. '
         'The repository MIT licence grants no rights in those texts; see [content licensing](../LICENSE-CONTENT.md).'), '',
    ]
    return '\n'.join(lines)


def main():
    catalog=json.loads((HERE/'catalog.json').read_text(encoding='utf8'))
    docs=catalog['documents']
    assert [d['order'] for d in docs] == list(range(1,len(docs)+1))
    assert len({d['id'] for d in docs}) == len(docs)
    assert [list(PRIORITIES).index(d['priority']) for d in docs] == sorted(list(PRIORITIES).index(d['priority']) for d in docs)
    seen=set()
    for doc in docs:
        for lang,edition in doc['editions'].items():
            path=HERE/lang/edition['file']
            assert path.parent == HERE/lang and path.is_file(), path
            assert path not in seen, path
            seen.add(path)
            raw=path.read_bytes()
            if path.suffix=='.md':
                raw=raw.replace(b'\r\n',b'\n')
            assert hashlib.sha256(raw).hexdigest()==edition['sha256'], path
            assert path.name.startswith(f'{doc["order"]:02d}_'), path
    actual={p for lang in ['EN','TC'] for p in (HERE/lang).iterdir() if p.is_file()}
    assert seen==actual, 'Uncatalogued or missing files'
    for lang,name in [('TC','README.zh-Hant.md'),('EN','README.md')]:
        content=render(catalog,lang)
        target=HERE/name
        if '--check' in sys.argv:
            assert target.read_text(encoding='utf8')==content, f'Regenerate {target}'
        else:
            target.write_text(content,encoding='utf8',newline='\n')
    print(f'Checked {len(docs)} materials, {len(seen)} files and both reading directories.')


if __name__=='__main__':
    main()
