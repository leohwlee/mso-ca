# Original 23 question-bank sources by module

Stable source IDs remain S01-S23. See the [reading directory](README.md) for reading order. The additions have not been mapped into this question-bank coverage table.



Guidance Notes ¶5.2 name the seven modules; ¶6.1 names five categories of
reference material, but neither says which category feeds which module. The
mapping below is derived from the bank itself — every citation in
[`web/questions.json`](../web/questions.json) resolved to the document it names,
by their stable source IDs. A question may cite two documents, so
the per-document figures can sum above the module total.

| Module | Source documents (questions citing each) | Questions |
|---|---|---|
| **1** General knowledge on AML/CFT and counter-proliferation financing | **S01** (1) · **S02** (23) · **S10** (2) · **S11** (2) · **S14** (2) · **S15** (1) · **S17** (1) · **S18** (1) · **S19** (2) · **S20** (2) · **S21** (1) · **S22** (1) | 32 |
| **2** Parts 1–7 of the AMLO | **S10** (53) · **S22** (1) · **S23** (1) | 53 |
| **3** Schedules to the AMLO | **S02** (2) · **S10** (43) · **S23** (1) | 43 |
| **4** Guidelines promulgated by the C&ED | **S01** (10) · **S03** (29) · **S04** (1) · **S05** (5) · **S06** (5) · **S07** (4) · **S08** (4) · **S09** (5) · **S10** (2) · **S16** (3) · **S22** (1) · **S23** (1) | 59 |
| **5** Systems and controls (i): institutional governance and strategy | **S02** (55) · **S07** (1) · **S10** (1) · **S12** (1) · **S23** (1) | 56 |
| **6** Systems and controls (ii): AML/CFT control areas | **S02** (62) · **S10** (5) · **S12** (2) · **S13** (5) · **S14** (7) · **S22** (26) · **S23** (1) | 74 |
| **7** Systems and controls (iii): demonstrating and monitoring compliance | **S02** (40) · **S22** (1) · **S23** (2) | 40 |

