# MSO official reading directory

[繁體中文版 →](README.zh-Hant.md)

**32 materials**, sorted by High → Medium → Low and recommended reading sequence within each level: 9 high, 19 medium, 4 low. Sort filenames in `EN/` or `TC/` and read in order.

Filename format: `reading-order_priority_title (version)`, for example `03_High_…`. English and Chinese files with the same reading number refer to the same material.

Priorities are study recommendations based on the official syllabus and document content, not published exam weights. High: first-pass essentials; Medium: second-pass reading or selected sections; Low: a final quick pass. Low does not mean unexaminable.

Basis: Guidance Notes paragraphs 5.2-6.1. There are seven modules of five questions; passing requires at least three correct in every module and at least 25/35 overall. References include Cap. 615, the AML/CFT Guideline, Licensing Guide, other guidelines and circulars.

[官方考試須知 / Official Guidance Notes](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_zh_TW.pdf)

## High priority

| Order | Material and local files | What it is | Reading focus |
|---|---|---|---|
| 01 | **Guidance Notes on the Competence Assessment (Dec 2022)**<br>[TC](<TC/01_高_能力評核須知（2022年12月）.pdf>) · [EN](<EN/01_High_Guidance Notes on the Competence Assessment (Dec 2022).pdf>) | Assessment rules and syllabus. | Read sections 5-7, passing rules and attendance arrangements first. |
| 02 | **Competence Assessment - Sample Questions (12 May 2021) - MSSB/CA_01/2021**<br>[TC](<TC/02_高_金錢服務經營者適用的能力評核_參考試題（2021年5月12日）.pdf>) · [EN](<EN/02_High_Competence Assessment - Sample Questions (12 May 2021).pdf>) | Seven official sample questions. | Attempt first, understand every statement, then repeat after the core reading. |
| 03 | **Guideline on AML-CFT for Money Service Operators (Jun 2023)**<br>[TC](<TC/03_高_打擊洗錢及恐怖分子資金籌集指引（金錢服務經營者適用）（2023年6月）.pdf>) · [EN](<EN/03_High_Guideline on AML-CFT for Money Service Operators (Jun 2023).pdf>) | The principal AML/CFT operating guideline for MSOs. | Study chapters 1-11 and Appendix A, including all control areas and remittance rules. |
| 04 | **AMLO Cap 615 - Consolidated (24 Sep 2026)**<br>[TC](<TC/04_高_打擊洗錢及恐怖分子資金籌集條例（第615章）（2026年9月24日綜合版）.pdf>) · [EN](<EN/04_High_AMLO Cap 615 - Consolidated (24 Sep 2026).pdf>) | The statutory text of AMLO, Cap. 615. | Read Parts 1-7 and the Schedules; focus on MSO licensing, supervision, sanctions, review and Schedule 2. |
| 05 | **Licensing Guide (May 2026)**<br>[TC](<TC/05_高_牌照指引（2026年5月）.pdf>) · [EN](<EN/05_High_Licensing Guide (May 2026).pdf>) | Licensing, renewal and continuing operating requirements. | Read exemptions, procedures, premises, local management office, personnel and returns. |
| 06 | **FAQ applicable to all MSOs (C&ED portal) - MSSB/GUIDE_01/2019**<br>[TC](<TC/06_高_適用於所有金錢服務經營者的常見問題（海關網站）.md>) · [EN](<EN/06_High_FAQ applicable to all MSOs (C&ED portal).md>) | Official FAQs on AML/CFT and licence applications. | Read practical identity, ownership, representative and non-face-to-face cases alongside the current rules. |
| 07 | **Circular - Supervisory Findings on Customer Due Diligence (22 Nov 2023) - MSSB/MIS_03/2023**<br>[TC](<TC/07_高_通函_客戶盡職審查相關監管工作中的發現（2023年11月22日）.pdf>) · [EN](<EN/07_High_Circular - Supervisory Findings on Customer Due Diligence (22 Nov 2023).pdf>) | Supervisory findings on customer due diligence. | Read the deficiencies, expected standards and good practices for risk, ownership, screening and authority. |
| 08 | **Circular - ML-TF Risks of Third Party Payments (17 Sep 2024) - MSSB/MIS_01/2024**<br>[TC](<TC/08_高_通函_第三方支付涉及的洗錢及恐怖分子資金籌集風險（2024年9月17日）.pdf>) · [EN](<EN/08_High_Circular - ML-TF Risks of Third Party Payments (17 Sep 2024).pdf>) | Risks and controls for third-party payments. | Study acceptance, approval, identity, relationships, funds, monitoring, records and reporting. |
| 09 | **Circular - Identification and Mitigation of Proliferation Financing Risks (22 Dec 2021) - MSSB/MIS_06/2021** **Added**<br>[TC](<TC/09_高_通函_識別和緩解大殺傷力武器擴散融資風險（2021年12月22日）.pdf>) · [EN](<EN/09_High_Circular - Identification and Mitigation of Proliferation Financing Risks (22 Dec 2021).pdf>) | Institutional proliferation-financing risk assessment and mitigation. | Read in full with guideline chapters 2 and 6, including review of existing business and customers. |

## Medium priority

| Order | Material and local files | What it is | Reading focus |
|---|---|---|---|
| 10 | **Guideline on Criteria for Determining Fitness and Propriety (Apr 2018)**<br>[TC](<TC/10_中_有關適當人選準則的指引（2018年4月）.pdf>) · [EN](<EN/10_Medium_Guideline on Criteria for Determining Fitness and Propriety (Apr 2018).pdf>) | Criteria for fitness and propriety. | Read with the supplement; distinguish adverse factors from automatic exclusions. |
| 11 | **Supplementary Guideline on Fitness and Propriety (Jan 2020)**<br>[TC](<TC/11_中_有關適當人選準則的補充指引（2020年1月）.pdf>) · [EN](<EN/11_Medium_Supplementary Guideline on Fitness and Propriety (Jan 2020).pdf>) | Supplementary fitness and propriety criteria. | Read competence, integrity, business intent, consumer interests and continuing compliance. |
| 12 | **Guidelines for Submission of Business Plan (Ver 12-2019)**<br>[TC](<TC/12_中_遞交業務計劃的指引（12-2019版）.pdf>) · [EN](<EN/12_Medium_Guidelines for Submission of Business Plan (Ver 12-2019).pdf>) | Required contents of a business plan. | Understand the business model, customers, jurisdictions, funds, staff, agents and outsourcing. |
| 13 | **Guidelines for Submission of AML-CFT Policy (Ver 12-2019)**<br>[TC](<TC/13_中_遞交打擊洗錢及恐怖分子資金籌集政策的指引（12-2019版）.pdf>) · [EN](<EN/13_Medium_Guidelines for Submission of AML-CFT Policy (Ver 12-2019).pdf>) | Required contents of an AML/CFT policy. | Use as a checklist for risk assessment, compliance, reporting, training, monitoring and audit. |
| 14 | **Disciplinary Action Guideline on Pecuniary Penalty (Apr 2018)**<br>[TC](<TC/14_中_施加罰款紀律行動指引（2018年4月）.pdf>) · [EN](<EN/14_Medium_Disciplinary Action Guideline on Pecuniary Penalty (Apr 2018).pdf>) | Pecuniary penalties for licensing and operating breaches. | Read with AMLO sections 43 and 45; distinguish from disciplinary fining. |
| 15 | **Disciplinary Fining Guideline (May 2018)**<br>[TC](<TC/15_中_紀律處分罰款指引（2018年5月）.pdf>) · [EN](<EN/15_Medium_Disciplinary Fining Guideline (May 2018).pdf>) | Disciplinary fining for specified AML/CFT breaches. | Read with sections 21 and 23: seriousness, deterrence, remediation, cooperation and history. |
| 16 | **Circular - ML-TF Risks of Delivery Channels (13 Dec 2021) - MSSB/MIS_05/2021**<br>[TC](<TC/16_中_通函_與交付渠道有關的洗錢及恐怖分子資金籌集風險（2021年12月13日）.pdf>) · [EN](<EN/16_Medium_Circular - ML-TF Risks of Delivery Channels (13 Dec 2021).pdf>) | Risks arising from delivery channels and counterparties. | Read pre-engagement assessment, periodic review and suspicious transaction follow-up. |
| 17 | **Circular - Cross-boundary Movement of Currency Ordinance Cap 629 (31 Jul 2018) - MSSB/MIS_06/2018**<br>[TC](<TC/17_中_通函_實體貨幣及不記名可轉讓票據跨境流動條例（2018年7月31日）.pdf>) · [EN](<EN/17_Medium_Circular - Cross-boundary Movement of Currency Ordinance Cap 629 (31 Jul 2018).pdf>) | Summary of cross-boundary currency and bearer instrument requirements. | Distinguish thresholds, arrival/departure, passengers and cargo. |
| 18 | **Circular - E-submission of the Periodic Return (30 May 2025) - MSSB/MIS_02/2025**<br>[TC](<TC/18_中_通函_經金錢服務經營者牌照系統提交電子版交易報告定期申報表（2025年5月30日）.pdf>) · [EN](<EN/18_Medium_Circular - E-submission of the Periodic Return (30 May 2025).pdf>) | Electronic periodic returns, reporting periods and data fields. | Study half-yearly submission, periods, electronic format and required fields. |
| 19 | **Circular - Amendments to the Money Changers Ordinance Cap 34 (17 Nov 2025) - MSSB/MIS_04/2025**<br>[TC](<TC/19_中_通函_貨幣兌換商條例第34章之修訂（2025年11月17日）.pdf>) · [EN](<EN/19_Medium_Circular - Amendments to the Money Changers Ordinance Cap 34 (17 Nov 2025).pdf>) | Notice of amendments to the Money Changers Ordinance. | Read the notice, then the following statutory schedules. |
| 20 | **Money Changers Ordinance Cap 34 - Schedules 2 and 3 - Official Webpage Extract (24 Aug 2025) - MSSB/MIS_04/2025** **Added**<br>[TC](<TC/20_中_貨幣兌換商條例第34章_附表2及3_官方網頁摘錄（2025年8月24日版）.md>) · [EN](<EN/20_Medium_Money Changers Ordinance Cap 34 - Schedules 2 and 3 - Official Webpage Extract (24 Aug 2025).md>) | Official webpage extract of Cap. 34 Schedules 2 and 3. | Read permitted statements and prescribed currencies, with sections 3-8 and Schedule 1 online for context. |
| 21 | **Circular - Trade-based Money Laundering Guidance (20 Jan 2026) - MSSB/MIS_01/2026**<br>[TC](<TC/21_中_通函_打擊以貿易進行洗錢活動指引（2026年1月20日）.pdf>) · [EN](<EN/21_Medium_Circular - Trade-based Money Laundering Guidance (20 Jan 2026).pdf>) | Trade-based money laundering risks and controls. | Read customer/funds checks, alerts, analysis and reporting, then the risk indicators. |
| 22 | **Trade-Based Money Laundering Risk Indicators - FATF and Egmont (Mar 2021)** **Added**<br>[TC](<TC/22_中_貿易洗錢風險指標_FATF與Egmont（2021年3月_英文原文指引）.md>) · [EN](<EN/22_Medium_Trade-Based Money Laundering Risk Indicators - FATF and Egmont (Mar 2021).pdf>) | Joint FATF/Egmont trade-based money laundering risk indicators. | Read the handling notes and four indicator groups; understand rather than memorise the lists. |
| 23 | **Circular - Statements issued by the FATF (3 Jul 2026) - MSSB/FATF_02/2026**<br>[TC](<TC/23_中_通函_財務行動特別組織的聲明（2026年7月3日）.pdf>) · [EN](<EN/23_Medium_Circular - Statements issued by the FATF (3 Jul 2026).pdf>) | FATF statements on high-risk and monitored jurisdictions. | Learn the different responses and check for a newer statement before the exam. |
| 24 | **Circular - Publication of Hong Kong Risk Assessment Report (11 Jul 2022) - MSSB/MIS_06/2022** **Added**<br>[TC](<TC/24_中_通函_公布香港洗錢及恐怖分子資金籌集風險評估報告（2022年7月11日）.pdf>) · [EN](<EN/24_Medium_Circular - Publication of Hong Kong Risk Assessment Report (11 Jul 2022).pdf>) | C&ED circular on the Hong Kong risk assessment report. | Read this short notice before the report to understand its application to MSOs. |
| 25 | **Hong Kong Money Laundering and Terrorist Financing Risk Assessment Report (2022)** **Added**<br>[TC](<TC/25_中_香港洗錢及恐怖分子資金籌集風險評估報告（2022年）.pdf>) · [EN](<EN/25_Medium_Hong Kong Money Laundering and Terrorist Financing Risk Assessment Report (2022).pdf>) | Hong Kong territory-wide and sectoral risk assessment. | Focus on section 5.4 and MSO cases; selectively read TF and PF chapters. |
| 26 | **Circular - United Nations Sanctions - Principles and Early Alerts (7 Feb 2018) - MSSB/SAN_01/2018** **Added**<br>[TC](<TC/26_中_通函_聯合國制裁_原則及預警機制（2018年2月7日）.pdf>) · [EN](<EN/26_Medium_Circular - United Nations Sanctions - Principles and Early Alerts (7 Feb 2018).pdf>) | Principles of UN sanctions screening and early alerts. | Read alongside guideline chapter 6, including sanctions not yet implemented locally. |
| 27 | **Training Slides - Suspicious Transaction Reporting (Uploaded 7 Jan 2026)** **Added**<br>[TC](<TC/27_中_培訓講義_舉報可疑交易（2026年1月7日上載）.pdf>) · [EN](<EN/27_Medium_Training Slides - Suspicious Transaction Reporting (Uploaded 7 Jan 2026).pdf>) | Officially hosted training slides on suspicious transaction reporting. | Use the cases and reporting explanation as an aid, not an independent exam specification. |
| 28 | **Training Slides - ML-TF-PF Risk Assessment and Mitigation (12 Mar 2024)** **Added**<br>[TC](<TC/28_中_培訓講義_洗錢及恐怖分子資金籌集和擴散融資的風險評估及緩解（2024年3月12日）.pdf>) · [EN](<EN/28_Medium_Training Slides - ML-TF-PF Risk Assessment and Mitigation (12 Mar 2024).pdf>) | C&ED training slides on ML/TF/PF risk assessment and mitigation. | Use diagrams and examples to consolidate the methodology; check current rules for detail. |

## Low priority

| Order | Material and local files | What it is | Reading focus |
|---|---|---|---|
| 29 | **Circular - ML-TF Institutional Risk Assessment (13 Aug 2018) - MSSB/MIS_07/2018** **Added**<br>[TC](<TC/29_低_通函_機構層面的洗錢及恐怖分子資金籌集風險評估（2018年8月13日）.pdf>) · [EN](<EN/29_Low_Circular - ML-TF Institutional Risk Assessment (13 Aug 2018).pdf>) | Earlier circular on institutional ML/TF risk assessment. | Read once alongside guideline chapter 2 and the delivery-channel circular; much overlaps. |
| 30 | **Circular - Fraudulent Websites and Social Media Platforms related to MSOs (24 Apr 2025) - MSSB/MIS_01/2025**<br>[TC](<TC/30_低_通函_與金錢服務經營者有關的欺詐網站及社交媒體平台（2025年4月24日）.pdf>) · [EN](<EN/30_Low_Circular - Fraudulent Websites and Social Media Platforms related to MSOs (24 Apr 2025).pdf>) | Warning about fraudulent websites and social media impersonation. | Remember data protection, vigilance, public notification and reporting. |
| 31 | **Circular - E-form Submission for Passenger Information on Currency and BNIs (23 Jun 2025) - MSSB/MIS_03/2025**<br>[TC](<TC/31_低_通函_提交旅客資料電子表格（現金類物品）（2025年6月23日）.pdf>) · [EN](<EN/31_Low_Circular - E-form Submission for Passenger Information on Currency and BNIs (23 Jun 2025).pdf>) | Passenger e-form and QR-code workflow for currency declarations. | Distinguish pre-filling from completing the declaration in person. |
| 32 | **Circular - FATF Consultation on Payment Transparency Guidance (16 Jul 2026) - MSSB/FATF_03/2026**<br>[TC](<TC/32_低_通函_財務行動特別組織就加強支付透明度的指引展開公眾諮詢（2026年7月16日）.pdf>) · [EN](<EN/32_Low_Circular - FATF Consultation on Payment Transparency Guidance (16 Jul 2026).pdf>) | FATF consultation on payment transparency guidance. | Understand the topic and future direction; do not treat a draft as current Hong Kong law. |

## Editions, languages and scope

- The original 23 sources are retained unchanged; nine materials have been added, including the recommended additions, the earlier institutional risk assessment circular and two training decks.
- **Item 20** is a text extract of Cap. 34 Schedules 2 and 3 from the official webpage, not the complete Ordinance or a verified PDF. The browser showed version 24 August 2025 on 18 October 2026; the PDF could not be saved. The extract links to the full law and identifies sections 3-8 and Schedule 1 for context.
- **Item 22** contains the official English FATF/Egmont PDF downloaded from co-publisher Egmont Group. Its TC file is a reading pointer, not a Chinese translation. The direct FATF download returned 403.
- **Item 27** was uploaded in both languages on 7 January 2026, but the official portal lists different seminar dates: 14 November 2025 for Chinese and 9 December 2025 for English. These are retained as their respective official editions, not described as verbatim translations of one seminar.
- **Item 28** is dated 12 March 2024 and was uploaded on 12 April 2024.
- **Item 04**, Cap. 615, retains the archived consolidated edition dated 24 September 2026. Whether it is still the latest edition was not reverified in this reorganisation.
- Recheck current lists and periodic statements before the exam. Retain still-cited principles circulars; overlap with later guidance does not itself establish formal withdrawal.
- The current bank and revision pack still use the original 23 sources. Archiving the nine additions does not establish question-bank coverage of them. Training decks are reading aids, not an additional official syllabus.

## Official sources and stable source IDs

S-numbers are stable source IDs for quotes, extracted text and historical audits. Old references to document 02 mean S02, now reading item 03. Use the reading order above for study.

| Reading order | Stable source ID | Official Chinese source | Official English source |
|---|---|---|---|
| 01 | S01 | [Official source](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_en.pdf) |
| 02 | S23 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=297633) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=297632) |
| 03 | S02 | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/AMLO_Guideline_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/AMLO_Guideline_en.pdf) |
| 04 | S10 | [Official source](https://www.elegislation.gov.hk/hk/cap615) | [Official source](https://www.elegislation.gov.hk/hk/cap615) |
| 05 | S03 | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Licensing_Guide_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Licensing_Guide_en.pdf) |
| 06 | S22 | [Official source](https://eservices.customs.gov.hk/MSOS/common/faqs) | [Official source](https://eservices.customs.gov.hk/MSOS/common/faqs) |
| 07 | S13 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=400636) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=400637) |
| 08 | S14 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=431731) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=431730) |
| 09 | S24 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=324152) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=324151) |
| 10 | S04 | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_on_Criteria_for_Determining_FP_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_on_Criteria_for_Determining_FP_en.pdf) |
| 11 | S05 | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Supplementary_FnP_Guideline_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Supplementary_FnP_Guideline_en.pdf) |
| 12 | S06 | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_for_Submission_of_Business_Plan_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_for_Submission_of_Business_Plan_en.pdf) |
| 13 | S07 | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_for_Submission_of_AML_Policy_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_for_Submission_of_AML_Policy_en.pdf) |
| 14 | S08 | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/disciplinary_action_guidelines_under_s.45_of_amlo_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/disciplinary_action_guidelines_under_s.45_of_amlo_en.pdf) |
| 15 | S09 | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Fining_Guideline_zh_TW.pdf) | [Official source](https://eservices.customs.gov.hk/MSOS/download/guideline/Fining_Guideline_en.pdf) |
| 16 | S12 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=323202) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=323201) |
| 17 | S11 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=165023) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=165022) |
| 18 | S16 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=457101) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=457100) |
| 19 | S18 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=472037) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=472036) |
| 20 | S27 | [Official source](https://www.elegislation.gov.hk/hk/cap34?_lang=zh-Hant-HK) | [Official source](https://www.elegislation.gov.hk/hk/cap34?_lang=en) |
| 21 | S19 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=478777) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=478776) |
| 22 | S28 | [英文原文入口](https://egmontgroup.org/wp-content/uploads/2021/10/Trade-Based-Money-Laundering-Risk-Indicators.pdf) | [Official source](https://egmontgroup.org/wp-content/uploads/2021/10/Trade-Based-Money-Laundering-Risk-Indicators.pdf) |
| 23 | S20 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=494903) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=494902) |
| 24 | S26 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=343447) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=343450) |
| 25 | S25 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=343270) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=343269) |
| 26 | S29 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=147929) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=147928) |
| 27 | S31 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=477113) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=477112) |
| 28 | S32 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=416502) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=416501) |
| 29 | S30 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=166600) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=166599) |
| 30 | S15 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=452990) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=452989) |
| 31 | S17 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=459116) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=459115) |
| 32 | S21 | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=496814) | [Official source](https://eservices.customs.gov.hk/MSOS/downloadFile?id=496813) |

## Maintenance and references

Before editing questions, filenames or source content, read [source maintenance](SOURCE-MAINTENANCE.md) to distinguish reading order from stable source IDs.

[`catalog.json`](catalog.json) records reading order, priority, source ID, filename, official URL and SHA-256. NN in `text/EN/NN.txt`, `text/TC/NN.txt`, `quotes.json` and `transcripts/NN.json` remains the stable source ID.

```bash
python docs/extract_text.py
python docs/build_catalog.py --check
go test ./...
```

See [question-bank source mapping](QUESTION-SOURCES.md) for the original 23 sources. `source-reorganization.json` and the catalog preserve verifiable migration records for historical paths and hashes.

[海關指引 / Guidelines](https://eservices.customs.gov.hk/MSOS/common/guidelines) · [海關通函 / Circulars](https://eservices.customs.gov.hk/MSOS/common/circulars) · [培訓資料 / Capacity building](https://eservices.customs.gov.hk/MSOS/common/capacityBuilding)

Rights in official source material remain with its publishers, including the HKSAR Government and FATF/OECD and Egmont Group. The repository MIT licence grants no rights in those texts; see [content licensing](../LICENSE-CONTENT.md).
