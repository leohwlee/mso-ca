# MSO 官方資料閱讀目錄

[English version →](README.md)

共 **32 項材料**，按「高 → 中 → 低」及同級建議閱讀順序排列：高9項、中19項、低4項。在 `TC/` 或 `EN/` 按檔名排序，順次閱讀即可。

檔名格式：`閱讀序號_優先級_文件名稱（版本）`，例如 `03_高_…`。同一序號的中英文檔案對應同一材料。

優先級是根據官方考綱及文件內容作出的復習建議，並非海關公布的出題權重。高：第一輪重點讀；中：第二輪完整讀或按建議選讀；低：最後快速讀。低優先級不表示不會考。

官方依據：《能力評核須知》第5.2至6.1段。七個單元各5題；每單元至少答對3題，總分至少25/35。參考類別包括第615章、反洗錢指引、牌照指引、其他指引及通函。

[官方考試須知 / Official Guidance Notes](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_zh_TW.pdf)

## 高優先級

| 順序 | 材料及本地檔案 | 它是甚麼 | 閱讀重點 |
|---|---|---|---|
| 01 | **能力評核須知（2022年12月）**<br>[TC](<TC/01_高_能力評核須知（2022年12月）.pdf>) · [EN](<EN/01_High_Guidance Notes on the Competence Assessment (Dec 2022).pdf>) | 能力評核的考試規則及範圍。 | 先讀第5至7節、及格要求及應考安排；毋須反覆背行政細節。 |
| 02 | **金錢服務經營者適用的能力評核_參考試題（2021年5月12日） - MSSB/CA_01/2021**<br>[TC](<TC/02_高_金錢服務經營者適用的能力評核_參考試題（2021年5月12日）.pdf>) · [EN](<EN/02_High_Competence Assessment - Sample Questions (12 May 2021).pdf>) | 海關公布的七道參考試題。 | 先試做，再逐項理解；完成核心教材後重做，不能據此推算出題比例。 |
| 03 | **打擊洗錢及恐怖分子資金籌集指引（金錢服務經營者適用）（2023年6月）**<br>[TC](<TC/03_高_打擊洗錢及恐怖分子資金籌集指引（金錢服務經營者適用）（2023年6月）.pdf>) · [EN](<EN/03_High_Guideline on AML-CFT for Money Service Operators (Jun 2023).pdf>) | MSO反洗錢工作的主要操作標準。 | 精讀第1至11章及附錄A：風險、管治、客戶核查、監察、制裁、舉報、紀錄、培訓及匯款。 |
| 04 | **打擊洗錢及恐怖分子資金籌集條例（第615章）（2026年9月24日綜合版）**<br>[TC](<TC/04_高_打擊洗錢及恐怖分子資金籌集條例（第615章）（2026年9月24日綜合版）.pdf>) · [EN](<EN/04_High_AMLO Cap 615 - Consolidated (24 Sep 2026).pdf>) | 第615章的法律原文。 | 按考綱讀第1至7部及附表；重點掌握MSO發牌、監管、紀律處分、覆核及附表2。 |
| 05 | **牌照指引（2026年5月）**<br>[TC](<TC/05_高_牌照指引（2026年5月）.pdf>) · [EN](<EN/05_High_Licensing Guide (May 2026).pdf>) | 申請、續牌及持牌期間的經營要求。 | 讀發牌豁免、程序、處所、本地管理辦事處、相關人士、變更及定期申報。 |
| 06 | **適用於所有金錢服務經營者的常見問題（海關網站） - MSSB/GUIDE_01/2019**<br>[TC](<TC/06_高_適用於所有金錢服務經營者的常見問題（海關網站）.md>) · [EN](<EN/06_High_FAQ applicable to all MSOs (C&ED portal).md>) | 海關對客戶核查及牌照申請的常見問題解釋。 | 配合核心指引讀身份文件、法人、實益擁有人、客戶代表及非面對面業務；疑義回查最新法例及指引。 |
| 07 | **通函_客戶盡職審查相關監管工作中的發現（2023年11月22日） - MSSB/MIS_03/2023**<br>[TC](<TC/07_高_通函_客戶盡職審查相關監管工作中的發現（2023年11月22日）.pdf>) · [EN](<EN/07_High_Circular - Supervisory Findings on Customer Due Diligence (22 Nov 2023).pdf>) | 海關巡查發現的客戶盡職審查缺失及預期標準。 | 逐項讀風險評級、實益擁有人、政治人物及制裁篩查、客戶代表授權的缺失和改善方式。 |
| 08 | **通函_第三方支付涉及的洗錢及恐怖分子資金籌集風險（2024年9月17日） - MSSB/MIS_01/2024**<br>[TC](<TC/08_高_通函_第三方支付涉及的洗錢及恐怖分子資金籌集風險（2024年9月17日）.pdf>) · [EN](<EN/08_High_Circular - ML-TF Risks of Third Party Payments (17 Sep 2024).pdf>) | 第三方付款的風險、接納條件及管控措施。 | 讀是否接納、管理層批准、第三方身份與關係、資金來源、持續監察、紀錄及舉報。 |
| 09 | **通函_識別和緩解大殺傷力武器擴散融資風險（2021年12月22日） - MSSB/MIS_06/2021** **新增**<br>[TC](<TC/09_高_通函_識別和緩解大殺傷力武器擴散融資風險（2021年12月22日）.pdf>) · [EN](<EN/09_High_Circular - Identification and Mitigation of Proliferation Financing Risks (22 Dec 2021).pdf>) | 機構層面識別、評估及減低擴散資金籌集風險的要求。 | 全文讀，配合核心指引第2及6章，留意現有業務及客戶的全面檢視。 |

## 中優先級

| 順序 | 材料及本地檔案 | 它是甚麼 | 閱讀重點 |
|---|---|---|---|
| 10 | **有關適當人選準則的指引（2018年4月）**<br>[TC](<TC/10_中_有關適當人選準則的指引（2018年4月）.pdf>) · [EN](<EN/10_Medium_Guideline on Criteria for Determining Fitness and Propriety (Apr 2018).pdf>) | 評定申請人及相關人士是否適合經營MSO的因素。 | 與補充指引一併讀；分清需考慮的不利因素及自動禁止。 |
| 11 | **有關適當人選準則的補充指引（2020年1月）**<br>[TC](<TC/11_中_有關適當人選準則的補充指引（2020年1月）.pdf>) · [EN](<EN/11_Medium_Supplementary Guideline on Fitness and Propriety (Jan 2020).pdf>) | 適當人選準則的補充情形及例子。 | 讀能力、誠信、真實經營意圖、消費者利益及持續合規。 |
| 12 | **遞交業務計劃的指引（12-2019版）**<br>[TC](<TC/12_中_遞交業務計劃的指引（12-2019版）.pdf>) · [EN](<EN/12_Medium_Guidelines for Submission of Business Plan (Ver 12-2019).pdf>) | 業務計劃應交代的主要項目。 | 掌握業務模式、客戶、地區、資金流向、人員、代理及外判；毋須逐字背表。 |
| 13 | **遞交打擊洗錢及恐怖分子資金籌集政策的指引（12-2019版）**<br>[TC](<TC/13_中_遞交打擊洗錢及恐怖分子資金籌集政策的指引（12-2019版）.pdf>) · [EN](<EN/13_Medium_Guidelines for Submission of AML-CFT Policy (Ver 12-2019).pdf>) | 如何制訂配合本身業務風險的反洗錢政策。 | 用作制度清單，覆核風險評估、合規、舉報、培訓、監察及審核安排。 |
| 14 | **施加罰款紀律行動指引（2018年4月）**<br>[TC](<TC/14_中_施加罰款紀律行動指引（2018年4月）.pdf>) · [EN](<EN/14_Medium_Disciplinary Action Guideline on Pecuniary Penalty (Apr 2018).pdf>) | 涉及牌照及經營規定的罰款權力及考慮因素。 | 配合第615章第43、45條讀，與另一份罰款指引區分。 |
| 15 | **紀律處分罰款指引（2018年5月）**<br>[TC](<TC/15_中_紀律處分罰款指引（2018年5月）.pdf>) · [EN](<EN/15_Medium_Disciplinary Fining Guideline (May 2018).pdf>) | 違反反洗錢指明條文時的罰款考慮。 | 配合第615章第21、23條讀嚴重性、阻嚇、補救、合作及過往紀錄。 |
| 16 | **通函_與交付渠道有關的洗錢及恐怖分子資金籌集風險（2021年12月13日） - MSSB/MIS_05/2021**<br>[TC](<TC/16_中_通函_與交付渠道有關的洗錢及恐怖分子資金籌集風險（2021年12月13日）.pdf>) · [EN](<EN/16_Medium_Circular - ML-TF Risks of Delivery Channels (13 Dec 2021).pdf>) | 匯款交付渠道、合作方及境外渠道的風險。 | 讀合作前的全面風險評估、定期覆核及可疑交易跟進。 |
| 17 | **通函_實體貨幣及不記名可轉讓票據跨境流動條例（2018年7月31日） - MSSB/MIS_06/2018**<br>[TC](<TC/17_中_通函_實體貨幣及不記名可轉讓票據跨境流動條例（2018年7月31日）.pdf>) · [EN](<EN/17_Medium_Circular - Cross-boundary Movement of Currency Ordinance Cap 629 (31 Jul 2018).pdf>) | 第629章跨境現金類物品申報及披露制度摘要。 | 分清門檻、入境與離境、旅客與貨物的不同要求。 |
| 18 | **通函_經金錢服務經營者牌照系統提交電子版交易報告定期申報表（2025年5月30日） - MSSB/MIS_02/2025**<br>[TC](<TC/18_中_通函_經金錢服務經營者牌照系統提交電子版交易報告定期申報表（2025年5月30日）.pdf>) · [EN](<EN/18_Medium_Circular - E-submission of the Periodic Return (30 May 2025).pdf>) | 交易定期申報的周期、電子提交及新增數據。 | 掌握每半年提交、涵蓋期間、提交方式及附表資料；注意現行安排。 |
| 19 | **通函_貨幣兌換商條例第34章之修訂（2025年11月17日） - MSSB/MIS_04/2025**<br>[TC](<TC/19_中_通函_貨幣兌換商條例第34章之修訂（2025年11月17日）.pdf>) · [EN](<EN/19_Medium_Circular - Amendments to the Money Changers Ordinance Cap 34 (17 Nov 2025).pdf>) | 提醒MSO注意第34章交易單據及匯率展示的修訂。 | 先讀短通函，隨即對照下一份法例附表原文。 |
| 20 | **貨幣兌換商條例第34章_附表2及3_官方網頁摘錄（2025年8月24日版） - MSSB/MIS_04/2025** **新增**<br>[TC](<TC/20_中_貨幣兌換商條例第34章_附表2及3_官方網頁摘錄（2025年8月24日版）.md>) · [EN](<EN/20_Medium_Money Changers Ordinance Cap 34 - Schedules 2 and 3 - Official Webpage Extract (24 Aug 2025).md>) | 第34章附表2及3的官方網頁原文摘錄。 | 讀准許陳述及訂明貨幣；適用範圍及單據、展示責任另配合官網第3至8條及附表1。 |
| 21 | **通函_打擊以貿易進行洗錢活動指引（2026年1月20日） - MSSB/MIS_01/2026**<br>[TC](<TC/21_中_通函_打擊以貿易進行洗錢活動指引（2026年1月20日）.pdf>) · [EN](<EN/21_Medium_Circular - Trade-based Money Laundering Guidance (20 Jan 2026).pdf>) | 偽造貿易、空殼公司等貿易洗錢風險及管控。 | 讀客戶與資金來源、交易警報、分析及舉報；再看下一份風險指標。 |
| 22 | **貿易洗錢風險指標_FATF與Egmont（2021年3月_英文原文指引）** **新增**<br>[TC](<TC/22_中_貿易洗錢風險指標_FATF與Egmont（2021年3月_英文原文指引）.md>) · [EN](<EN/22_Medium_Trade-Based Money Laundering Risk Indicators - FATF and Egmont (Mar 2021).pdf>) | FATF與Egmont共同發布的貿易洗錢風險指標。 | 讀使用說明及四組指標；理解企業、貿易、單據貨物及賬戶交易的異常，不逐字背全表。 |
| 23 | **通函_財務行動特別組織的聲明（2026年7月3日） - MSSB/FATF_02/2026**<br>[TC](<TC/23_中_通函_財務行動特別組織的聲明（2026年7月3日）.pdf>) · [EN](<EN/23_Medium_Circular - Statements issued by the FATF (3 Jul 2026).pdf>) | FATF對高風險及受加強監察司法管轄區的聲明。 | 掌握不同類別的處理原則；考前查有否更新，勿只背舊名單。 |
| 24 | **通函_公布香港洗錢及恐怖分子資金籌集風險評估報告（2022年7月11日） - MSSB/MIS_06/2022** **新增**<br>[TC](<TC/24_中_通函_公布香港洗錢及恐怖分子資金籌集風險評估報告（2022年7月11日）.pdf>) · [EN](<EN/24_Medium_Circular - Publication of Hong Kong Risk Assessment Report (11 Jul 2022).pdf>) | 海關要求業界考慮香港風險評估報告的通函。 | 先讀一頁通函，掌握為何及如何把行業風險納入本身評估。 |
| 25 | **香港洗錢及恐怖分子資金籌集風險評估報告（2022年）** **新增**<br>[TC](<TC/25_中_香港洗錢及恐怖分子資金籌集風險評估報告（2022年）.pdf>) · [EN](<EN/25_Medium_Hong Kong Money Laundering and Terrorist Financing Risk Assessment Report (2022).pdf>) | 香港整體及各行業的洗錢、恐怖分子及擴散資金籌集風險評估。 | 重點第5.4節MSO及相關案例，再選讀恐怖分子及擴散資金籌集部分，毋須整本精讀。 |
| 26 | **通函_聯合國制裁_原則及預警機制（2018年2月7日） - MSSB/SAN_01/2018** **新增**<br>[TC](<TC/26_中_通函_聯合國制裁_原則及預警機制（2018年2月7日）.pdf>) · [EN](<EN/26_Medium_Circular - United Nations Sanctions - Principles and Early Alerts (7 Feb 2018).pdf>) | 聯合國制裁的原則性監管要求及預警機制。 | 與核心指引第6章對讀；留意未在香港落實的聯合國制裁、篩查更新及舉報。 |
| 27 | **培訓講義_舉報可疑交易（2026年1月7日上載）** **新增**<br>[TC](<TC/27_中_培訓講義_舉報可疑交易（2026年1月7日上載）.pdf>) · [EN](<EN/27_Medium_Training Slides - Suspicious Transaction Reporting (Uploaded 7 Jan 2026).pdf>) | 海關網站發布的聯合財富情報組培訓講義：舉報可疑交易。 | 輔助理解可疑交易、舉報及案例；屬培訓資料，不能據此推定全部內容獨立出題。 |
| 28 | **培訓講義_洗錢及恐怖分子資金籌集和擴散融資的風險評估及緩解（2024年3月12日）** **新增**<br>[TC](<TC/28_中_培訓講義_洗錢及恐怖分子資金籌集和擴散融資的風險評估及緩解（2024年3月12日）.pdf>) · [EN](<EN/28_Medium_Training Slides - ML-TF-PF Risk Assessment and Mitigation (12 Mar 2024).pdf>) | 海關培訓講義：洗錢、恐怖分子及擴散資金籌集風險評估。 | 在核心規則後用圖表和例子整理風險評估方法；具體規定回查現行指引。 |

## 低優先級

| 順序 | 材料及本地檔案 | 它是甚麼 | 閱讀重點 |
|---|---|---|---|
| 29 | **通函_機構層面的洗錢及恐怖分子資金籌集風險評估（2018年8月13日） - MSSB/MIS_07/2018** **新增**<br>[TC](<TC/29_低_通函_機構層面的洗錢及恐怖分子資金籌集風險評估（2018年8月13日）.pdf>) · [EN](<EN/29_Low_Circular - ML-TF Institutional Risk Assessment (13 Aug 2018).pdf>) | 機構層面風險評估的較早原則性通函。 | 一頁讀完，與核心指引第2章及交付渠道通函對照；大量內容重疊。 |
| 30 | **通函_與金錢服務經營者有關的欺詐網站及社交媒體平台（2025年4月24日） - MSSB/MIS_01/2025**<br>[TC](<TC/30_低_通函_與金錢服務經營者有關的欺詐網站及社交媒體平台（2025年4月24日）.pdf>) · [EN](<EN/30_Low_Circular - Fraudulent Websites and Social Media Platforms related to MSOs (24 Apr 2025).pdf>) | MSO被冒名、欺詐網站及社交媒體平台的防範提醒。 | 記住保護資料、留意冒名、通知公眾及報案。 |
| 31 | **通函_提交旅客資料電子表格（現金類物品）（2025年6月23日） - MSSB/MIS_03/2025**<br>[TC](<TC/31_低_通函_提交旅客資料電子表格（現金類物品）（2025年6月23日）.pdf>) · [EN](<EN/31_Low_Circular - E-form Submission for Passenger Information on Currency and BNIs (23 Jun 2025).pdf>) | 旅客跨境現金類物品的電子預填表及二維碼流程。 | 分清預先填寫與現場完成申報，配合跨境現金通函閱讀。 |
| 32 | **通函_財務行動特別組織就加強支付透明度的指引展開公眾諮詢（2026年7月16日） - MSSB/FATF_03/2026**<br>[TC](<TC/32_低_通函_財務行動特別組織就加強支付透明度的指引展開公眾諮詢（2026年7月16日）.pdf>) · [EN](<EN/32_Low_Circular - FATF Consultation on Payment Transparency Guidance (16 Jul 2026).pdf>) | FATF就支付透明度指引草案徵詢意見的通知。 | 了解主題及未來方向；勿把諮詢草案直接當成香港已生效要求。 |

## 版本、語言及收錄範圍

- 原有23份文件保留原件；另加入9項材料，包括5組建議補充資料、較早機構風險評估通函及兩份培訓講義。
- **第20項**是第34章附表2及3的官方網頁文字摘錄，不是完整條例或核證PDF。2026年10月18日已在官方瀏覽器頁面核實版本日期為2025年8月24日；PDF下載未能保存。完整法例及第3至8條、附表1的閱讀入口保存在摘錄內。
- **第22項**收錄共同發布方Egmont Group官網的FATF／Egmont英文原件。未找到並核實官方繁體中文版，因此TC檔是通往本地英文原件的閱讀入口，不是中文譯本。FATF直接下載回傳403，已改從共同發布方取得原件。
- **第27項**兩個語言版本同於2026年1月7日上載，但官網列出的講座日期不同：中文為2025年11月14日、英文為2025年12月9日。各自保留官方版本，不宣稱是同場逐字翻譯。
- **第28項**講座日期為2024年3月12日，2024年4月12日上載。
- **第04項**第615章沿用2026年9月24日歸檔綜合版；本次未重新核實其是否仍為最新版本。第20項已核實的第34章版本不能替代這項核驗。
- 名單及定期聲明會更新，考前請查海關通函及FATF最新資料。仍被引用的原則性通函可保留；與新指引內容重疊不等於已正式失效。
- 現行題庫和溫習資料仍以原有23份來源為依據；新增9項的收錄不代表題庫已加入或完整測試其考點。培訓講義屬輔助閱讀，不是額外的官方考綱。

## 官方來源及舊編號對照

此處的S編號是供題庫、文字擷取及歷史審核使用的固定來源ID；舊資料中的「文件02」即S02，現在閱讀順序為03。日常閱讀請用上面的「順序」，不要用S編號排序。

| 閱讀順序 | 固定來源ID | 官方中文來源 | 官方英文來源 |
|---|---|---|---|
| 01 | S01 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/licensing/Guidance_Notes_on_the_Competence_Assessment_for_Money_Service_Operators_en.pdf) |
| 02 | S23 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=297633) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=297632) |
| 03 | S02 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/AMLO_Guideline_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/AMLO_Guideline_en.pdf) |
| 04 | S10 | [官方來源](https://www.elegislation.gov.hk/hk/cap615) | [官方來源](https://www.elegislation.gov.hk/hk/cap615) |
| 05 | S03 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Licensing_Guide_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Licensing_Guide_en.pdf) |
| 06 | S22 | [官方來源](https://eservices.customs.gov.hk/MSOS/common/faqs) | [官方來源](https://eservices.customs.gov.hk/MSOS/common/faqs) |
| 07 | S13 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=400636) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=400637) |
| 08 | S14 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=431731) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=431730) |
| 09 | S24 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=324152) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=324151) |
| 10 | S04 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_on_Criteria_for_Determining_FP_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_on_Criteria_for_Determining_FP_en.pdf) |
| 11 | S05 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Supplementary_FnP_Guideline_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Supplementary_FnP_Guideline_en.pdf) |
| 12 | S06 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_for_Submission_of_Business_Plan_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_for_Submission_of_Business_Plan_en.pdf) |
| 13 | S07 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_for_Submission_of_AML_Policy_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Guidelines_for_Submission_of_AML_Policy_en.pdf) |
| 14 | S08 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/disciplinary_action_guidelines_under_s.45_of_amlo_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/disciplinary_action_guidelines_under_s.45_of_amlo_en.pdf) |
| 15 | S09 | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Fining_Guideline_zh_TW.pdf) | [官方來源](https://eservices.customs.gov.hk/MSOS/download/guideline/Fining_Guideline_en.pdf) |
| 16 | S12 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=323202) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=323201) |
| 17 | S11 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=165023) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=165022) |
| 18 | S16 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=457101) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=457100) |
| 19 | S18 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=472037) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=472036) |
| 20 | S27 | [官方來源](https://www.elegislation.gov.hk/hk/cap34?_lang=zh-Hant-HK) | [官方來源](https://www.elegislation.gov.hk/hk/cap34?_lang=en) |
| 21 | S19 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=478777) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=478776) |
| 22 | S28 | [英文原文入口](https://egmontgroup.org/wp-content/uploads/2021/10/Trade-Based-Money-Laundering-Risk-Indicators.pdf) | [官方來源](https://egmontgroup.org/wp-content/uploads/2021/10/Trade-Based-Money-Laundering-Risk-Indicators.pdf) |
| 23 | S20 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=494903) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=494902) |
| 24 | S26 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=343447) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=343450) |
| 25 | S25 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=343270) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=343269) |
| 26 | S29 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=147929) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=147928) |
| 27 | S31 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=477113) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=477112) |
| 28 | S32 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=416502) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=416501) |
| 29 | S30 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=166600) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=166599) |
| 30 | S15 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=452990) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=452989) |
| 31 | S17 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=459116) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=459115) |
| 32 | S21 | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=496814) | [官方來源](https://eservices.customs.gov.hk/MSOS/downloadFile?id=496813) |

## 維護及引用

改題、改名或更新官方文件前，先讀[來源維護說明](SOURCE-MAINTENANCE.zh-Hant.md)，避免混淆閱讀序號及固定來源編號。

[`catalog.json`](catalog.json)記錄閱讀順序、優先級、來源ID、檔名、官方網址及SHA-256摘要。`text/EN/NN.txt`、`text/TC/NN.txt`、`quotes.json`及`transcripts/NN.json`的NN仍是固定來源ID。改名時不要把這些ID當作閱讀序號重編。

```bash
python docs/extract_text.py
python docs/build_catalog.py --check
go test ./...
```

既有題庫各單元的引用統計見[原有23份來源對照](QUESTION-SOURCES.zh-Hant.md)。歷史審核的舊檔名及摘要，由`source-reorganization.json`和目錄映射保留可核驗的遷移記錄。

[海關指引 / Guidelines](https://eservices.customs.gov.hk/MSOS/common/guidelines) · [海關通函 / Circulars](https://eservices.customs.gov.hk/MSOS/common/circulars) · [培訓資料 / Capacity building](https://eservices.customs.gov.hk/MSOS/common/capacityBuilding)

官方原文的權利仍屬各發布機構，包括香港特區政府及FATF／OECD與Egmont Group。本庫的MIT授權不授予這些原文的使用權；詳見[內容授權](../LICENSE-CONTENT.md)。
