# Maintaining source identity and reading order

[繁體中文版 →](SOURCE-MAINTENANCE.zh-Hant.md)

Read this before editing questions, revision content or official source files.
The 18 October 2026 reorganisation changed visible filenames and added reading
materials. It preserved question IDs, quote IDs and the original source contents.

## Two different numbers

| Field | Purpose | AML/CFT Guideline example |
|---|---|---|
| `order` | Reading sequence and filename prefix; may change | `3`, filename starts `03_High_` |
| `priority` | Study priority; may change | `high` |
| `id` | Stable source identity; never reassigned | `"02"`, displayed as S02 |
| `editions.EN.file` / `editions.TC.file` | Actual archive filename | Resolve through `catalog.json` |
| Quote `doc` | Stable ID, without the display prefix S | `"doc": "02"` |
| Extracted text | Indexed by stable ID | `text/EN/02.txt`, `text/TC/02.txt` |
| Image transcript | Indexed by stable ID when present | S16 uses `transcripts/16.json`, although its reading order is 18 |

Older decisions saying “document 02” mean S02, not reading item 02. PDF page
references still apply because the originals were renamed without changing
their contents. `QUESTION-SOURCES.md` retains the original bank/source mapping.
`python bank/find.py EN 02 "target market"` still searches the AML/CFT Guideline.

## Existing functionality

The exam app and its offline build read `web/`, including `web/questions.json`;
they do not open PDFs by archive filename. Question IDs and browser storage keys
for progress/history were not changed. The revision pack is generated from
`revision/` and retains its stable source references. Extraction and source tests
resolve new filenames through the catalog. Historical audit paths resolve through
`previous_file`; keep that field even after further renaming.

## Renaming or changing order

1. Find the stable ID in `catalog.json`. Rename the files and update `order`,
   `priority` and both language filenames together. Keep `id` and `previous_file`.
   Unchanged content keeps its hash.
2. Run `python docs/extract_text.py` (requires PyMuPDF) to update manifest source
   names, then `python docs/build_catalog.py` to regenerate both directories.
   Edit catalog metadata or the generator, not generated README tables directly.
3. If a maintenance file is recorded in `source-reorganization.json`, preserve
   its original `before_text` and `before_sha256`. Review its changes and update
   only `after_sha256`, using UTF-8 text with LF line endings. Normal LF/CRLF
   conversion is accepted. Do not refresh historical source/question evidence
   hashes just to suppress a failure.
4. Run the checks below. Never renumber quotes, text extracts or transcripts to
   match reading order.

## Adding or updating source content

An updated edition of the same source retains its ID; a different material gets
a new unused ID. Archive official content and record the URL, version and hash.
PDF hashes use original bytes; Markdown hashes fold CRLF to LF. Re-extract text,
review affected quotes and recheck image transcripts against any replaced PDF.

S24-S32 are archived reading additions, not completed question-bank coverage.
When authorised to use them in questions, read the relevant official passages,
add the citation/source mapping in `sources_test.go` (`docPatterns`) and follow
`bank/FORMAT.md` and the review workflow. A matching quote alone does not establish
semantic correctness or exam scope. Append evidence for later changes rather
than rewriting earlier audit snapshots; new contradictions follow the existing
decisions process.

S27 contains only Cap. 34 Schedules 2 and 3 as an official webpage extract. S28's
TC file points to the official English PDF; it is not a Chinese translation.
Training editions may come from different seminar dates. Retain these boundaries
and each edition's own provenance.

## Checks

```bash
python docs/build_catalog.py --check
go test ./...
python bank/audit/report.py --check
python bank/audit/terms_report.py --check
python bank/audit/p1_report.py --check
python bank/audit/remaining_report.py --check
```

When generation may be affected, also build both outputs:

```bash
go run . -export-html dist/mso-ca.html
python revision/pack_build.py dist/mso-revision-pack.html
```

CI and release verification also run the catalog check: order, filenames,
archive hashes and generated directory content. Go tests check source/text,
quote and transcript links; audit checks protect recorded review evidence.
External bookmarks using old physical filenames need the current filename or
the reading directory instead.
